﻿namespace Monopoly
{
    partial class Jogo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Jogo));
            this.label1 = new System.Windows.Forms.Label();
            this.TerminarTurnoButton = new System.Windows.Forms.Button();
            this.dadosButton = new System.Windows.Forms.Button();
            this.dado1label = new System.Windows.Forms.Label();
            this.dado2label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dinheiroJogLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.PreçoCasa = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ValorHipot = new System.Windows.Forms.Label();
            this.HipotecaButton = new System.Windows.Forms.Button();
            this.BuildButton = new System.Windows.Forms.Button();
            this.NrHotel = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.NrCasas = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.NomeProp = new System.Windows.Forms.Label();
            this.PB_Color = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.J8_39 = new System.Windows.Forms.PictureBox();
            this.J7_39 = new System.Windows.Forms.PictureBox();
            this.J6_39 = new System.Windows.Forms.PictureBox();
            this.J5_39 = new System.Windows.Forms.PictureBox();
            this.J4_39 = new System.Windows.Forms.PictureBox();
            this.J3_39 = new System.Windows.Forms.PictureBox();
            this.J2_39 = new System.Windows.Forms.PictureBox();
            this.J1_39 = new System.Windows.Forms.PictureBox();
            this.J8_38 = new System.Windows.Forms.PictureBox();
            this.J7_38 = new System.Windows.Forms.PictureBox();
            this.J6_38 = new System.Windows.Forms.PictureBox();
            this.J5_38 = new System.Windows.Forms.PictureBox();
            this.J4_38 = new System.Windows.Forms.PictureBox();
            this.J3_38 = new System.Windows.Forms.PictureBox();
            this.J2_38 = new System.Windows.Forms.PictureBox();
            this.J1_38 = new System.Windows.Forms.PictureBox();
            this.J8_37 = new System.Windows.Forms.PictureBox();
            this.J7_37 = new System.Windows.Forms.PictureBox();
            this.J6_37 = new System.Windows.Forms.PictureBox();
            this.J5_37 = new System.Windows.Forms.PictureBox();
            this.J4_37 = new System.Windows.Forms.PictureBox();
            this.J3_37 = new System.Windows.Forms.PictureBox();
            this.J2_37 = new System.Windows.Forms.PictureBox();
            this.J1_37 = new System.Windows.Forms.PictureBox();
            this.J8_36 = new System.Windows.Forms.PictureBox();
            this.J7_36 = new System.Windows.Forms.PictureBox();
            this.J6_36 = new System.Windows.Forms.PictureBox();
            this.J5_36 = new System.Windows.Forms.PictureBox();
            this.J4_36 = new System.Windows.Forms.PictureBox();
            this.J3_36 = new System.Windows.Forms.PictureBox();
            this.J2_36 = new System.Windows.Forms.PictureBox();
            this.J1_36 = new System.Windows.Forms.PictureBox();
            this.J8_35 = new System.Windows.Forms.PictureBox();
            this.J7_35 = new System.Windows.Forms.PictureBox();
            this.J6_35 = new System.Windows.Forms.PictureBox();
            this.J5_35 = new System.Windows.Forms.PictureBox();
            this.J4_35 = new System.Windows.Forms.PictureBox();
            this.J3_35 = new System.Windows.Forms.PictureBox();
            this.J2_35 = new System.Windows.Forms.PictureBox();
            this.J1_35 = new System.Windows.Forms.PictureBox();
            this.J8_34 = new System.Windows.Forms.PictureBox();
            this.J7_34 = new System.Windows.Forms.PictureBox();
            this.J6_34 = new System.Windows.Forms.PictureBox();
            this.J5_34 = new System.Windows.Forms.PictureBox();
            this.J4_34 = new System.Windows.Forms.PictureBox();
            this.J3_34 = new System.Windows.Forms.PictureBox();
            this.J2_34 = new System.Windows.Forms.PictureBox();
            this.J1_34 = new System.Windows.Forms.PictureBox();
            this.J8_33 = new System.Windows.Forms.PictureBox();
            this.J7_33 = new System.Windows.Forms.PictureBox();
            this.J6_33 = new System.Windows.Forms.PictureBox();
            this.J5_33 = new System.Windows.Forms.PictureBox();
            this.J4_33 = new System.Windows.Forms.PictureBox();
            this.J3_33 = new System.Windows.Forms.PictureBox();
            this.J2_33 = new System.Windows.Forms.PictureBox();
            this.J1_33 = new System.Windows.Forms.PictureBox();
            this.J8_32 = new System.Windows.Forms.PictureBox();
            this.J7_32 = new System.Windows.Forms.PictureBox();
            this.J6_32 = new System.Windows.Forms.PictureBox();
            this.J5_32 = new System.Windows.Forms.PictureBox();
            this.J4_32 = new System.Windows.Forms.PictureBox();
            this.J3_32 = new System.Windows.Forms.PictureBox();
            this.J2_32 = new System.Windows.Forms.PictureBox();
            this.J1_32 = new System.Windows.Forms.PictureBox();
            this.J8_31 = new System.Windows.Forms.PictureBox();
            this.J7_31 = new System.Windows.Forms.PictureBox();
            this.J6_31 = new System.Windows.Forms.PictureBox();
            this.J5_31 = new System.Windows.Forms.PictureBox();
            this.J4_31 = new System.Windows.Forms.PictureBox();
            this.J3_31 = new System.Windows.Forms.PictureBox();
            this.J2_31 = new System.Windows.Forms.PictureBox();
            this.J1_31 = new System.Windows.Forms.PictureBox();
            this.J8_29 = new System.Windows.Forms.PictureBox();
            this.J7_29 = new System.Windows.Forms.PictureBox();
            this.J6_29 = new System.Windows.Forms.PictureBox();
            this.J5_29 = new System.Windows.Forms.PictureBox();
            this.J4_29 = new System.Windows.Forms.PictureBox();
            this.J3_29 = new System.Windows.Forms.PictureBox();
            this.J2_29 = new System.Windows.Forms.PictureBox();
            this.J1_29 = new System.Windows.Forms.PictureBox();
            this.J8_28 = new System.Windows.Forms.PictureBox();
            this.J7_28 = new System.Windows.Forms.PictureBox();
            this.J6_28 = new System.Windows.Forms.PictureBox();
            this.J5_28 = new System.Windows.Forms.PictureBox();
            this.J4_28 = new System.Windows.Forms.PictureBox();
            this.J3_28 = new System.Windows.Forms.PictureBox();
            this.J2_28 = new System.Windows.Forms.PictureBox();
            this.J1_28 = new System.Windows.Forms.PictureBox();
            this.J8_27 = new System.Windows.Forms.PictureBox();
            this.J7_27 = new System.Windows.Forms.PictureBox();
            this.J6_27 = new System.Windows.Forms.PictureBox();
            this.J5_27 = new System.Windows.Forms.PictureBox();
            this.J4_27 = new System.Windows.Forms.PictureBox();
            this.J3_27 = new System.Windows.Forms.PictureBox();
            this.J2_27 = new System.Windows.Forms.PictureBox();
            this.J1_27 = new System.Windows.Forms.PictureBox();
            this.J8_26 = new System.Windows.Forms.PictureBox();
            this.J7_26 = new System.Windows.Forms.PictureBox();
            this.J6_26 = new System.Windows.Forms.PictureBox();
            this.J5_26 = new System.Windows.Forms.PictureBox();
            this.J4_26 = new System.Windows.Forms.PictureBox();
            this.J3_26 = new System.Windows.Forms.PictureBox();
            this.J2_26 = new System.Windows.Forms.PictureBox();
            this.J1_26 = new System.Windows.Forms.PictureBox();
            this.J8_25 = new System.Windows.Forms.PictureBox();
            this.J7_25 = new System.Windows.Forms.PictureBox();
            this.J6_25 = new System.Windows.Forms.PictureBox();
            this.J5_25 = new System.Windows.Forms.PictureBox();
            this.J4_25 = new System.Windows.Forms.PictureBox();
            this.J3_25 = new System.Windows.Forms.PictureBox();
            this.J2_25 = new System.Windows.Forms.PictureBox();
            this.J1_25 = new System.Windows.Forms.PictureBox();
            this.J8_24 = new System.Windows.Forms.PictureBox();
            this.J7_24 = new System.Windows.Forms.PictureBox();
            this.J6_24 = new System.Windows.Forms.PictureBox();
            this.J5_24 = new System.Windows.Forms.PictureBox();
            this.J4_24 = new System.Windows.Forms.PictureBox();
            this.J3_24 = new System.Windows.Forms.PictureBox();
            this.J2_24 = new System.Windows.Forms.PictureBox();
            this.J1_24 = new System.Windows.Forms.PictureBox();
            this.J8_23 = new System.Windows.Forms.PictureBox();
            this.J7_23 = new System.Windows.Forms.PictureBox();
            this.J6_23 = new System.Windows.Forms.PictureBox();
            this.J5_23 = new System.Windows.Forms.PictureBox();
            this.J4_23 = new System.Windows.Forms.PictureBox();
            this.J3_23 = new System.Windows.Forms.PictureBox();
            this.J2_23 = new System.Windows.Forms.PictureBox();
            this.J1_23 = new System.Windows.Forms.PictureBox();
            this.J8_22 = new System.Windows.Forms.PictureBox();
            this.J7_22 = new System.Windows.Forms.PictureBox();
            this.J6_22 = new System.Windows.Forms.PictureBox();
            this.J5_22 = new System.Windows.Forms.PictureBox();
            this.J4_22 = new System.Windows.Forms.PictureBox();
            this.J3_22 = new System.Windows.Forms.PictureBox();
            this.J2_22 = new System.Windows.Forms.PictureBox();
            this.J1_22 = new System.Windows.Forms.PictureBox();
            this.J8_20 = new System.Windows.Forms.PictureBox();
            this.J7_20 = new System.Windows.Forms.PictureBox();
            this.J6_20 = new System.Windows.Forms.PictureBox();
            this.J5_20 = new System.Windows.Forms.PictureBox();
            this.J4_20 = new System.Windows.Forms.PictureBox();
            this.J3_20 = new System.Windows.Forms.PictureBox();
            this.J2_20 = new System.Windows.Forms.PictureBox();
            this.J1_20 = new System.Windows.Forms.PictureBox();
            this.J8_21 = new System.Windows.Forms.PictureBox();
            this.J7_21 = new System.Windows.Forms.PictureBox();
            this.J6_21 = new System.Windows.Forms.PictureBox();
            this.J5_21 = new System.Windows.Forms.PictureBox();
            this.J4_21 = new System.Windows.Forms.PictureBox();
            this.J3_21 = new System.Windows.Forms.PictureBox();
            this.J2_21 = new System.Windows.Forms.PictureBox();
            this.J1_21 = new System.Windows.Forms.PictureBox();
            this.J8_19 = new System.Windows.Forms.PictureBox();
            this.J7_19 = new System.Windows.Forms.PictureBox();
            this.J6_19 = new System.Windows.Forms.PictureBox();
            this.J5_19 = new System.Windows.Forms.PictureBox();
            this.J4_19 = new System.Windows.Forms.PictureBox();
            this.J3_19 = new System.Windows.Forms.PictureBox();
            this.J2_19 = new System.Windows.Forms.PictureBox();
            this.J1_19 = new System.Windows.Forms.PictureBox();
            this.J8_18 = new System.Windows.Forms.PictureBox();
            this.J7_18 = new System.Windows.Forms.PictureBox();
            this.J6_18 = new System.Windows.Forms.PictureBox();
            this.J5_18 = new System.Windows.Forms.PictureBox();
            this.J4_18 = new System.Windows.Forms.PictureBox();
            this.J3_18 = new System.Windows.Forms.PictureBox();
            this.J2_18 = new System.Windows.Forms.PictureBox();
            this.J1_18 = new System.Windows.Forms.PictureBox();
            this.J8_17 = new System.Windows.Forms.PictureBox();
            this.J7_17 = new System.Windows.Forms.PictureBox();
            this.J6_17 = new System.Windows.Forms.PictureBox();
            this.J5_17 = new System.Windows.Forms.PictureBox();
            this.J4_17 = new System.Windows.Forms.PictureBox();
            this.J3_17 = new System.Windows.Forms.PictureBox();
            this.J2_17 = new System.Windows.Forms.PictureBox();
            this.J1_17 = new System.Windows.Forms.PictureBox();
            this.J8_16 = new System.Windows.Forms.PictureBox();
            this.J7_16 = new System.Windows.Forms.PictureBox();
            this.J6_16 = new System.Windows.Forms.PictureBox();
            this.J5_16 = new System.Windows.Forms.PictureBox();
            this.J4_16 = new System.Windows.Forms.PictureBox();
            this.J3_16 = new System.Windows.Forms.PictureBox();
            this.J2_16 = new System.Windows.Forms.PictureBox();
            this.J1_16 = new System.Windows.Forms.PictureBox();
            this.J8_15 = new System.Windows.Forms.PictureBox();
            this.J7_15 = new System.Windows.Forms.PictureBox();
            this.J6_15 = new System.Windows.Forms.PictureBox();
            this.J5_15 = new System.Windows.Forms.PictureBox();
            this.J4_15 = new System.Windows.Forms.PictureBox();
            this.J3_15 = new System.Windows.Forms.PictureBox();
            this.J2_15 = new System.Windows.Forms.PictureBox();
            this.J1_15 = new System.Windows.Forms.PictureBox();
            this.J8_14 = new System.Windows.Forms.PictureBox();
            this.J7_14 = new System.Windows.Forms.PictureBox();
            this.J6_14 = new System.Windows.Forms.PictureBox();
            this.J5_14 = new System.Windows.Forms.PictureBox();
            this.J4_14 = new System.Windows.Forms.PictureBox();
            this.J3_14 = new System.Windows.Forms.PictureBox();
            this.J2_14 = new System.Windows.Forms.PictureBox();
            this.J1_14 = new System.Windows.Forms.PictureBox();
            this.J8_13 = new System.Windows.Forms.PictureBox();
            this.J7_13 = new System.Windows.Forms.PictureBox();
            this.J6_13 = new System.Windows.Forms.PictureBox();
            this.J5_13 = new System.Windows.Forms.PictureBox();
            this.J4_13 = new System.Windows.Forms.PictureBox();
            this.J3_13 = new System.Windows.Forms.PictureBox();
            this.J2_13 = new System.Windows.Forms.PictureBox();
            this.J1_13 = new System.Windows.Forms.PictureBox();
            this.J8_12 = new System.Windows.Forms.PictureBox();
            this.J7_12 = new System.Windows.Forms.PictureBox();
            this.J6_12 = new System.Windows.Forms.PictureBox();
            this.J5_12 = new System.Windows.Forms.PictureBox();
            this.J4_12 = new System.Windows.Forms.PictureBox();
            this.J3_12 = new System.Windows.Forms.PictureBox();
            this.J2_12 = new System.Windows.Forms.PictureBox();
            this.J1_12 = new System.Windows.Forms.PictureBox();
            this.J8_11 = new System.Windows.Forms.PictureBox();
            this.J7_11 = new System.Windows.Forms.PictureBox();
            this.J6_11 = new System.Windows.Forms.PictureBox();
            this.J5_11 = new System.Windows.Forms.PictureBox();
            this.J4_11 = new System.Windows.Forms.PictureBox();
            this.J3_11 = new System.Windows.Forms.PictureBox();
            this.J2_11 = new System.Windows.Forms.PictureBox();
            this.J1_11 = new System.Windows.Forms.PictureBox();
            this.J8_10 = new System.Windows.Forms.PictureBox();
            this.J7_10 = new System.Windows.Forms.PictureBox();
            this.J6_10 = new System.Windows.Forms.PictureBox();
            this.J5_10 = new System.Windows.Forms.PictureBox();
            this.J4_10 = new System.Windows.Forms.PictureBox();
            this.J3_10 = new System.Windows.Forms.PictureBox();
            this.J2_10 = new System.Windows.Forms.PictureBox();
            this.J1_10 = new System.Windows.Forms.PictureBox();
            this.J8_10P = new System.Windows.Forms.PictureBox();
            this.J7_10P = new System.Windows.Forms.PictureBox();
            this.J6_10P = new System.Windows.Forms.PictureBox();
            this.J5_10P = new System.Windows.Forms.PictureBox();
            this.J4_10P = new System.Windows.Forms.PictureBox();
            this.J3_10P = new System.Windows.Forms.PictureBox();
            this.J2_10P = new System.Windows.Forms.PictureBox();
            this.J1_10P = new System.Windows.Forms.PictureBox();
            this.J8_09 = new System.Windows.Forms.PictureBox();
            this.J7_09 = new System.Windows.Forms.PictureBox();
            this.J6_09 = new System.Windows.Forms.PictureBox();
            this.J5_09 = new System.Windows.Forms.PictureBox();
            this.J4_09 = new System.Windows.Forms.PictureBox();
            this.J3_09 = new System.Windows.Forms.PictureBox();
            this.J2_09 = new System.Windows.Forms.PictureBox();
            this.J1_09 = new System.Windows.Forms.PictureBox();
            this.J8_08 = new System.Windows.Forms.PictureBox();
            this.J7_08 = new System.Windows.Forms.PictureBox();
            this.J6_08 = new System.Windows.Forms.PictureBox();
            this.J5_08 = new System.Windows.Forms.PictureBox();
            this.J4_08 = new System.Windows.Forms.PictureBox();
            this.J3_08 = new System.Windows.Forms.PictureBox();
            this.J2_08 = new System.Windows.Forms.PictureBox();
            this.J1_08 = new System.Windows.Forms.PictureBox();
            this.J8_07 = new System.Windows.Forms.PictureBox();
            this.J7_07 = new System.Windows.Forms.PictureBox();
            this.J6_07 = new System.Windows.Forms.PictureBox();
            this.J5_07 = new System.Windows.Forms.PictureBox();
            this.J4_07 = new System.Windows.Forms.PictureBox();
            this.J3_07 = new System.Windows.Forms.PictureBox();
            this.J2_07 = new System.Windows.Forms.PictureBox();
            this.J1_07 = new System.Windows.Forms.PictureBox();
            this.J8_06 = new System.Windows.Forms.PictureBox();
            this.J7_06 = new System.Windows.Forms.PictureBox();
            this.J6_06 = new System.Windows.Forms.PictureBox();
            this.J5_06 = new System.Windows.Forms.PictureBox();
            this.J4_06 = new System.Windows.Forms.PictureBox();
            this.J3_06 = new System.Windows.Forms.PictureBox();
            this.J2_06 = new System.Windows.Forms.PictureBox();
            this.J1_06 = new System.Windows.Forms.PictureBox();
            this.J8_05 = new System.Windows.Forms.PictureBox();
            this.J7_05 = new System.Windows.Forms.PictureBox();
            this.J6_05 = new System.Windows.Forms.PictureBox();
            this.J5_05 = new System.Windows.Forms.PictureBox();
            this.J4_05 = new System.Windows.Forms.PictureBox();
            this.J3_05 = new System.Windows.Forms.PictureBox();
            this.J2_05 = new System.Windows.Forms.PictureBox();
            this.J1_05 = new System.Windows.Forms.PictureBox();
            this.J8_04 = new System.Windows.Forms.PictureBox();
            this.J7_04 = new System.Windows.Forms.PictureBox();
            this.J6_04 = new System.Windows.Forms.PictureBox();
            this.J5_04 = new System.Windows.Forms.PictureBox();
            this.J4_04 = new System.Windows.Forms.PictureBox();
            this.J3_04 = new System.Windows.Forms.PictureBox();
            this.J2_04 = new System.Windows.Forms.PictureBox();
            this.J1_04 = new System.Windows.Forms.PictureBox();
            this.J8_03 = new System.Windows.Forms.PictureBox();
            this.J7_03 = new System.Windows.Forms.PictureBox();
            this.J6_03 = new System.Windows.Forms.PictureBox();
            this.J5_03 = new System.Windows.Forms.PictureBox();
            this.J4_03 = new System.Windows.Forms.PictureBox();
            this.J3_03 = new System.Windows.Forms.PictureBox();
            this.J2_03 = new System.Windows.Forms.PictureBox();
            this.J1_03 = new System.Windows.Forms.PictureBox();
            this.J8_02 = new System.Windows.Forms.PictureBox();
            this.J7_02 = new System.Windows.Forms.PictureBox();
            this.J6_02 = new System.Windows.Forms.PictureBox();
            this.J5_02 = new System.Windows.Forms.PictureBox();
            this.J4_02 = new System.Windows.Forms.PictureBox();
            this.J3_02 = new System.Windows.Forms.PictureBox();
            this.J2_02 = new System.Windows.Forms.PictureBox();
            this.J1_02 = new System.Windows.Forms.PictureBox();
            this.J8_01 = new System.Windows.Forms.PictureBox();
            this.J7_01 = new System.Windows.Forms.PictureBox();
            this.J6_01 = new System.Windows.Forms.PictureBox();
            this.J5_01 = new System.Windows.Forms.PictureBox();
            this.J4_01 = new System.Windows.Forms.PictureBox();
            this.J3_01 = new System.Windows.Forms.PictureBox();
            this.J2_01 = new System.Windows.Forms.PictureBox();
            this.J1_01 = new System.Windows.Forms.PictureBox();
            this.J8_00 = new System.Windows.Forms.PictureBox();
            this.J7_00 = new System.Windows.Forms.PictureBox();
            this.J6_00 = new System.Windows.Forms.PictureBox();
            this.J5_00 = new System.Windows.Forms.PictureBox();
            this.J4_00 = new System.Windows.Forms.PictureBox();
            this.J3_00 = new System.Windows.Forms.PictureBox();
            this.J2_00 = new System.Windows.Forms.PictureBox();
            this.J1_00 = new System.Windows.Forms.PictureBox();
            this.prop39 = new System.Windows.Forms.PictureBox();
            this.prop37 = new System.Windows.Forms.PictureBox();
            this.prop35 = new System.Windows.Forms.PictureBox();
            this.prop34 = new System.Windows.Forms.PictureBox();
            this.prop32 = new System.Windows.Forms.PictureBox();
            this.prop31 = new System.Windows.Forms.PictureBox();
            this.prop29 = new System.Windows.Forms.PictureBox();
            this.prop28 = new System.Windows.Forms.PictureBox();
            this.prop27 = new System.Windows.Forms.PictureBox();
            this.prop26 = new System.Windows.Forms.PictureBox();
            this.prop25 = new System.Windows.Forms.PictureBox();
            this.prop24 = new System.Windows.Forms.PictureBox();
            this.prop23 = new System.Windows.Forms.PictureBox();
            this.prop21 = new System.Windows.Forms.PictureBox();
            this.prop19 = new System.Windows.Forms.PictureBox();
            this.prop18 = new System.Windows.Forms.PictureBox();
            this.prop16 = new System.Windows.Forms.PictureBox();
            this.prop15 = new System.Windows.Forms.PictureBox();
            this.prop14 = new System.Windows.Forms.PictureBox();
            this.prop13 = new System.Windows.Forms.PictureBox();
            this.prop12 = new System.Windows.Forms.PictureBox();
            this.prop11 = new System.Windows.Forms.PictureBox();
            this.prop9 = new System.Windows.Forms.PictureBox();
            this.prop8 = new System.Windows.Forms.PictureBox();
            this.prop6 = new System.Windows.Forms.PictureBox();
            this.prop5 = new System.Windows.Forms.PictureBox();
            this.prop3 = new System.Windows.Forms.PictureBox();
            this.prop1 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button4 = new System.Windows.Forms.Button();
            this.C1_04 = new System.Windows.Forms.PictureBox();
            this.C1_01 = new System.Windows.Forms.PictureBox();
            this.C1_03 = new System.Windows.Forms.PictureBox();
            this.C1_02 = new System.Windows.Forms.PictureBox();
            this.C3_02 = new System.Windows.Forms.PictureBox();
            this.C3_03 = new System.Windows.Forms.PictureBox();
            this.C3_01 = new System.Windows.Forms.PictureBox();
            this.C3_04 = new System.Windows.Forms.PictureBox();
            this.C6_02 = new System.Windows.Forms.PictureBox();
            this.C6_03 = new System.Windows.Forms.PictureBox();
            this.C6_01 = new System.Windows.Forms.PictureBox();
            this.C6_04 = new System.Windows.Forms.PictureBox();
            this.C8_02 = new System.Windows.Forms.PictureBox();
            this.C8_03 = new System.Windows.Forms.PictureBox();
            this.C8_01 = new System.Windows.Forms.PictureBox();
            this.C8_04 = new System.Windows.Forms.PictureBox();
            this.C9_02 = new System.Windows.Forms.PictureBox();
            this.C9_03 = new System.Windows.Forms.PictureBox();
            this.C9_01 = new System.Windows.Forms.PictureBox();
            this.C9_04 = new System.Windows.Forms.PictureBox();
            this.C11_04 = new System.Windows.Forms.PictureBox();
            this.C11_02 = new System.Windows.Forms.PictureBox();
            this.C11_03 = new System.Windows.Forms.PictureBox();
            this.C11_01 = new System.Windows.Forms.PictureBox();
            this.C13_04 = new System.Windows.Forms.PictureBox();
            this.C13_02 = new System.Windows.Forms.PictureBox();
            this.C13_03 = new System.Windows.Forms.PictureBox();
            this.C13_01 = new System.Windows.Forms.PictureBox();
            this.C14_04 = new System.Windows.Forms.PictureBox();
            this.C14_02 = new System.Windows.Forms.PictureBox();
            this.C14_03 = new System.Windows.Forms.PictureBox();
            this.C14_01 = new System.Windows.Forms.PictureBox();
            this.C16_04 = new System.Windows.Forms.PictureBox();
            this.C16_02 = new System.Windows.Forms.PictureBox();
            this.C16_03 = new System.Windows.Forms.PictureBox();
            this.C16_01 = new System.Windows.Forms.PictureBox();
            this.C18_04 = new System.Windows.Forms.PictureBox();
            this.C18_02 = new System.Windows.Forms.PictureBox();
            this.C18_03 = new System.Windows.Forms.PictureBox();
            this.C18_01 = new System.Windows.Forms.PictureBox();
            this.C19_04 = new System.Windows.Forms.PictureBox();
            this.C19_02 = new System.Windows.Forms.PictureBox();
            this.C19_03 = new System.Windows.Forms.PictureBox();
            this.C19_01 = new System.Windows.Forms.PictureBox();
            this.C21_04 = new System.Windows.Forms.PictureBox();
            this.C21_02 = new System.Windows.Forms.PictureBox();
            this.C21_03 = new System.Windows.Forms.PictureBox();
            this.C21_01 = new System.Windows.Forms.PictureBox();
            this.C23_04 = new System.Windows.Forms.PictureBox();
            this.C23_02 = new System.Windows.Forms.PictureBox();
            this.C23_03 = new System.Windows.Forms.PictureBox();
            this.C23_01 = new System.Windows.Forms.PictureBox();
            this.C24_04 = new System.Windows.Forms.PictureBox();
            this.C24_02 = new System.Windows.Forms.PictureBox();
            this.C24_03 = new System.Windows.Forms.PictureBox();
            this.C24_01 = new System.Windows.Forms.PictureBox();
            this.C26_04 = new System.Windows.Forms.PictureBox();
            this.C26_02 = new System.Windows.Forms.PictureBox();
            this.C26_03 = new System.Windows.Forms.PictureBox();
            this.C26_01 = new System.Windows.Forms.PictureBox();
            this.C27_04 = new System.Windows.Forms.PictureBox();
            this.C27_02 = new System.Windows.Forms.PictureBox();
            this.C27_03 = new System.Windows.Forms.PictureBox();
            this.C27_01 = new System.Windows.Forms.PictureBox();
            this.C29_04 = new System.Windows.Forms.PictureBox();
            this.C29_02 = new System.Windows.Forms.PictureBox();
            this.C29_03 = new System.Windows.Forms.PictureBox();
            this.C29_01 = new System.Windows.Forms.PictureBox();
            this.C31_02 = new System.Windows.Forms.PictureBox();
            this.C31_04 = new System.Windows.Forms.PictureBox();
            this.C31_01 = new System.Windows.Forms.PictureBox();
            this.C31_03 = new System.Windows.Forms.PictureBox();
            this.C32_02 = new System.Windows.Forms.PictureBox();
            this.C32_04 = new System.Windows.Forms.PictureBox();
            this.C32_01 = new System.Windows.Forms.PictureBox();
            this.C32_03 = new System.Windows.Forms.PictureBox();
            this.C34_02 = new System.Windows.Forms.PictureBox();
            this.C34_04 = new System.Windows.Forms.PictureBox();
            this.C34_01 = new System.Windows.Forms.PictureBox();
            this.C34_03 = new System.Windows.Forms.PictureBox();
            this.C37_02 = new System.Windows.Forms.PictureBox();
            this.C37_04 = new System.Windows.Forms.PictureBox();
            this.C37_01 = new System.Windows.Forms.PictureBox();
            this.C37_03 = new System.Windows.Forms.PictureBox();
            this.C39_02 = new System.Windows.Forms.PictureBox();
            this.C39_04 = new System.Windows.Forms.PictureBox();
            this.C39_01 = new System.Windows.Forms.PictureBox();
            this.C39_03 = new System.Windows.Forms.PictureBox();
            this.H1 = new System.Windows.Forms.PictureBox();
            this.H3 = new System.Windows.Forms.PictureBox();
            this.H6 = new System.Windows.Forms.PictureBox();
            this.H8 = new System.Windows.Forms.PictureBox();
            this.H9 = new System.Windows.Forms.PictureBox();
            this.H11 = new System.Windows.Forms.PictureBox();
            this.H13 = new System.Windows.Forms.PictureBox();
            this.H14 = new System.Windows.Forms.PictureBox();
            this.H16 = new System.Windows.Forms.PictureBox();
            this.H18 = new System.Windows.Forms.PictureBox();
            this.H19 = new System.Windows.Forms.PictureBox();
            this.H21 = new System.Windows.Forms.PictureBox();
            this.H23 = new System.Windows.Forms.PictureBox();
            this.H24 = new System.Windows.Forms.PictureBox();
            this.H26 = new System.Windows.Forms.PictureBox();
            this.H27 = new System.Windows.Forms.PictureBox();
            this.H29 = new System.Windows.Forms.PictureBox();
            this.H31 = new System.Windows.Forms.PictureBox();
            this.H32 = new System.Windows.Forms.PictureBox();
            this.H34 = new System.Windows.Forms.PictureBox();
            this.H37 = new System.Windows.Forms.PictureBox();
            this.H39 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_Color)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_10P)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_10P)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_10P)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_10P)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_10P)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_10P)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_10P)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_10P)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C1_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C1_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C1_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C1_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C8_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C8_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C8_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C8_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C9_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C9_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C9_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C9_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C11_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C11_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C11_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C11_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C13_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C13_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C13_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C13_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C14_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C14_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C14_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C14_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C16_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C16_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C16_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C16_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C18_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C18_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C18_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C18_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C19_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C19_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C19_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C19_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C21_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C21_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C21_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C21_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C23_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C23_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C23_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C23_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C24_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C24_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C24_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C24_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C26_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C26_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C26_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C26_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C27_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C27_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C27_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C27_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C29_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C29_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C29_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C29_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C31_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C31_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C31_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C31_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C32_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C32_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C32_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C32_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C34_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C34_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C34_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C34_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C37_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C37_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C37_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C37_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C39_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C39_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C39_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C39_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H39)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "-";
            // 
            // TerminarTurnoButton
            // 
            this.TerminarTurnoButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.TerminarTurnoButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.TerminarTurnoButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TerminarTurnoButton.ForeColor = System.Drawing.Color.White;
            this.TerminarTurnoButton.Location = new System.Drawing.Point(759, 488);
            this.TerminarTurnoButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TerminarTurnoButton.Name = "TerminarTurnoButton";
            this.TerminarTurnoButton.Size = new System.Drawing.Size(240, 53);
            this.TerminarTurnoButton.TabIndex = 1;
            this.TerminarTurnoButton.Text = "Terminar Turno";
            this.TerminarTurnoButton.UseVisualStyleBackColor = false;
            this.TerminarTurnoButton.Visible = false;
            this.TerminarTurnoButton.Click += new System.EventHandler(this.TerminarTurnoButton_Click);
            // 
            // dadosButton
            // 
            this.dadosButton.BackColor = System.Drawing.Color.Teal;
            this.dadosButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dadosButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dadosButton.ForeColor = System.Drawing.Color.White;
            this.dadosButton.Location = new System.Drawing.Point(16, 17);
            this.dadosButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dadosButton.Name = "dadosButton";
            this.dadosButton.Size = new System.Drawing.Size(184, 30);
            this.dadosButton.TabIndex = 2;
            this.dadosButton.Text = "Lançar Dados";
            this.dadosButton.UseVisualStyleBackColor = false;
            this.dadosButton.Click += new System.EventHandler(this.dadosButton_Click);
            // 
            // dado1label
            // 
            this.dado1label.AutoSize = true;
            this.dado1label.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dado1label.Location = new System.Drawing.Point(62, 57);
            this.dado1label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.dado1label.Name = "dado1label";
            this.dado1label.Size = new System.Drawing.Size(24, 26);
            this.dado1label.TabIndex = 3;
            this.dado1label.Text = "0";
            // 
            // dado2label
            // 
            this.dado2label.AutoSize = true;
            this.dado2label.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dado2label.Location = new System.Drawing.Point(126, 57);
            this.dado2label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.dado2label.Name = "dado2label";
            this.dado2label.Size = new System.Drawing.Size(24, 26);
            this.dado2label.TabIndex = 4;
            this.dado2label.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(300, 20);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Dinheiro:";
            // 
            // dinheiroJogLabel
            // 
            this.dinheiroJogLabel.AutoSize = true;
            this.dinheiroJogLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dinheiroJogLabel.Location = new System.Drawing.Point(374, 15);
            this.dinheiroJogLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.dinheiroJogLabel.Name = "dinheiroJogLabel";
            this.dinheiroJogLabel.Size = new System.Drawing.Size(16, 24);
            this.dinheiroJogLabel.TabIndex = 8;
            this.dinheiroJogLabel.Text = "-";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.dinheiroJogLabel);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox1.Location = new System.Drawing.Point(528, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(471, 81);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Jogador Atual";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(379, 65);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(87, 16);
            this.label21.TabIndex = 63;
            this.label21.Text = "Ronda Nº 1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 52);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 16);
            this.label4.TabIndex = 13;
            this.label4.Text = "label4";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Teal;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(759, 449);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(240, 34);
            this.button1.TabIndex = 12;
            this.button1.Text = "Comprar Propriedade";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox2.Controls.Add(this.dado1label);
            this.groupBox2.Controls.Add(this.dado2label);
            this.groupBox2.Controls.Add(this.dadosButton);
            this.groupBox2.Location = new System.Drawing.Point(528, 449);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(216, 92);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Dados";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(544, 403);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(184, 34);
            this.button2.TabIndex = 14;
            this.button2.Text = "Pague 5.000€ agora ou espere mais %% turnos\r\n";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(16, 24);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(214, 21);
            this.comboBox1.TabIndex = 43;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.PreçoCasa);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.ValorHipot);
            this.groupBox3.Controls.Add(this.HipotecaButton);
            this.groupBox3.Controls.Add(this.BuildButton);
            this.groupBox3.Controls.Add(this.NrHotel);
            this.groupBox3.Controls.Add(this.pictureBox3);
            this.groupBox3.Controls.Add(this.NrCasas);
            this.groupBox3.Controls.Add(this.pictureBox2);
            this.groupBox3.Controls.Add(this.NomeProp);
            this.groupBox3.Controls.Add(this.PB_Color);
            this.groupBox3.Controls.Add(this.comboBox1);
            this.groupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox3.Location = new System.Drawing.Point(528, 96);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Size = new System.Drawing.Size(471, 146);
            this.groupBox3.TabIndex = 44;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Propriedades";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(268, 15);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(195, 117);
            this.label20.TabIndex = 62;
            this.label20.Text = resources.GetString("label20.Text");
            this.label20.Visible = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(302, 76);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(98, 13);
            this.label19.TabIndex = 62;
            this.label19.Text = "Se tem 4 estações:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(302, 61);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(98, 13);
            this.label18.TabIndex = 62;
            this.label18.Text = "Se tem 3 estações:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(302, 46);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(98, 13);
            this.label17.TabIndex = 62;
            this.label17.Text = "Se tem 2 estações:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Enabled = false;
            this.label16.Location = new System.Drawing.Point(302, 30);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(62, 13);
            this.label16.TabIndex = 62;
            this.label16.Text = "ALUGUER:";
            this.label16.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(417, 105);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 13);
            this.label15.TabIndex = 60;
            this.label15.Text = "label15";
            this.label15.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(417, 90);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 13);
            this.label14.TabIndex = 60;
            this.label14.Text = "label14";
            this.label14.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(417, 75);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 13);
            this.label13.TabIndex = 60;
            this.label13.Text = "label13";
            this.label13.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(417, 59);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 13);
            this.label12.TabIndex = 59;
            this.label12.Text = "label12";
            this.label12.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(417, 44);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 58;
            this.label11.Text = "label11";
            this.label11.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(417, 27);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 45;
            this.label10.Text = "label10";
            this.label10.Visible = false;
            // 
            // PreçoCasa
            // 
            this.PreçoCasa.AutoSize = true;
            this.PreçoCasa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PreçoCasa.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.PreçoCasa.Location = new System.Drawing.Point(195, 89);
            this.PreçoCasa.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PreçoCasa.Name = "PreçoCasa";
            this.PreçoCasa.Size = new System.Drawing.Size(16, 16);
            this.PreçoCasa.TabIndex = 57;
            this.PreçoCasa.Text = "0";
            this.PreçoCasa.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(289, 105);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 13);
            this.label9.TabIndex = 56;
            this.label9.Text = "\"         Com HOTEL:";
            this.label9.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(289, 59);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 13);
            this.label8.TabIndex = 55;
            this.label8.Text = "\"         Com 2 Casas:";
            this.label8.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(289, 89);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 13);
            this.label6.TabIndex = 53;
            this.label6.Text = "\"         Com 4 Casas:";
            this.label6.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(289, 44);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 13);
            this.label5.TabIndex = 52;
            this.label5.Text = "\"         Com 1 Casa:";
            this.label5.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(289, 75);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 13);
            this.label7.TabIndex = 54;
            this.label7.Text = "\"         Com 3 Casas:";
            this.label7.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(268, 27);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 13);
            this.label3.TabIndex = 51;
            this.label3.Text = "ALUGUER Só do Terreno:";
            this.label3.Visible = false;
            // 
            // ValorHipot
            // 
            this.ValorHipot.AutoSize = true;
            this.ValorHipot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ValorHipot.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ValorHipot.Location = new System.Drawing.Point(195, 118);
            this.ValorHipot.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ValorHipot.Name = "ValorHipot";
            this.ValorHipot.Size = new System.Drawing.Size(16, 16);
            this.ValorHipot.TabIndex = 45;
            this.ValorHipot.Text = "0";
            this.ValorHipot.Visible = false;
            // 
            // HipotecaButton
            // 
            this.HipotecaButton.BackColor = System.Drawing.Color.Teal;
            this.HipotecaButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.HipotecaButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HipotecaButton.ForeColor = System.Drawing.Color.White;
            this.HipotecaButton.Location = new System.Drawing.Point(75, 115);
            this.HipotecaButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.HipotecaButton.Name = "HipotecaButton";
            this.HipotecaButton.Size = new System.Drawing.Size(116, 24);
            this.HipotecaButton.TabIndex = 50;
            this.HipotecaButton.Text = "Hipotecar";
            this.HipotecaButton.UseVisualStyleBackColor = false;
            this.HipotecaButton.Visible = false;
            this.HipotecaButton.Click += new System.EventHandler(this.HipotecaButton_Click);
            // 
            // BuildButton
            // 
            this.BuildButton.BackColor = System.Drawing.Color.Teal;
            this.BuildButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BuildButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BuildButton.ForeColor = System.Drawing.Color.White;
            this.BuildButton.Location = new System.Drawing.Point(75, 85);
            this.BuildButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BuildButton.Name = "BuildButton";
            this.BuildButton.Size = new System.Drawing.Size(116, 24);
            this.BuildButton.TabIndex = 45;
            this.BuildButton.Text = "Construir";
            this.BuildButton.UseVisualStyleBackColor = false;
            this.BuildButton.Visible = false;
            this.BuildButton.Click += new System.EventHandler(this.BuildButton_Click);
            // 
            // NrHotel
            // 
            this.NrHotel.AutoSize = true;
            this.NrHotel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NrHotel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.NrHotel.Location = new System.Drawing.Point(42, 118);
            this.NrHotel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.NrHotel.Name = "NrHotel";
            this.NrHotel.Size = new System.Drawing.Size(16, 16);
            this.NrHotel.TabIndex = 49;
            this.NrHotel.Text = "0";
            this.NrHotel.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.pictureBox3.Location = new System.Drawing.Point(16, 114);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(22, 20);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 48;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // NrCasas
            // 
            this.NrCasas.AutoSize = true;
            this.NrCasas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NrCasas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.NrCasas.Location = new System.Drawing.Point(42, 93);
            this.NrCasas.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.NrCasas.Name = "NrCasas";
            this.NrCasas.Size = new System.Drawing.Size(16, 16);
            this.NrCasas.TabIndex = 47;
            this.NrCasas.Text = "0";
            this.NrCasas.Visible = false;
            this.NrCasas.Click += new System.EventHandler(this.NrCasas_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.pictureBox2.Location = new System.Drawing.Point(16, 89);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(22, 20);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 46;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // NomeProp
            // 
            this.NomeProp.AutoSize = true;
            this.NomeProp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NomeProp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.NomeProp.Location = new System.Drawing.Point(42, 60);
            this.NomeProp.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.NomeProp.Name = "NomeProp";
            this.NomeProp.Size = new System.Drawing.Size(51, 16);
            this.NomeProp.TabIndex = 14;
            this.NomeProp.Text = "label3";
            this.NomeProp.Visible = false;
            // 
            // PB_Color
            // 
            this.PB_Color.Location = new System.Drawing.Point(16, 56);
            this.PB_Color.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.PB_Color.Name = "PB_Color";
            this.PB_Color.Size = new System.Drawing.Size(22, 20);
            this.PB_Color.TabIndex = 45;
            this.PB_Color.TabStop = false;
            this.PB_Color.Visible = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Teal;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(759, 403);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(240, 34);
            this.button3.TabIndex = 62;
            this.button3.Text = "Trocar com Jogador";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // J8_39
            // 
            this.J8_39.BackColor = System.Drawing.Color.Transparent;
            this.J8_39.Location = new System.Drawing.Point(488, 462);
            this.J8_39.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_39.Name = "J8_39";
            this.J8_39.Size = new System.Drawing.Size(11, 12);
            this.J8_39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_39.TabIndex = 383;
            this.J8_39.TabStop = false;
            this.J8_39.Visible = false;
            // 
            // J7_39
            // 
            this.J7_39.BackColor = System.Drawing.Color.Transparent;
            this.J7_39.Location = new System.Drawing.Point(475, 462);
            this.J7_39.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_39.Name = "J7_39";
            this.J7_39.Size = new System.Drawing.Size(11, 12);
            this.J7_39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_39.TabIndex = 382;
            this.J7_39.TabStop = false;
            this.J7_39.Visible = false;
            // 
            // J6_39
            // 
            this.J6_39.BackColor = System.Drawing.Color.Transparent;
            this.J6_39.Location = new System.Drawing.Point(462, 462);
            this.J6_39.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_39.Name = "J6_39";
            this.J6_39.Size = new System.Drawing.Size(11, 12);
            this.J6_39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_39.TabIndex = 381;
            this.J6_39.TabStop = false;
            this.J6_39.Visible = false;
            // 
            // J5_39
            // 
            this.J5_39.BackColor = System.Drawing.Color.Transparent;
            this.J5_39.Location = new System.Drawing.Point(488, 448);
            this.J5_39.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_39.Name = "J5_39";
            this.J5_39.Size = new System.Drawing.Size(11, 12);
            this.J5_39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_39.TabIndex = 380;
            this.J5_39.TabStop = false;
            this.J5_39.Visible = false;
            // 
            // J4_39
            // 
            this.J4_39.BackColor = System.Drawing.Color.Transparent;
            this.J4_39.Location = new System.Drawing.Point(462, 448);
            this.J4_39.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_39.Name = "J4_39";
            this.J4_39.Size = new System.Drawing.Size(11, 12);
            this.J4_39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_39.TabIndex = 379;
            this.J4_39.TabStop = false;
            this.J4_39.Visible = false;
            // 
            // J3_39
            // 
            this.J3_39.BackColor = System.Drawing.Color.Transparent;
            this.J3_39.Location = new System.Drawing.Point(488, 434);
            this.J3_39.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_39.Name = "J3_39";
            this.J3_39.Size = new System.Drawing.Size(11, 12);
            this.J3_39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_39.TabIndex = 378;
            this.J3_39.TabStop = false;
            this.J3_39.Visible = false;
            // 
            // J2_39
            // 
            this.J2_39.BackColor = System.Drawing.Color.Transparent;
            this.J2_39.Location = new System.Drawing.Point(475, 434);
            this.J2_39.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_39.Name = "J2_39";
            this.J2_39.Size = new System.Drawing.Size(11, 12);
            this.J2_39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_39.TabIndex = 377;
            this.J2_39.TabStop = false;
            this.J2_39.Visible = false;
            // 
            // J1_39
            // 
            this.J1_39.BackColor = System.Drawing.Color.Transparent;
            this.J1_39.Location = new System.Drawing.Point(462, 434);
            this.J1_39.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_39.Name = "J1_39";
            this.J1_39.Size = new System.Drawing.Size(11, 12);
            this.J1_39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_39.TabIndex = 376;
            this.J1_39.TabStop = false;
            this.J1_39.Visible = false;
            // 
            // J8_38
            // 
            this.J8_38.BackColor = System.Drawing.Color.Transparent;
            this.J8_38.Location = new System.Drawing.Point(488, 418);
            this.J8_38.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_38.Name = "J8_38";
            this.J8_38.Size = new System.Drawing.Size(11, 12);
            this.J8_38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_38.TabIndex = 375;
            this.J8_38.TabStop = false;
            this.J8_38.Visible = false;
            // 
            // J7_38
            // 
            this.J7_38.BackColor = System.Drawing.Color.Transparent;
            this.J7_38.Location = new System.Drawing.Point(475, 418);
            this.J7_38.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_38.Name = "J7_38";
            this.J7_38.Size = new System.Drawing.Size(11, 12);
            this.J7_38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_38.TabIndex = 374;
            this.J7_38.TabStop = false;
            this.J7_38.Visible = false;
            // 
            // J6_38
            // 
            this.J6_38.BackColor = System.Drawing.Color.Transparent;
            this.J6_38.Location = new System.Drawing.Point(462, 418);
            this.J6_38.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_38.Name = "J6_38";
            this.J6_38.Size = new System.Drawing.Size(11, 12);
            this.J6_38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_38.TabIndex = 373;
            this.J6_38.TabStop = false;
            this.J6_38.Visible = false;
            // 
            // J5_38
            // 
            this.J5_38.BackColor = System.Drawing.Color.Transparent;
            this.J5_38.Location = new System.Drawing.Point(488, 405);
            this.J5_38.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_38.Name = "J5_38";
            this.J5_38.Size = new System.Drawing.Size(11, 12);
            this.J5_38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_38.TabIndex = 372;
            this.J5_38.TabStop = false;
            this.J5_38.Visible = false;
            // 
            // J4_38
            // 
            this.J4_38.BackColor = System.Drawing.Color.Transparent;
            this.J4_38.Location = new System.Drawing.Point(462, 405);
            this.J4_38.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_38.Name = "J4_38";
            this.J4_38.Size = new System.Drawing.Size(11, 12);
            this.J4_38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_38.TabIndex = 371;
            this.J4_38.TabStop = false;
            this.J4_38.Visible = false;
            // 
            // J3_38
            // 
            this.J3_38.BackColor = System.Drawing.Color.Transparent;
            this.J3_38.Location = new System.Drawing.Point(488, 391);
            this.J3_38.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_38.Name = "J3_38";
            this.J3_38.Size = new System.Drawing.Size(11, 12);
            this.J3_38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_38.TabIndex = 370;
            this.J3_38.TabStop = false;
            this.J3_38.Visible = false;
            // 
            // J2_38
            // 
            this.J2_38.BackColor = System.Drawing.Color.Transparent;
            this.J2_38.Location = new System.Drawing.Point(475, 391);
            this.J2_38.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_38.Name = "J2_38";
            this.J2_38.Size = new System.Drawing.Size(11, 12);
            this.J2_38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_38.TabIndex = 369;
            this.J2_38.TabStop = false;
            this.J2_38.Visible = false;
            // 
            // J1_38
            // 
            this.J1_38.BackColor = System.Drawing.Color.Transparent;
            this.J1_38.Location = new System.Drawing.Point(462, 391);
            this.J1_38.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_38.Name = "J1_38";
            this.J1_38.Size = new System.Drawing.Size(11, 12);
            this.J1_38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_38.TabIndex = 368;
            this.J1_38.TabStop = false;
            this.J1_38.Visible = false;
            // 
            // J8_37
            // 
            this.J8_37.BackColor = System.Drawing.Color.Transparent;
            this.J8_37.Location = new System.Drawing.Point(488, 375);
            this.J8_37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_37.Name = "J8_37";
            this.J8_37.Size = new System.Drawing.Size(11, 12);
            this.J8_37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_37.TabIndex = 367;
            this.J8_37.TabStop = false;
            this.J8_37.Visible = false;
            // 
            // J7_37
            // 
            this.J7_37.BackColor = System.Drawing.Color.Transparent;
            this.J7_37.Location = new System.Drawing.Point(475, 375);
            this.J7_37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_37.Name = "J7_37";
            this.J7_37.Size = new System.Drawing.Size(11, 12);
            this.J7_37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_37.TabIndex = 366;
            this.J7_37.TabStop = false;
            this.J7_37.Visible = false;
            // 
            // J6_37
            // 
            this.J6_37.BackColor = System.Drawing.Color.Transparent;
            this.J6_37.Location = new System.Drawing.Point(462, 375);
            this.J6_37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_37.Name = "J6_37";
            this.J6_37.Size = new System.Drawing.Size(11, 12);
            this.J6_37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_37.TabIndex = 365;
            this.J6_37.TabStop = false;
            this.J6_37.Visible = false;
            // 
            // J5_37
            // 
            this.J5_37.BackColor = System.Drawing.Color.Transparent;
            this.J5_37.Location = new System.Drawing.Point(488, 361);
            this.J5_37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_37.Name = "J5_37";
            this.J5_37.Size = new System.Drawing.Size(11, 12);
            this.J5_37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_37.TabIndex = 364;
            this.J5_37.TabStop = false;
            this.J5_37.Visible = false;
            // 
            // J4_37
            // 
            this.J4_37.BackColor = System.Drawing.Color.Transparent;
            this.J4_37.Location = new System.Drawing.Point(462, 361);
            this.J4_37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_37.Name = "J4_37";
            this.J4_37.Size = new System.Drawing.Size(11, 12);
            this.J4_37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_37.TabIndex = 363;
            this.J4_37.TabStop = false;
            this.J4_37.Visible = false;
            // 
            // J3_37
            // 
            this.J3_37.BackColor = System.Drawing.Color.Transparent;
            this.J3_37.Location = new System.Drawing.Point(488, 347);
            this.J3_37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_37.Name = "J3_37";
            this.J3_37.Size = new System.Drawing.Size(11, 12);
            this.J3_37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_37.TabIndex = 362;
            this.J3_37.TabStop = false;
            this.J3_37.Visible = false;
            // 
            // J2_37
            // 
            this.J2_37.BackColor = System.Drawing.Color.Transparent;
            this.J2_37.Location = new System.Drawing.Point(475, 347);
            this.J2_37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_37.Name = "J2_37";
            this.J2_37.Size = new System.Drawing.Size(11, 12);
            this.J2_37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_37.TabIndex = 361;
            this.J2_37.TabStop = false;
            this.J2_37.Visible = false;
            // 
            // J1_37
            // 
            this.J1_37.BackColor = System.Drawing.Color.Transparent;
            this.J1_37.Location = new System.Drawing.Point(462, 347);
            this.J1_37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_37.Name = "J1_37";
            this.J1_37.Size = new System.Drawing.Size(11, 12);
            this.J1_37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_37.TabIndex = 360;
            this.J1_37.TabStop = false;
            this.J1_37.Visible = false;
            // 
            // J8_36
            // 
            this.J8_36.BackColor = System.Drawing.Color.Transparent;
            this.J8_36.Location = new System.Drawing.Point(488, 331);
            this.J8_36.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_36.Name = "J8_36";
            this.J8_36.Size = new System.Drawing.Size(11, 12);
            this.J8_36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_36.TabIndex = 359;
            this.J8_36.TabStop = false;
            this.J8_36.Visible = false;
            // 
            // J7_36
            // 
            this.J7_36.BackColor = System.Drawing.Color.Transparent;
            this.J7_36.Location = new System.Drawing.Point(475, 331);
            this.J7_36.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_36.Name = "J7_36";
            this.J7_36.Size = new System.Drawing.Size(11, 12);
            this.J7_36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_36.TabIndex = 358;
            this.J7_36.TabStop = false;
            this.J7_36.Visible = false;
            // 
            // J6_36
            // 
            this.J6_36.BackColor = System.Drawing.Color.Transparent;
            this.J6_36.Location = new System.Drawing.Point(462, 331);
            this.J6_36.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_36.Name = "J6_36";
            this.J6_36.Size = new System.Drawing.Size(11, 12);
            this.J6_36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_36.TabIndex = 357;
            this.J6_36.TabStop = false;
            this.J6_36.Visible = false;
            // 
            // J5_36
            // 
            this.J5_36.BackColor = System.Drawing.Color.Transparent;
            this.J5_36.Location = new System.Drawing.Point(488, 317);
            this.J5_36.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_36.Name = "J5_36";
            this.J5_36.Size = new System.Drawing.Size(11, 12);
            this.J5_36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_36.TabIndex = 356;
            this.J5_36.TabStop = false;
            this.J5_36.Visible = false;
            // 
            // J4_36
            // 
            this.J4_36.BackColor = System.Drawing.Color.Transparent;
            this.J4_36.Location = new System.Drawing.Point(462, 317);
            this.J4_36.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_36.Name = "J4_36";
            this.J4_36.Size = new System.Drawing.Size(11, 12);
            this.J4_36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_36.TabIndex = 355;
            this.J4_36.TabStop = false;
            this.J4_36.Visible = false;
            // 
            // J3_36
            // 
            this.J3_36.BackColor = System.Drawing.Color.Transparent;
            this.J3_36.Location = new System.Drawing.Point(488, 303);
            this.J3_36.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_36.Name = "J3_36";
            this.J3_36.Size = new System.Drawing.Size(11, 12);
            this.J3_36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_36.TabIndex = 354;
            this.J3_36.TabStop = false;
            this.J3_36.Visible = false;
            // 
            // J2_36
            // 
            this.J2_36.BackColor = System.Drawing.Color.Transparent;
            this.J2_36.Location = new System.Drawing.Point(475, 303);
            this.J2_36.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_36.Name = "J2_36";
            this.J2_36.Size = new System.Drawing.Size(11, 12);
            this.J2_36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_36.TabIndex = 353;
            this.J2_36.TabStop = false;
            this.J2_36.Visible = false;
            // 
            // J1_36
            // 
            this.J1_36.BackColor = System.Drawing.Color.Transparent;
            this.J1_36.Location = new System.Drawing.Point(462, 303);
            this.J1_36.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_36.Name = "J1_36";
            this.J1_36.Size = new System.Drawing.Size(11, 12);
            this.J1_36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_36.TabIndex = 352;
            this.J1_36.TabStop = false;
            this.J1_36.Visible = false;
            // 
            // J8_35
            // 
            this.J8_35.BackColor = System.Drawing.Color.Transparent;
            this.J8_35.Location = new System.Drawing.Point(488, 287);
            this.J8_35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_35.Name = "J8_35";
            this.J8_35.Size = new System.Drawing.Size(11, 12);
            this.J8_35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_35.TabIndex = 351;
            this.J8_35.TabStop = false;
            this.J8_35.Visible = false;
            // 
            // J7_35
            // 
            this.J7_35.BackColor = System.Drawing.Color.Transparent;
            this.J7_35.Location = new System.Drawing.Point(475, 287);
            this.J7_35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_35.Name = "J7_35";
            this.J7_35.Size = new System.Drawing.Size(11, 12);
            this.J7_35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_35.TabIndex = 350;
            this.J7_35.TabStop = false;
            this.J7_35.Visible = false;
            // 
            // J6_35
            // 
            this.J6_35.BackColor = System.Drawing.Color.Transparent;
            this.J6_35.Location = new System.Drawing.Point(462, 287);
            this.J6_35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_35.Name = "J6_35";
            this.J6_35.Size = new System.Drawing.Size(11, 12);
            this.J6_35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_35.TabIndex = 349;
            this.J6_35.TabStop = false;
            this.J6_35.Visible = false;
            // 
            // J5_35
            // 
            this.J5_35.BackColor = System.Drawing.Color.Transparent;
            this.J5_35.Location = new System.Drawing.Point(488, 273);
            this.J5_35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_35.Name = "J5_35";
            this.J5_35.Size = new System.Drawing.Size(11, 12);
            this.J5_35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_35.TabIndex = 348;
            this.J5_35.TabStop = false;
            this.J5_35.Visible = false;
            // 
            // J4_35
            // 
            this.J4_35.BackColor = System.Drawing.Color.Transparent;
            this.J4_35.Location = new System.Drawing.Point(462, 273);
            this.J4_35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_35.Name = "J4_35";
            this.J4_35.Size = new System.Drawing.Size(11, 12);
            this.J4_35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_35.TabIndex = 347;
            this.J4_35.TabStop = false;
            this.J4_35.Visible = false;
            // 
            // J3_35
            // 
            this.J3_35.BackColor = System.Drawing.Color.Transparent;
            this.J3_35.Location = new System.Drawing.Point(488, 259);
            this.J3_35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_35.Name = "J3_35";
            this.J3_35.Size = new System.Drawing.Size(11, 12);
            this.J3_35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_35.TabIndex = 346;
            this.J3_35.TabStop = false;
            this.J3_35.Visible = false;
            // 
            // J2_35
            // 
            this.J2_35.BackColor = System.Drawing.Color.Transparent;
            this.J2_35.Location = new System.Drawing.Point(475, 259);
            this.J2_35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_35.Name = "J2_35";
            this.J2_35.Size = new System.Drawing.Size(11, 12);
            this.J2_35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_35.TabIndex = 345;
            this.J2_35.TabStop = false;
            this.J2_35.Visible = false;
            // 
            // J1_35
            // 
            this.J1_35.BackColor = System.Drawing.Color.Transparent;
            this.J1_35.Location = new System.Drawing.Point(462, 259);
            this.J1_35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_35.Name = "J1_35";
            this.J1_35.Size = new System.Drawing.Size(11, 12);
            this.J1_35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_35.TabIndex = 344;
            this.J1_35.TabStop = false;
            this.J1_35.Visible = false;
            // 
            // J8_34
            // 
            this.J8_34.BackColor = System.Drawing.Color.Transparent;
            this.J8_34.Location = new System.Drawing.Point(488, 242);
            this.J8_34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_34.Name = "J8_34";
            this.J8_34.Size = new System.Drawing.Size(11, 12);
            this.J8_34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_34.TabIndex = 343;
            this.J8_34.TabStop = false;
            this.J8_34.Visible = false;
            // 
            // J7_34
            // 
            this.J7_34.BackColor = System.Drawing.Color.Transparent;
            this.J7_34.Location = new System.Drawing.Point(475, 242);
            this.J7_34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_34.Name = "J7_34";
            this.J7_34.Size = new System.Drawing.Size(11, 12);
            this.J7_34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_34.TabIndex = 342;
            this.J7_34.TabStop = false;
            this.J7_34.Visible = false;
            // 
            // J6_34
            // 
            this.J6_34.BackColor = System.Drawing.Color.Transparent;
            this.J6_34.Location = new System.Drawing.Point(462, 242);
            this.J6_34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_34.Name = "J6_34";
            this.J6_34.Size = new System.Drawing.Size(11, 12);
            this.J6_34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_34.TabIndex = 341;
            this.J6_34.TabStop = false;
            this.J6_34.Visible = false;
            // 
            // J5_34
            // 
            this.J5_34.BackColor = System.Drawing.Color.Transparent;
            this.J5_34.Location = new System.Drawing.Point(488, 228);
            this.J5_34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_34.Name = "J5_34";
            this.J5_34.Size = new System.Drawing.Size(11, 12);
            this.J5_34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_34.TabIndex = 340;
            this.J5_34.TabStop = false;
            this.J5_34.Visible = false;
            // 
            // J4_34
            // 
            this.J4_34.BackColor = System.Drawing.Color.Transparent;
            this.J4_34.Location = new System.Drawing.Point(462, 228);
            this.J4_34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_34.Name = "J4_34";
            this.J4_34.Size = new System.Drawing.Size(11, 12);
            this.J4_34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_34.TabIndex = 339;
            this.J4_34.TabStop = false;
            this.J4_34.Visible = false;
            // 
            // J3_34
            // 
            this.J3_34.BackColor = System.Drawing.Color.Transparent;
            this.J3_34.Location = new System.Drawing.Point(488, 214);
            this.J3_34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_34.Name = "J3_34";
            this.J3_34.Size = new System.Drawing.Size(11, 12);
            this.J3_34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_34.TabIndex = 338;
            this.J3_34.TabStop = false;
            this.J3_34.Visible = false;
            // 
            // J2_34
            // 
            this.J2_34.BackColor = System.Drawing.Color.Transparent;
            this.J2_34.Location = new System.Drawing.Point(475, 214);
            this.J2_34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_34.Name = "J2_34";
            this.J2_34.Size = new System.Drawing.Size(11, 12);
            this.J2_34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_34.TabIndex = 337;
            this.J2_34.TabStop = false;
            this.J2_34.Visible = false;
            // 
            // J1_34
            // 
            this.J1_34.BackColor = System.Drawing.Color.Transparent;
            this.J1_34.Location = new System.Drawing.Point(462, 214);
            this.J1_34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_34.Name = "J1_34";
            this.J1_34.Size = new System.Drawing.Size(11, 12);
            this.J1_34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_34.TabIndex = 336;
            this.J1_34.TabStop = false;
            this.J1_34.Visible = false;
            // 
            // J8_33
            // 
            this.J8_33.BackColor = System.Drawing.Color.Transparent;
            this.J8_33.Location = new System.Drawing.Point(488, 198);
            this.J8_33.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_33.Name = "J8_33";
            this.J8_33.Size = new System.Drawing.Size(11, 12);
            this.J8_33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_33.TabIndex = 335;
            this.J8_33.TabStop = false;
            this.J8_33.Visible = false;
            // 
            // J7_33
            // 
            this.J7_33.BackColor = System.Drawing.Color.Transparent;
            this.J7_33.Location = new System.Drawing.Point(475, 198);
            this.J7_33.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_33.Name = "J7_33";
            this.J7_33.Size = new System.Drawing.Size(11, 12);
            this.J7_33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_33.TabIndex = 334;
            this.J7_33.TabStop = false;
            this.J7_33.Visible = false;
            // 
            // J6_33
            // 
            this.J6_33.BackColor = System.Drawing.Color.Transparent;
            this.J6_33.Location = new System.Drawing.Point(462, 198);
            this.J6_33.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_33.Name = "J6_33";
            this.J6_33.Size = new System.Drawing.Size(11, 12);
            this.J6_33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_33.TabIndex = 333;
            this.J6_33.TabStop = false;
            this.J6_33.Visible = false;
            // 
            // J5_33
            // 
            this.J5_33.BackColor = System.Drawing.Color.Transparent;
            this.J5_33.Location = new System.Drawing.Point(488, 184);
            this.J5_33.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_33.Name = "J5_33";
            this.J5_33.Size = new System.Drawing.Size(11, 12);
            this.J5_33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_33.TabIndex = 332;
            this.J5_33.TabStop = false;
            this.J5_33.Visible = false;
            // 
            // J4_33
            // 
            this.J4_33.BackColor = System.Drawing.Color.Transparent;
            this.J4_33.Location = new System.Drawing.Point(462, 184);
            this.J4_33.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_33.Name = "J4_33";
            this.J4_33.Size = new System.Drawing.Size(11, 12);
            this.J4_33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_33.TabIndex = 331;
            this.J4_33.TabStop = false;
            this.J4_33.Visible = false;
            // 
            // J3_33
            // 
            this.J3_33.BackColor = System.Drawing.Color.Transparent;
            this.J3_33.Location = new System.Drawing.Point(488, 171);
            this.J3_33.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_33.Name = "J3_33";
            this.J3_33.Size = new System.Drawing.Size(11, 12);
            this.J3_33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_33.TabIndex = 330;
            this.J3_33.TabStop = false;
            this.J3_33.Visible = false;
            // 
            // J2_33
            // 
            this.J2_33.BackColor = System.Drawing.Color.Transparent;
            this.J2_33.Location = new System.Drawing.Point(475, 171);
            this.J2_33.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_33.Name = "J2_33";
            this.J2_33.Size = new System.Drawing.Size(11, 12);
            this.J2_33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_33.TabIndex = 329;
            this.J2_33.TabStop = false;
            this.J2_33.Visible = false;
            // 
            // J1_33
            // 
            this.J1_33.BackColor = System.Drawing.Color.Transparent;
            this.J1_33.Location = new System.Drawing.Point(462, 171);
            this.J1_33.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_33.Name = "J1_33";
            this.J1_33.Size = new System.Drawing.Size(11, 12);
            this.J1_33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_33.TabIndex = 328;
            this.J1_33.TabStop = false;
            this.J1_33.Visible = false;
            // 
            // J8_32
            // 
            this.J8_32.BackColor = System.Drawing.Color.Transparent;
            this.J8_32.Location = new System.Drawing.Point(488, 154);
            this.J8_32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_32.Name = "J8_32";
            this.J8_32.Size = new System.Drawing.Size(11, 12);
            this.J8_32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_32.TabIndex = 327;
            this.J8_32.TabStop = false;
            this.J8_32.Visible = false;
            // 
            // J7_32
            // 
            this.J7_32.BackColor = System.Drawing.Color.Transparent;
            this.J7_32.Location = new System.Drawing.Point(475, 154);
            this.J7_32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_32.Name = "J7_32";
            this.J7_32.Size = new System.Drawing.Size(11, 12);
            this.J7_32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_32.TabIndex = 326;
            this.J7_32.TabStop = false;
            this.J7_32.Visible = false;
            // 
            // J6_32
            // 
            this.J6_32.BackColor = System.Drawing.Color.Transparent;
            this.J6_32.Location = new System.Drawing.Point(462, 154);
            this.J6_32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_32.Name = "J6_32";
            this.J6_32.Size = new System.Drawing.Size(11, 12);
            this.J6_32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_32.TabIndex = 325;
            this.J6_32.TabStop = false;
            this.J6_32.Visible = false;
            // 
            // J5_32
            // 
            this.J5_32.BackColor = System.Drawing.Color.Transparent;
            this.J5_32.Location = new System.Drawing.Point(488, 141);
            this.J5_32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_32.Name = "J5_32";
            this.J5_32.Size = new System.Drawing.Size(11, 12);
            this.J5_32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_32.TabIndex = 324;
            this.J5_32.TabStop = false;
            this.J5_32.Visible = false;
            // 
            // J4_32
            // 
            this.J4_32.BackColor = System.Drawing.Color.Transparent;
            this.J4_32.Location = new System.Drawing.Point(462, 141);
            this.J4_32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_32.Name = "J4_32";
            this.J4_32.Size = new System.Drawing.Size(11, 12);
            this.J4_32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_32.TabIndex = 323;
            this.J4_32.TabStop = false;
            this.J4_32.Visible = false;
            // 
            // J3_32
            // 
            this.J3_32.BackColor = System.Drawing.Color.Transparent;
            this.J3_32.Location = new System.Drawing.Point(488, 127);
            this.J3_32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_32.Name = "J3_32";
            this.J3_32.Size = new System.Drawing.Size(11, 12);
            this.J3_32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_32.TabIndex = 322;
            this.J3_32.TabStop = false;
            this.J3_32.Visible = false;
            // 
            // J2_32
            // 
            this.J2_32.BackColor = System.Drawing.Color.Transparent;
            this.J2_32.Location = new System.Drawing.Point(475, 127);
            this.J2_32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_32.Name = "J2_32";
            this.J2_32.Size = new System.Drawing.Size(11, 12);
            this.J2_32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_32.TabIndex = 321;
            this.J2_32.TabStop = false;
            this.J2_32.Visible = false;
            // 
            // J1_32
            // 
            this.J1_32.BackColor = System.Drawing.Color.Transparent;
            this.J1_32.Location = new System.Drawing.Point(462, 127);
            this.J1_32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_32.Name = "J1_32";
            this.J1_32.Size = new System.Drawing.Size(11, 12);
            this.J1_32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_32.TabIndex = 320;
            this.J1_32.TabStop = false;
            this.J1_32.Visible = false;
            // 
            // J8_31
            // 
            this.J8_31.BackColor = System.Drawing.Color.Transparent;
            this.J8_31.Location = new System.Drawing.Point(488, 110);
            this.J8_31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_31.Name = "J8_31";
            this.J8_31.Size = new System.Drawing.Size(11, 12);
            this.J8_31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_31.TabIndex = 319;
            this.J8_31.TabStop = false;
            this.J8_31.Visible = false;
            // 
            // J7_31
            // 
            this.J7_31.BackColor = System.Drawing.Color.Transparent;
            this.J7_31.Location = new System.Drawing.Point(475, 110);
            this.J7_31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_31.Name = "J7_31";
            this.J7_31.Size = new System.Drawing.Size(11, 12);
            this.J7_31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_31.TabIndex = 318;
            this.J7_31.TabStop = false;
            this.J7_31.Visible = false;
            // 
            // J6_31
            // 
            this.J6_31.BackColor = System.Drawing.Color.Transparent;
            this.J6_31.Location = new System.Drawing.Point(462, 110);
            this.J6_31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_31.Name = "J6_31";
            this.J6_31.Size = new System.Drawing.Size(11, 12);
            this.J6_31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_31.TabIndex = 317;
            this.J6_31.TabStop = false;
            this.J6_31.Visible = false;
            // 
            // J5_31
            // 
            this.J5_31.BackColor = System.Drawing.Color.Transparent;
            this.J5_31.Location = new System.Drawing.Point(488, 97);
            this.J5_31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_31.Name = "J5_31";
            this.J5_31.Size = new System.Drawing.Size(11, 12);
            this.J5_31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_31.TabIndex = 316;
            this.J5_31.TabStop = false;
            this.J5_31.Visible = false;
            // 
            // J4_31
            // 
            this.J4_31.BackColor = System.Drawing.Color.Transparent;
            this.J4_31.Location = new System.Drawing.Point(462, 97);
            this.J4_31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_31.Name = "J4_31";
            this.J4_31.Size = new System.Drawing.Size(11, 12);
            this.J4_31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_31.TabIndex = 315;
            this.J4_31.TabStop = false;
            this.J4_31.Visible = false;
            // 
            // J3_31
            // 
            this.J3_31.BackColor = System.Drawing.Color.Transparent;
            this.J3_31.Location = new System.Drawing.Point(488, 83);
            this.J3_31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_31.Name = "J3_31";
            this.J3_31.Size = new System.Drawing.Size(11, 12);
            this.J3_31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_31.TabIndex = 314;
            this.J3_31.TabStop = false;
            this.J3_31.Visible = false;
            // 
            // J2_31
            // 
            this.J2_31.BackColor = System.Drawing.Color.Transparent;
            this.J2_31.Location = new System.Drawing.Point(475, 83);
            this.J2_31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_31.Name = "J2_31";
            this.J2_31.Size = new System.Drawing.Size(11, 12);
            this.J2_31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_31.TabIndex = 313;
            this.J2_31.TabStop = false;
            this.J2_31.Visible = false;
            // 
            // J1_31
            // 
            this.J1_31.BackColor = System.Drawing.Color.Transparent;
            this.J1_31.Location = new System.Drawing.Point(462, 83);
            this.J1_31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_31.Name = "J1_31";
            this.J1_31.Size = new System.Drawing.Size(11, 12);
            this.J1_31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_31.TabIndex = 312;
            this.J1_31.TabStop = false;
            this.J1_31.Visible = false;
            // 
            // J8_29
            // 
            this.J8_29.BackColor = System.Drawing.Color.Transparent;
            this.J8_29.Location = new System.Drawing.Point(430, 48);
            this.J8_29.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_29.Name = "J8_29";
            this.J8_29.Size = new System.Drawing.Size(11, 12);
            this.J8_29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_29.TabIndex = 311;
            this.J8_29.TabStop = false;
            this.J8_29.Visible = false;
            // 
            // J7_29
            // 
            this.J7_29.BackColor = System.Drawing.Color.Transparent;
            this.J7_29.Location = new System.Drawing.Point(418, 48);
            this.J7_29.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_29.Name = "J7_29";
            this.J7_29.Size = new System.Drawing.Size(11, 12);
            this.J7_29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_29.TabIndex = 310;
            this.J7_29.TabStop = false;
            this.J7_29.Visible = false;
            // 
            // J6_29
            // 
            this.J6_29.BackColor = System.Drawing.Color.Transparent;
            this.J6_29.Location = new System.Drawing.Point(405, 48);
            this.J6_29.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_29.Name = "J6_29";
            this.J6_29.Size = new System.Drawing.Size(11, 12);
            this.J6_29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_29.TabIndex = 309;
            this.J6_29.TabStop = false;
            this.J6_29.Visible = false;
            // 
            // J5_29
            // 
            this.J5_29.BackColor = System.Drawing.Color.Transparent;
            this.J5_29.Location = new System.Drawing.Point(430, 34);
            this.J5_29.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_29.Name = "J5_29";
            this.J5_29.Size = new System.Drawing.Size(11, 12);
            this.J5_29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_29.TabIndex = 308;
            this.J5_29.TabStop = false;
            this.J5_29.Visible = false;
            // 
            // J4_29
            // 
            this.J4_29.BackColor = System.Drawing.Color.Transparent;
            this.J4_29.Location = new System.Drawing.Point(405, 34);
            this.J4_29.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_29.Name = "J4_29";
            this.J4_29.Size = new System.Drawing.Size(11, 12);
            this.J4_29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_29.TabIndex = 307;
            this.J4_29.TabStop = false;
            this.J4_29.Visible = false;
            // 
            // J3_29
            // 
            this.J3_29.BackColor = System.Drawing.Color.Transparent;
            this.J3_29.Location = new System.Drawing.Point(430, 20);
            this.J3_29.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_29.Name = "J3_29";
            this.J3_29.Size = new System.Drawing.Size(11, 12);
            this.J3_29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_29.TabIndex = 306;
            this.J3_29.TabStop = false;
            this.J3_29.Visible = false;
            // 
            // J2_29
            // 
            this.J2_29.BackColor = System.Drawing.Color.Transparent;
            this.J2_29.Location = new System.Drawing.Point(418, 20);
            this.J2_29.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_29.Name = "J2_29";
            this.J2_29.Size = new System.Drawing.Size(11, 12);
            this.J2_29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_29.TabIndex = 305;
            this.J2_29.TabStop = false;
            this.J2_29.Visible = false;
            // 
            // J1_29
            // 
            this.J1_29.BackColor = System.Drawing.Color.Transparent;
            this.J1_29.Location = new System.Drawing.Point(405, 20);
            this.J1_29.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_29.Name = "J1_29";
            this.J1_29.Size = new System.Drawing.Size(11, 12);
            this.J1_29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_29.TabIndex = 304;
            this.J1_29.TabStop = false;
            this.J1_29.Visible = false;
            // 
            // J8_28
            // 
            this.J8_28.BackColor = System.Drawing.Color.Transparent;
            this.J8_28.Location = new System.Drawing.Point(390, 48);
            this.J8_28.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_28.Name = "J8_28";
            this.J8_28.Size = new System.Drawing.Size(11, 12);
            this.J8_28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_28.TabIndex = 303;
            this.J8_28.TabStop = false;
            this.J8_28.Visible = false;
            // 
            // J7_28
            // 
            this.J7_28.BackColor = System.Drawing.Color.Transparent;
            this.J7_28.Location = new System.Drawing.Point(377, 48);
            this.J7_28.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_28.Name = "J7_28";
            this.J7_28.Size = new System.Drawing.Size(11, 12);
            this.J7_28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_28.TabIndex = 302;
            this.J7_28.TabStop = false;
            this.J7_28.Visible = false;
            // 
            // J6_28
            // 
            this.J6_28.BackColor = System.Drawing.Color.Transparent;
            this.J6_28.Location = new System.Drawing.Point(364, 48);
            this.J6_28.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_28.Name = "J6_28";
            this.J6_28.Size = new System.Drawing.Size(11, 12);
            this.J6_28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_28.TabIndex = 301;
            this.J6_28.TabStop = false;
            this.J6_28.Visible = false;
            // 
            // J5_28
            // 
            this.J5_28.BackColor = System.Drawing.Color.Transparent;
            this.J5_28.Location = new System.Drawing.Point(390, 34);
            this.J5_28.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_28.Name = "J5_28";
            this.J5_28.Size = new System.Drawing.Size(11, 12);
            this.J5_28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_28.TabIndex = 300;
            this.J5_28.TabStop = false;
            this.J5_28.Visible = false;
            // 
            // J4_28
            // 
            this.J4_28.BackColor = System.Drawing.Color.Transparent;
            this.J4_28.Location = new System.Drawing.Point(364, 34);
            this.J4_28.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_28.Name = "J4_28";
            this.J4_28.Size = new System.Drawing.Size(11, 12);
            this.J4_28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_28.TabIndex = 299;
            this.J4_28.TabStop = false;
            this.J4_28.Visible = false;
            // 
            // J3_28
            // 
            this.J3_28.BackColor = System.Drawing.Color.Transparent;
            this.J3_28.Location = new System.Drawing.Point(390, 20);
            this.J3_28.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_28.Name = "J3_28";
            this.J3_28.Size = new System.Drawing.Size(11, 12);
            this.J3_28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_28.TabIndex = 298;
            this.J3_28.TabStop = false;
            this.J3_28.Visible = false;
            // 
            // J2_28
            // 
            this.J2_28.BackColor = System.Drawing.Color.Transparent;
            this.J2_28.Location = new System.Drawing.Point(377, 20);
            this.J2_28.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_28.Name = "J2_28";
            this.J2_28.Size = new System.Drawing.Size(11, 12);
            this.J2_28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_28.TabIndex = 297;
            this.J2_28.TabStop = false;
            this.J2_28.Visible = false;
            // 
            // J1_28
            // 
            this.J1_28.BackColor = System.Drawing.Color.Transparent;
            this.J1_28.Location = new System.Drawing.Point(364, 20);
            this.J1_28.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_28.Name = "J1_28";
            this.J1_28.Size = new System.Drawing.Size(11, 12);
            this.J1_28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_28.TabIndex = 296;
            this.J1_28.TabStop = false;
            this.J1_28.Visible = false;
            // 
            // J8_27
            // 
            this.J8_27.BackColor = System.Drawing.Color.Transparent;
            this.J8_27.Location = new System.Drawing.Point(349, 48);
            this.J8_27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_27.Name = "J8_27";
            this.J8_27.Size = new System.Drawing.Size(11, 12);
            this.J8_27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_27.TabIndex = 295;
            this.J8_27.TabStop = false;
            this.J8_27.Visible = false;
            // 
            // J7_27
            // 
            this.J7_27.BackColor = System.Drawing.Color.Transparent;
            this.J7_27.Location = new System.Drawing.Point(336, 48);
            this.J7_27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_27.Name = "J7_27";
            this.J7_27.Size = new System.Drawing.Size(11, 12);
            this.J7_27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_27.TabIndex = 294;
            this.J7_27.TabStop = false;
            this.J7_27.Visible = false;
            // 
            // J6_27
            // 
            this.J6_27.BackColor = System.Drawing.Color.Transparent;
            this.J6_27.Location = new System.Drawing.Point(323, 48);
            this.J6_27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_27.Name = "J6_27";
            this.J6_27.Size = new System.Drawing.Size(11, 12);
            this.J6_27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_27.TabIndex = 293;
            this.J6_27.TabStop = false;
            this.J6_27.Visible = false;
            // 
            // J5_27
            // 
            this.J5_27.BackColor = System.Drawing.Color.Transparent;
            this.J5_27.Location = new System.Drawing.Point(349, 34);
            this.J5_27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_27.Name = "J5_27";
            this.J5_27.Size = new System.Drawing.Size(11, 12);
            this.J5_27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_27.TabIndex = 292;
            this.J5_27.TabStop = false;
            this.J5_27.Visible = false;
            // 
            // J4_27
            // 
            this.J4_27.BackColor = System.Drawing.Color.Transparent;
            this.J4_27.Location = new System.Drawing.Point(323, 34);
            this.J4_27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_27.Name = "J4_27";
            this.J4_27.Size = new System.Drawing.Size(11, 12);
            this.J4_27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_27.TabIndex = 291;
            this.J4_27.TabStop = false;
            this.J4_27.Visible = false;
            // 
            // J3_27
            // 
            this.J3_27.BackColor = System.Drawing.Color.Transparent;
            this.J3_27.Location = new System.Drawing.Point(349, 20);
            this.J3_27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_27.Name = "J3_27";
            this.J3_27.Size = new System.Drawing.Size(11, 12);
            this.J3_27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_27.TabIndex = 290;
            this.J3_27.TabStop = false;
            this.J3_27.Visible = false;
            // 
            // J2_27
            // 
            this.J2_27.BackColor = System.Drawing.Color.Transparent;
            this.J2_27.Location = new System.Drawing.Point(336, 20);
            this.J2_27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_27.Name = "J2_27";
            this.J2_27.Size = new System.Drawing.Size(11, 12);
            this.J2_27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_27.TabIndex = 289;
            this.J2_27.TabStop = false;
            this.J2_27.Visible = false;
            // 
            // J1_27
            // 
            this.J1_27.BackColor = System.Drawing.Color.Transparent;
            this.J1_27.Location = new System.Drawing.Point(323, 20);
            this.J1_27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_27.Name = "J1_27";
            this.J1_27.Size = new System.Drawing.Size(11, 12);
            this.J1_27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_27.TabIndex = 288;
            this.J1_27.TabStop = false;
            this.J1_27.Visible = false;
            // 
            // J8_26
            // 
            this.J8_26.BackColor = System.Drawing.Color.Transparent;
            this.J8_26.Location = new System.Drawing.Point(308, 48);
            this.J8_26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_26.Name = "J8_26";
            this.J8_26.Size = new System.Drawing.Size(11, 12);
            this.J8_26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_26.TabIndex = 287;
            this.J8_26.TabStop = false;
            this.J8_26.Visible = false;
            // 
            // J7_26
            // 
            this.J7_26.BackColor = System.Drawing.Color.Transparent;
            this.J7_26.Location = new System.Drawing.Point(296, 48);
            this.J7_26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_26.Name = "J7_26";
            this.J7_26.Size = new System.Drawing.Size(11, 12);
            this.J7_26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_26.TabIndex = 286;
            this.J7_26.TabStop = false;
            this.J7_26.Visible = false;
            // 
            // J6_26
            // 
            this.J6_26.BackColor = System.Drawing.Color.Transparent;
            this.J6_26.Location = new System.Drawing.Point(283, 48);
            this.J6_26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_26.Name = "J6_26";
            this.J6_26.Size = new System.Drawing.Size(11, 12);
            this.J6_26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_26.TabIndex = 285;
            this.J6_26.TabStop = false;
            this.J6_26.Visible = false;
            // 
            // J5_26
            // 
            this.J5_26.BackColor = System.Drawing.Color.Transparent;
            this.J5_26.Location = new System.Drawing.Point(308, 34);
            this.J5_26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_26.Name = "J5_26";
            this.J5_26.Size = new System.Drawing.Size(11, 12);
            this.J5_26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_26.TabIndex = 284;
            this.J5_26.TabStop = false;
            this.J5_26.Visible = false;
            // 
            // J4_26
            // 
            this.J4_26.BackColor = System.Drawing.Color.Transparent;
            this.J4_26.Location = new System.Drawing.Point(283, 34);
            this.J4_26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_26.Name = "J4_26";
            this.J4_26.Size = new System.Drawing.Size(11, 12);
            this.J4_26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_26.TabIndex = 283;
            this.J4_26.TabStop = false;
            this.J4_26.Visible = false;
            // 
            // J3_26
            // 
            this.J3_26.BackColor = System.Drawing.Color.Transparent;
            this.J3_26.Location = new System.Drawing.Point(308, 20);
            this.J3_26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_26.Name = "J3_26";
            this.J3_26.Size = new System.Drawing.Size(11, 12);
            this.J3_26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_26.TabIndex = 282;
            this.J3_26.TabStop = false;
            this.J3_26.Visible = false;
            // 
            // J2_26
            // 
            this.J2_26.BackColor = System.Drawing.Color.Transparent;
            this.J2_26.Location = new System.Drawing.Point(296, 20);
            this.J2_26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_26.Name = "J2_26";
            this.J2_26.Size = new System.Drawing.Size(11, 12);
            this.J2_26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_26.TabIndex = 281;
            this.J2_26.TabStop = false;
            this.J2_26.Visible = false;
            // 
            // J1_26
            // 
            this.J1_26.BackColor = System.Drawing.Color.Transparent;
            this.J1_26.Location = new System.Drawing.Point(283, 20);
            this.J1_26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_26.Name = "J1_26";
            this.J1_26.Size = new System.Drawing.Size(11, 12);
            this.J1_26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_26.TabIndex = 280;
            this.J1_26.TabStop = false;
            this.J1_26.Visible = false;
            // 
            // J8_25
            // 
            this.J8_25.BackColor = System.Drawing.Color.Transparent;
            this.J8_25.Location = new System.Drawing.Point(268, 48);
            this.J8_25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_25.Name = "J8_25";
            this.J8_25.Size = new System.Drawing.Size(11, 12);
            this.J8_25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_25.TabIndex = 279;
            this.J8_25.TabStop = false;
            this.J8_25.Visible = false;
            // 
            // J7_25
            // 
            this.J7_25.BackColor = System.Drawing.Color.Transparent;
            this.J7_25.Location = new System.Drawing.Point(255, 48);
            this.J7_25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_25.Name = "J7_25";
            this.J7_25.Size = new System.Drawing.Size(11, 12);
            this.J7_25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_25.TabIndex = 278;
            this.J7_25.TabStop = false;
            this.J7_25.Visible = false;
            // 
            // J6_25
            // 
            this.J6_25.BackColor = System.Drawing.Color.Transparent;
            this.J6_25.Location = new System.Drawing.Point(242, 48);
            this.J6_25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_25.Name = "J6_25";
            this.J6_25.Size = new System.Drawing.Size(11, 12);
            this.J6_25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_25.TabIndex = 277;
            this.J6_25.TabStop = false;
            this.J6_25.Visible = false;
            // 
            // J5_25
            // 
            this.J5_25.BackColor = System.Drawing.Color.Transparent;
            this.J5_25.Location = new System.Drawing.Point(268, 34);
            this.J5_25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_25.Name = "J5_25";
            this.J5_25.Size = new System.Drawing.Size(11, 12);
            this.J5_25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_25.TabIndex = 276;
            this.J5_25.TabStop = false;
            this.J5_25.Visible = false;
            // 
            // J4_25
            // 
            this.J4_25.BackColor = System.Drawing.Color.Transparent;
            this.J4_25.Location = new System.Drawing.Point(242, 34);
            this.J4_25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_25.Name = "J4_25";
            this.J4_25.Size = new System.Drawing.Size(11, 12);
            this.J4_25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_25.TabIndex = 275;
            this.J4_25.TabStop = false;
            this.J4_25.Visible = false;
            // 
            // J3_25
            // 
            this.J3_25.BackColor = System.Drawing.Color.Transparent;
            this.J3_25.Location = new System.Drawing.Point(268, 20);
            this.J3_25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_25.Name = "J3_25";
            this.J3_25.Size = new System.Drawing.Size(11, 12);
            this.J3_25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_25.TabIndex = 274;
            this.J3_25.TabStop = false;
            this.J3_25.Visible = false;
            // 
            // J2_25
            // 
            this.J2_25.BackColor = System.Drawing.Color.Transparent;
            this.J2_25.Location = new System.Drawing.Point(255, 20);
            this.J2_25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_25.Name = "J2_25";
            this.J2_25.Size = new System.Drawing.Size(11, 12);
            this.J2_25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_25.TabIndex = 273;
            this.J2_25.TabStop = false;
            this.J2_25.Visible = false;
            // 
            // J1_25
            // 
            this.J1_25.BackColor = System.Drawing.Color.Transparent;
            this.J1_25.Location = new System.Drawing.Point(242, 20);
            this.J1_25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_25.Name = "J1_25";
            this.J1_25.Size = new System.Drawing.Size(11, 12);
            this.J1_25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_25.TabIndex = 272;
            this.J1_25.TabStop = false;
            this.J1_25.Visible = false;
            // 
            // J8_24
            // 
            this.J8_24.BackColor = System.Drawing.Color.Transparent;
            this.J8_24.Location = new System.Drawing.Point(226, 48);
            this.J8_24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_24.Name = "J8_24";
            this.J8_24.Size = new System.Drawing.Size(11, 12);
            this.J8_24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_24.TabIndex = 271;
            this.J8_24.TabStop = false;
            this.J8_24.Visible = false;
            // 
            // J7_24
            // 
            this.J7_24.BackColor = System.Drawing.Color.Transparent;
            this.J7_24.Location = new System.Drawing.Point(214, 48);
            this.J7_24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_24.Name = "J7_24";
            this.J7_24.Size = new System.Drawing.Size(11, 12);
            this.J7_24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_24.TabIndex = 270;
            this.J7_24.TabStop = false;
            this.J7_24.Visible = false;
            // 
            // J6_24
            // 
            this.J6_24.BackColor = System.Drawing.Color.Transparent;
            this.J6_24.Location = new System.Drawing.Point(201, 48);
            this.J6_24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_24.Name = "J6_24";
            this.J6_24.Size = new System.Drawing.Size(11, 12);
            this.J6_24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_24.TabIndex = 269;
            this.J6_24.TabStop = false;
            this.J6_24.Visible = false;
            // 
            // J5_24
            // 
            this.J5_24.BackColor = System.Drawing.Color.Transparent;
            this.J5_24.Location = new System.Drawing.Point(226, 34);
            this.J5_24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_24.Name = "J5_24";
            this.J5_24.Size = new System.Drawing.Size(11, 12);
            this.J5_24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_24.TabIndex = 268;
            this.J5_24.TabStop = false;
            this.J5_24.Visible = false;
            // 
            // J4_24
            // 
            this.J4_24.BackColor = System.Drawing.Color.Transparent;
            this.J4_24.Location = new System.Drawing.Point(201, 34);
            this.J4_24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_24.Name = "J4_24";
            this.J4_24.Size = new System.Drawing.Size(11, 12);
            this.J4_24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_24.TabIndex = 267;
            this.J4_24.TabStop = false;
            this.J4_24.Visible = false;
            // 
            // J3_24
            // 
            this.J3_24.BackColor = System.Drawing.Color.Transparent;
            this.J3_24.Location = new System.Drawing.Point(226, 20);
            this.J3_24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_24.Name = "J3_24";
            this.J3_24.Size = new System.Drawing.Size(11, 12);
            this.J3_24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_24.TabIndex = 266;
            this.J3_24.TabStop = false;
            this.J3_24.Visible = false;
            // 
            // J2_24
            // 
            this.J2_24.BackColor = System.Drawing.Color.Transparent;
            this.J2_24.Location = new System.Drawing.Point(214, 20);
            this.J2_24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_24.Name = "J2_24";
            this.J2_24.Size = new System.Drawing.Size(11, 12);
            this.J2_24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_24.TabIndex = 265;
            this.J2_24.TabStop = false;
            this.J2_24.Visible = false;
            // 
            // J1_24
            // 
            this.J1_24.BackColor = System.Drawing.Color.Transparent;
            this.J1_24.Location = new System.Drawing.Point(201, 20);
            this.J1_24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_24.Name = "J1_24";
            this.J1_24.Size = new System.Drawing.Size(11, 12);
            this.J1_24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_24.TabIndex = 264;
            this.J1_24.TabStop = false;
            this.J1_24.Visible = false;
            // 
            // J8_23
            // 
            this.J8_23.BackColor = System.Drawing.Color.Transparent;
            this.J8_23.Location = new System.Drawing.Point(186, 48);
            this.J8_23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_23.Name = "J8_23";
            this.J8_23.Size = new System.Drawing.Size(11, 12);
            this.J8_23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_23.TabIndex = 263;
            this.J8_23.TabStop = false;
            this.J8_23.Visible = false;
            // 
            // J7_23
            // 
            this.J7_23.BackColor = System.Drawing.Color.Transparent;
            this.J7_23.Location = new System.Drawing.Point(173, 48);
            this.J7_23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_23.Name = "J7_23";
            this.J7_23.Size = new System.Drawing.Size(11, 12);
            this.J7_23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_23.TabIndex = 262;
            this.J7_23.TabStop = false;
            this.J7_23.Visible = false;
            // 
            // J6_23
            // 
            this.J6_23.BackColor = System.Drawing.Color.Transparent;
            this.J6_23.Location = new System.Drawing.Point(160, 48);
            this.J6_23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_23.Name = "J6_23";
            this.J6_23.Size = new System.Drawing.Size(11, 12);
            this.J6_23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_23.TabIndex = 261;
            this.J6_23.TabStop = false;
            this.J6_23.Visible = false;
            // 
            // J5_23
            // 
            this.J5_23.BackColor = System.Drawing.Color.Transparent;
            this.J5_23.Location = new System.Drawing.Point(186, 34);
            this.J5_23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_23.Name = "J5_23";
            this.J5_23.Size = new System.Drawing.Size(11, 12);
            this.J5_23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_23.TabIndex = 260;
            this.J5_23.TabStop = false;
            this.J5_23.Visible = false;
            // 
            // J4_23
            // 
            this.J4_23.BackColor = System.Drawing.Color.Transparent;
            this.J4_23.Location = new System.Drawing.Point(160, 34);
            this.J4_23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_23.Name = "J4_23";
            this.J4_23.Size = new System.Drawing.Size(11, 12);
            this.J4_23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_23.TabIndex = 259;
            this.J4_23.TabStop = false;
            this.J4_23.Visible = false;
            // 
            // J3_23
            // 
            this.J3_23.BackColor = System.Drawing.Color.Transparent;
            this.J3_23.Location = new System.Drawing.Point(186, 20);
            this.J3_23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_23.Name = "J3_23";
            this.J3_23.Size = new System.Drawing.Size(11, 12);
            this.J3_23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_23.TabIndex = 258;
            this.J3_23.TabStop = false;
            this.J3_23.Visible = false;
            // 
            // J2_23
            // 
            this.J2_23.BackColor = System.Drawing.Color.Transparent;
            this.J2_23.Location = new System.Drawing.Point(173, 20);
            this.J2_23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_23.Name = "J2_23";
            this.J2_23.Size = new System.Drawing.Size(11, 12);
            this.J2_23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_23.TabIndex = 257;
            this.J2_23.TabStop = false;
            this.J2_23.Visible = false;
            // 
            // J1_23
            // 
            this.J1_23.BackColor = System.Drawing.Color.Transparent;
            this.J1_23.Location = new System.Drawing.Point(160, 20);
            this.J1_23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_23.Name = "J1_23";
            this.J1_23.Size = new System.Drawing.Size(11, 12);
            this.J1_23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_23.TabIndex = 256;
            this.J1_23.TabStop = false;
            this.J1_23.Visible = false;
            // 
            // J8_22
            // 
            this.J8_22.BackColor = System.Drawing.Color.Transparent;
            this.J8_22.Location = new System.Drawing.Point(146, 48);
            this.J8_22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_22.Name = "J8_22";
            this.J8_22.Size = new System.Drawing.Size(11, 12);
            this.J8_22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_22.TabIndex = 255;
            this.J8_22.TabStop = false;
            this.J8_22.Visible = false;
            // 
            // J7_22
            // 
            this.J7_22.BackColor = System.Drawing.Color.Transparent;
            this.J7_22.Location = new System.Drawing.Point(133, 48);
            this.J7_22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_22.Name = "J7_22";
            this.J7_22.Size = new System.Drawing.Size(11, 12);
            this.J7_22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_22.TabIndex = 254;
            this.J7_22.TabStop = false;
            this.J7_22.Visible = false;
            // 
            // J6_22
            // 
            this.J6_22.BackColor = System.Drawing.Color.Transparent;
            this.J6_22.Location = new System.Drawing.Point(120, 48);
            this.J6_22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_22.Name = "J6_22";
            this.J6_22.Size = new System.Drawing.Size(11, 12);
            this.J6_22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_22.TabIndex = 253;
            this.J6_22.TabStop = false;
            this.J6_22.Visible = false;
            // 
            // J5_22
            // 
            this.J5_22.BackColor = System.Drawing.Color.Transparent;
            this.J5_22.Location = new System.Drawing.Point(146, 34);
            this.J5_22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_22.Name = "J5_22";
            this.J5_22.Size = new System.Drawing.Size(11, 12);
            this.J5_22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_22.TabIndex = 252;
            this.J5_22.TabStop = false;
            this.J5_22.Visible = false;
            // 
            // J4_22
            // 
            this.J4_22.BackColor = System.Drawing.Color.Transparent;
            this.J4_22.Location = new System.Drawing.Point(120, 34);
            this.J4_22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_22.Name = "J4_22";
            this.J4_22.Size = new System.Drawing.Size(11, 12);
            this.J4_22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_22.TabIndex = 251;
            this.J4_22.TabStop = false;
            this.J4_22.Visible = false;
            // 
            // J3_22
            // 
            this.J3_22.BackColor = System.Drawing.Color.Transparent;
            this.J3_22.Location = new System.Drawing.Point(146, 20);
            this.J3_22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_22.Name = "J3_22";
            this.J3_22.Size = new System.Drawing.Size(11, 12);
            this.J3_22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_22.TabIndex = 250;
            this.J3_22.TabStop = false;
            this.J3_22.Visible = false;
            // 
            // J2_22
            // 
            this.J2_22.BackColor = System.Drawing.Color.Transparent;
            this.J2_22.Location = new System.Drawing.Point(133, 20);
            this.J2_22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_22.Name = "J2_22";
            this.J2_22.Size = new System.Drawing.Size(11, 12);
            this.J2_22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_22.TabIndex = 249;
            this.J2_22.TabStop = false;
            this.J2_22.Visible = false;
            // 
            // J1_22
            // 
            this.J1_22.BackColor = System.Drawing.Color.Transparent;
            this.J1_22.Location = new System.Drawing.Point(120, 20);
            this.J1_22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_22.Name = "J1_22";
            this.J1_22.Size = new System.Drawing.Size(11, 12);
            this.J1_22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_22.TabIndex = 248;
            this.J1_22.TabStop = false;
            this.J1_22.Visible = false;
            // 
            // J8_20
            // 
            this.J8_20.BackColor = System.Drawing.Color.Transparent;
            this.J8_20.Location = new System.Drawing.Point(46, 48);
            this.J8_20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_20.Name = "J8_20";
            this.J8_20.Size = new System.Drawing.Size(11, 12);
            this.J8_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_20.TabIndex = 247;
            this.J8_20.TabStop = false;
            this.J8_20.Visible = false;
            // 
            // J7_20
            // 
            this.J7_20.BackColor = System.Drawing.Color.Transparent;
            this.J7_20.Location = new System.Drawing.Point(34, 48);
            this.J7_20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_20.Name = "J7_20";
            this.J7_20.Size = new System.Drawing.Size(11, 12);
            this.J7_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_20.TabIndex = 246;
            this.J7_20.TabStop = false;
            this.J7_20.Visible = false;
            // 
            // J6_20
            // 
            this.J6_20.BackColor = System.Drawing.Color.Transparent;
            this.J6_20.Location = new System.Drawing.Point(21, 48);
            this.J6_20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_20.Name = "J6_20";
            this.J6_20.Size = new System.Drawing.Size(11, 12);
            this.J6_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_20.TabIndex = 245;
            this.J6_20.TabStop = false;
            this.J6_20.Visible = false;
            // 
            // J5_20
            // 
            this.J5_20.BackColor = System.Drawing.Color.Transparent;
            this.J5_20.Location = new System.Drawing.Point(46, 34);
            this.J5_20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_20.Name = "J5_20";
            this.J5_20.Size = new System.Drawing.Size(11, 12);
            this.J5_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_20.TabIndex = 244;
            this.J5_20.TabStop = false;
            this.J5_20.Visible = false;
            // 
            // J4_20
            // 
            this.J4_20.BackColor = System.Drawing.Color.Transparent;
            this.J4_20.Location = new System.Drawing.Point(21, 34);
            this.J4_20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_20.Name = "J4_20";
            this.J4_20.Size = new System.Drawing.Size(11, 12);
            this.J4_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_20.TabIndex = 243;
            this.J4_20.TabStop = false;
            this.J4_20.Visible = false;
            // 
            // J3_20
            // 
            this.J3_20.BackColor = System.Drawing.Color.Transparent;
            this.J3_20.Location = new System.Drawing.Point(46, 20);
            this.J3_20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_20.Name = "J3_20";
            this.J3_20.Size = new System.Drawing.Size(11, 12);
            this.J3_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_20.TabIndex = 242;
            this.J3_20.TabStop = false;
            this.J3_20.Visible = false;
            // 
            // J2_20
            // 
            this.J2_20.BackColor = System.Drawing.Color.Transparent;
            this.J2_20.Location = new System.Drawing.Point(34, 20);
            this.J2_20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_20.Name = "J2_20";
            this.J2_20.Size = new System.Drawing.Size(11, 12);
            this.J2_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_20.TabIndex = 241;
            this.J2_20.TabStop = false;
            this.J2_20.Visible = false;
            // 
            // J1_20
            // 
            this.J1_20.BackColor = System.Drawing.Color.Transparent;
            this.J1_20.Location = new System.Drawing.Point(21, 20);
            this.J1_20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_20.Name = "J1_20";
            this.J1_20.Size = new System.Drawing.Size(11, 12);
            this.J1_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_20.TabIndex = 240;
            this.J1_20.TabStop = false;
            this.J1_20.Visible = false;
            // 
            // J8_21
            // 
            this.J8_21.BackColor = System.Drawing.Color.Transparent;
            this.J8_21.Location = new System.Drawing.Point(104, 48);
            this.J8_21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_21.Name = "J8_21";
            this.J8_21.Size = new System.Drawing.Size(11, 12);
            this.J8_21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_21.TabIndex = 239;
            this.J8_21.TabStop = false;
            this.J8_21.Visible = false;
            // 
            // J7_21
            // 
            this.J7_21.BackColor = System.Drawing.Color.Transparent;
            this.J7_21.Location = new System.Drawing.Point(92, 48);
            this.J7_21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_21.Name = "J7_21";
            this.J7_21.Size = new System.Drawing.Size(11, 12);
            this.J7_21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_21.TabIndex = 238;
            this.J7_21.TabStop = false;
            this.J7_21.Visible = false;
            // 
            // J6_21
            // 
            this.J6_21.BackColor = System.Drawing.Color.Transparent;
            this.J6_21.Location = new System.Drawing.Point(79, 48);
            this.J6_21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_21.Name = "J6_21";
            this.J6_21.Size = new System.Drawing.Size(11, 12);
            this.J6_21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_21.TabIndex = 237;
            this.J6_21.TabStop = false;
            this.J6_21.Visible = false;
            // 
            // J5_21
            // 
            this.J5_21.BackColor = System.Drawing.Color.Transparent;
            this.J5_21.Location = new System.Drawing.Point(104, 34);
            this.J5_21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_21.Name = "J5_21";
            this.J5_21.Size = new System.Drawing.Size(11, 12);
            this.J5_21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_21.TabIndex = 236;
            this.J5_21.TabStop = false;
            this.J5_21.Visible = false;
            // 
            // J4_21
            // 
            this.J4_21.BackColor = System.Drawing.Color.Transparent;
            this.J4_21.Location = new System.Drawing.Point(79, 34);
            this.J4_21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_21.Name = "J4_21";
            this.J4_21.Size = new System.Drawing.Size(11, 12);
            this.J4_21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_21.TabIndex = 235;
            this.J4_21.TabStop = false;
            this.J4_21.Visible = false;
            // 
            // J3_21
            // 
            this.J3_21.BackColor = System.Drawing.Color.Transparent;
            this.J3_21.Location = new System.Drawing.Point(104, 20);
            this.J3_21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_21.Name = "J3_21";
            this.J3_21.Size = new System.Drawing.Size(11, 12);
            this.J3_21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_21.TabIndex = 234;
            this.J3_21.TabStop = false;
            this.J3_21.Visible = false;
            // 
            // J2_21
            // 
            this.J2_21.BackColor = System.Drawing.Color.Transparent;
            this.J2_21.Location = new System.Drawing.Point(92, 20);
            this.J2_21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_21.Name = "J2_21";
            this.J2_21.Size = new System.Drawing.Size(11, 12);
            this.J2_21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_21.TabIndex = 233;
            this.J2_21.TabStop = false;
            this.J2_21.Visible = false;
            // 
            // J1_21
            // 
            this.J1_21.BackColor = System.Drawing.Color.Transparent;
            this.J1_21.Location = new System.Drawing.Point(79, 20);
            this.J1_21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_21.Name = "J1_21";
            this.J1_21.Size = new System.Drawing.Size(11, 12);
            this.J1_21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_21.TabIndex = 232;
            this.J1_21.TabStop = false;
            this.J1_21.Visible = false;
            // 
            // J8_19
            // 
            this.J8_19.BackColor = System.Drawing.Color.Transparent;
            this.J8_19.Location = new System.Drawing.Point(46, 110);
            this.J8_19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_19.Name = "J8_19";
            this.J8_19.Size = new System.Drawing.Size(11, 12);
            this.J8_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_19.TabIndex = 231;
            this.J8_19.TabStop = false;
            this.J8_19.Visible = false;
            // 
            // J7_19
            // 
            this.J7_19.BackColor = System.Drawing.Color.Transparent;
            this.J7_19.Location = new System.Drawing.Point(34, 110);
            this.J7_19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_19.Name = "J7_19";
            this.J7_19.Size = new System.Drawing.Size(11, 12);
            this.J7_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_19.TabIndex = 230;
            this.J7_19.TabStop = false;
            this.J7_19.Visible = false;
            // 
            // J6_19
            // 
            this.J6_19.BackColor = System.Drawing.Color.Transparent;
            this.J6_19.Location = new System.Drawing.Point(21, 110);
            this.J6_19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_19.Name = "J6_19";
            this.J6_19.Size = new System.Drawing.Size(11, 12);
            this.J6_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_19.TabIndex = 229;
            this.J6_19.TabStop = false;
            this.J6_19.Visible = false;
            // 
            // J5_19
            // 
            this.J5_19.BackColor = System.Drawing.Color.Transparent;
            this.J5_19.Location = new System.Drawing.Point(46, 97);
            this.J5_19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_19.Name = "J5_19";
            this.J5_19.Size = new System.Drawing.Size(11, 12);
            this.J5_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_19.TabIndex = 228;
            this.J5_19.TabStop = false;
            this.J5_19.Visible = false;
            // 
            // J4_19
            // 
            this.J4_19.BackColor = System.Drawing.Color.Transparent;
            this.J4_19.Location = new System.Drawing.Point(21, 97);
            this.J4_19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_19.Name = "J4_19";
            this.J4_19.Size = new System.Drawing.Size(11, 12);
            this.J4_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_19.TabIndex = 227;
            this.J4_19.TabStop = false;
            this.J4_19.Visible = false;
            // 
            // J3_19
            // 
            this.J3_19.BackColor = System.Drawing.Color.Transparent;
            this.J3_19.Location = new System.Drawing.Point(46, 83);
            this.J3_19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_19.Name = "J3_19";
            this.J3_19.Size = new System.Drawing.Size(11, 12);
            this.J3_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_19.TabIndex = 226;
            this.J3_19.TabStop = false;
            this.J3_19.Visible = false;
            // 
            // J2_19
            // 
            this.J2_19.BackColor = System.Drawing.Color.Transparent;
            this.J2_19.Location = new System.Drawing.Point(34, 83);
            this.J2_19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_19.Name = "J2_19";
            this.J2_19.Size = new System.Drawing.Size(11, 12);
            this.J2_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_19.TabIndex = 225;
            this.J2_19.TabStop = false;
            this.J2_19.Visible = false;
            // 
            // J1_19
            // 
            this.J1_19.BackColor = System.Drawing.Color.Transparent;
            this.J1_19.Location = new System.Drawing.Point(21, 83);
            this.J1_19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_19.Name = "J1_19";
            this.J1_19.Size = new System.Drawing.Size(11, 12);
            this.J1_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_19.TabIndex = 224;
            this.J1_19.TabStop = false;
            this.J1_19.Visible = false;
            // 
            // J8_18
            // 
            this.J8_18.BackColor = System.Drawing.Color.Transparent;
            this.J8_18.Location = new System.Drawing.Point(46, 154);
            this.J8_18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_18.Name = "J8_18";
            this.J8_18.Size = new System.Drawing.Size(11, 12);
            this.J8_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_18.TabIndex = 223;
            this.J8_18.TabStop = false;
            this.J8_18.Visible = false;
            // 
            // J7_18
            // 
            this.J7_18.BackColor = System.Drawing.Color.Transparent;
            this.J7_18.Location = new System.Drawing.Point(34, 154);
            this.J7_18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_18.Name = "J7_18";
            this.J7_18.Size = new System.Drawing.Size(11, 12);
            this.J7_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_18.TabIndex = 222;
            this.J7_18.TabStop = false;
            this.J7_18.Visible = false;
            // 
            // J6_18
            // 
            this.J6_18.BackColor = System.Drawing.Color.Transparent;
            this.J6_18.Location = new System.Drawing.Point(21, 154);
            this.J6_18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_18.Name = "J6_18";
            this.J6_18.Size = new System.Drawing.Size(11, 12);
            this.J6_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_18.TabIndex = 221;
            this.J6_18.TabStop = false;
            this.J6_18.Visible = false;
            // 
            // J5_18
            // 
            this.J5_18.BackColor = System.Drawing.Color.Transparent;
            this.J5_18.Location = new System.Drawing.Point(46, 141);
            this.J5_18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_18.Name = "J5_18";
            this.J5_18.Size = new System.Drawing.Size(11, 12);
            this.J5_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_18.TabIndex = 220;
            this.J5_18.TabStop = false;
            this.J5_18.Visible = false;
            // 
            // J4_18
            // 
            this.J4_18.BackColor = System.Drawing.Color.Transparent;
            this.J4_18.Location = new System.Drawing.Point(21, 141);
            this.J4_18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_18.Name = "J4_18";
            this.J4_18.Size = new System.Drawing.Size(11, 12);
            this.J4_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_18.TabIndex = 219;
            this.J4_18.TabStop = false;
            this.J4_18.Visible = false;
            // 
            // J3_18
            // 
            this.J3_18.BackColor = System.Drawing.Color.Transparent;
            this.J3_18.Location = new System.Drawing.Point(46, 127);
            this.J3_18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_18.Name = "J3_18";
            this.J3_18.Size = new System.Drawing.Size(11, 12);
            this.J3_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_18.TabIndex = 218;
            this.J3_18.TabStop = false;
            this.J3_18.Visible = false;
            // 
            // J2_18
            // 
            this.J2_18.BackColor = System.Drawing.Color.Transparent;
            this.J2_18.Location = new System.Drawing.Point(34, 127);
            this.J2_18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_18.Name = "J2_18";
            this.J2_18.Size = new System.Drawing.Size(11, 12);
            this.J2_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_18.TabIndex = 217;
            this.J2_18.TabStop = false;
            this.J2_18.Visible = false;
            // 
            // J1_18
            // 
            this.J1_18.BackColor = System.Drawing.Color.Transparent;
            this.J1_18.Location = new System.Drawing.Point(21, 127);
            this.J1_18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_18.Name = "J1_18";
            this.J1_18.Size = new System.Drawing.Size(11, 12);
            this.J1_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_18.TabIndex = 216;
            this.J1_18.TabStop = false;
            this.J1_18.Visible = false;
            // 
            // J8_17
            // 
            this.J8_17.BackColor = System.Drawing.Color.Transparent;
            this.J8_17.Location = new System.Drawing.Point(46, 198);
            this.J8_17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_17.Name = "J8_17";
            this.J8_17.Size = new System.Drawing.Size(11, 12);
            this.J8_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_17.TabIndex = 215;
            this.J8_17.TabStop = false;
            this.J8_17.Visible = false;
            // 
            // J7_17
            // 
            this.J7_17.BackColor = System.Drawing.Color.Transparent;
            this.J7_17.Location = new System.Drawing.Point(34, 198);
            this.J7_17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_17.Name = "J7_17";
            this.J7_17.Size = new System.Drawing.Size(11, 12);
            this.J7_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_17.TabIndex = 214;
            this.J7_17.TabStop = false;
            this.J7_17.Visible = false;
            // 
            // J6_17
            // 
            this.J6_17.BackColor = System.Drawing.Color.Transparent;
            this.J6_17.Location = new System.Drawing.Point(21, 198);
            this.J6_17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_17.Name = "J6_17";
            this.J6_17.Size = new System.Drawing.Size(11, 12);
            this.J6_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_17.TabIndex = 213;
            this.J6_17.TabStop = false;
            this.J6_17.Visible = false;
            // 
            // J5_17
            // 
            this.J5_17.BackColor = System.Drawing.Color.Transparent;
            this.J5_17.Location = new System.Drawing.Point(46, 184);
            this.J5_17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_17.Name = "J5_17";
            this.J5_17.Size = new System.Drawing.Size(11, 12);
            this.J5_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_17.TabIndex = 212;
            this.J5_17.TabStop = false;
            this.J5_17.Visible = false;
            // 
            // J4_17
            // 
            this.J4_17.BackColor = System.Drawing.Color.Transparent;
            this.J4_17.Location = new System.Drawing.Point(21, 184);
            this.J4_17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_17.Name = "J4_17";
            this.J4_17.Size = new System.Drawing.Size(11, 12);
            this.J4_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_17.TabIndex = 211;
            this.J4_17.TabStop = false;
            this.J4_17.Visible = false;
            // 
            // J3_17
            // 
            this.J3_17.BackColor = System.Drawing.Color.Transparent;
            this.J3_17.Location = new System.Drawing.Point(46, 171);
            this.J3_17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_17.Name = "J3_17";
            this.J3_17.Size = new System.Drawing.Size(11, 12);
            this.J3_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_17.TabIndex = 210;
            this.J3_17.TabStop = false;
            this.J3_17.Visible = false;
            // 
            // J2_17
            // 
            this.J2_17.BackColor = System.Drawing.Color.Transparent;
            this.J2_17.Location = new System.Drawing.Point(34, 171);
            this.J2_17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_17.Name = "J2_17";
            this.J2_17.Size = new System.Drawing.Size(11, 12);
            this.J2_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_17.TabIndex = 209;
            this.J2_17.TabStop = false;
            this.J2_17.Visible = false;
            // 
            // J1_17
            // 
            this.J1_17.BackColor = System.Drawing.Color.Transparent;
            this.J1_17.Location = new System.Drawing.Point(21, 171);
            this.J1_17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_17.Name = "J1_17";
            this.J1_17.Size = new System.Drawing.Size(11, 12);
            this.J1_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_17.TabIndex = 208;
            this.J1_17.TabStop = false;
            this.J1_17.Visible = false;
            // 
            // J8_16
            // 
            this.J8_16.BackColor = System.Drawing.Color.Transparent;
            this.J8_16.Location = new System.Drawing.Point(46, 243);
            this.J8_16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_16.Name = "J8_16";
            this.J8_16.Size = new System.Drawing.Size(11, 12);
            this.J8_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_16.TabIndex = 207;
            this.J8_16.TabStop = false;
            this.J8_16.Visible = false;
            // 
            // J7_16
            // 
            this.J7_16.BackColor = System.Drawing.Color.Transparent;
            this.J7_16.Location = new System.Drawing.Point(34, 243);
            this.J7_16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_16.Name = "J7_16";
            this.J7_16.Size = new System.Drawing.Size(11, 12);
            this.J7_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_16.TabIndex = 206;
            this.J7_16.TabStop = false;
            this.J7_16.Visible = false;
            // 
            // J6_16
            // 
            this.J6_16.BackColor = System.Drawing.Color.Transparent;
            this.J6_16.Location = new System.Drawing.Point(21, 243);
            this.J6_16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_16.Name = "J6_16";
            this.J6_16.Size = new System.Drawing.Size(11, 12);
            this.J6_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_16.TabIndex = 205;
            this.J6_16.TabStop = false;
            this.J6_16.Visible = false;
            // 
            // J5_16
            // 
            this.J5_16.BackColor = System.Drawing.Color.Transparent;
            this.J5_16.Location = new System.Drawing.Point(46, 229);
            this.J5_16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_16.Name = "J5_16";
            this.J5_16.Size = new System.Drawing.Size(11, 12);
            this.J5_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_16.TabIndex = 204;
            this.J5_16.TabStop = false;
            this.J5_16.Visible = false;
            // 
            // J4_16
            // 
            this.J4_16.BackColor = System.Drawing.Color.Transparent;
            this.J4_16.Location = new System.Drawing.Point(21, 229);
            this.J4_16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_16.Name = "J4_16";
            this.J4_16.Size = new System.Drawing.Size(11, 12);
            this.J4_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_16.TabIndex = 203;
            this.J4_16.TabStop = false;
            this.J4_16.Visible = false;
            // 
            // J3_16
            // 
            this.J3_16.BackColor = System.Drawing.Color.Transparent;
            this.J3_16.Location = new System.Drawing.Point(46, 215);
            this.J3_16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_16.Name = "J3_16";
            this.J3_16.Size = new System.Drawing.Size(11, 12);
            this.J3_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_16.TabIndex = 202;
            this.J3_16.TabStop = false;
            this.J3_16.Visible = false;
            // 
            // J2_16
            // 
            this.J2_16.BackColor = System.Drawing.Color.Transparent;
            this.J2_16.Location = new System.Drawing.Point(34, 215);
            this.J2_16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_16.Name = "J2_16";
            this.J2_16.Size = new System.Drawing.Size(11, 12);
            this.J2_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_16.TabIndex = 201;
            this.J2_16.TabStop = false;
            this.J2_16.Visible = false;
            // 
            // J1_16
            // 
            this.J1_16.BackColor = System.Drawing.Color.Transparent;
            this.J1_16.Location = new System.Drawing.Point(21, 215);
            this.J1_16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_16.Name = "J1_16";
            this.J1_16.Size = new System.Drawing.Size(11, 12);
            this.J1_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_16.TabIndex = 200;
            this.J1_16.TabStop = false;
            this.J1_16.Visible = false;
            // 
            // J8_15
            // 
            this.J8_15.BackColor = System.Drawing.Color.Transparent;
            this.J8_15.Location = new System.Drawing.Point(46, 287);
            this.J8_15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_15.Name = "J8_15";
            this.J8_15.Size = new System.Drawing.Size(11, 12);
            this.J8_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_15.TabIndex = 199;
            this.J8_15.TabStop = false;
            this.J8_15.Visible = false;
            // 
            // J7_15
            // 
            this.J7_15.BackColor = System.Drawing.Color.Transparent;
            this.J7_15.Location = new System.Drawing.Point(34, 287);
            this.J7_15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_15.Name = "J7_15";
            this.J7_15.Size = new System.Drawing.Size(11, 12);
            this.J7_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_15.TabIndex = 198;
            this.J7_15.TabStop = false;
            this.J7_15.Visible = false;
            // 
            // J6_15
            // 
            this.J6_15.BackColor = System.Drawing.Color.Transparent;
            this.J6_15.Location = new System.Drawing.Point(21, 287);
            this.J6_15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_15.Name = "J6_15";
            this.J6_15.Size = new System.Drawing.Size(11, 12);
            this.J6_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_15.TabIndex = 197;
            this.J6_15.TabStop = false;
            this.J6_15.Visible = false;
            // 
            // J5_15
            // 
            this.J5_15.BackColor = System.Drawing.Color.Transparent;
            this.J5_15.Location = new System.Drawing.Point(46, 273);
            this.J5_15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_15.Name = "J5_15";
            this.J5_15.Size = new System.Drawing.Size(11, 12);
            this.J5_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_15.TabIndex = 196;
            this.J5_15.TabStop = false;
            this.J5_15.Visible = false;
            // 
            // J4_15
            // 
            this.J4_15.BackColor = System.Drawing.Color.Transparent;
            this.J4_15.Location = new System.Drawing.Point(21, 273);
            this.J4_15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_15.Name = "J4_15";
            this.J4_15.Size = new System.Drawing.Size(11, 12);
            this.J4_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_15.TabIndex = 195;
            this.J4_15.TabStop = false;
            this.J4_15.Visible = false;
            // 
            // J3_15
            // 
            this.J3_15.BackColor = System.Drawing.Color.Transparent;
            this.J3_15.Location = new System.Drawing.Point(46, 259);
            this.J3_15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_15.Name = "J3_15";
            this.J3_15.Size = new System.Drawing.Size(11, 12);
            this.J3_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_15.TabIndex = 194;
            this.J3_15.TabStop = false;
            this.J3_15.Visible = false;
            // 
            // J2_15
            // 
            this.J2_15.BackColor = System.Drawing.Color.Transparent;
            this.J2_15.Location = new System.Drawing.Point(34, 259);
            this.J2_15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_15.Name = "J2_15";
            this.J2_15.Size = new System.Drawing.Size(11, 12);
            this.J2_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_15.TabIndex = 193;
            this.J2_15.TabStop = false;
            this.J2_15.Visible = false;
            // 
            // J1_15
            // 
            this.J1_15.BackColor = System.Drawing.Color.Transparent;
            this.J1_15.Location = new System.Drawing.Point(21, 259);
            this.J1_15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_15.Name = "J1_15";
            this.J1_15.Size = new System.Drawing.Size(11, 12);
            this.J1_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_15.TabIndex = 192;
            this.J1_15.TabStop = false;
            this.J1_15.Visible = false;
            // 
            // J8_14
            // 
            this.J8_14.BackColor = System.Drawing.Color.Transparent;
            this.J8_14.Location = new System.Drawing.Point(46, 330);
            this.J8_14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_14.Name = "J8_14";
            this.J8_14.Size = new System.Drawing.Size(11, 12);
            this.J8_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_14.TabIndex = 191;
            this.J8_14.TabStop = false;
            this.J8_14.Visible = false;
            // 
            // J7_14
            // 
            this.J7_14.BackColor = System.Drawing.Color.Transparent;
            this.J7_14.Location = new System.Drawing.Point(34, 330);
            this.J7_14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_14.Name = "J7_14";
            this.J7_14.Size = new System.Drawing.Size(11, 12);
            this.J7_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_14.TabIndex = 190;
            this.J7_14.TabStop = false;
            this.J7_14.Visible = false;
            // 
            // J6_14
            // 
            this.J6_14.BackColor = System.Drawing.Color.Transparent;
            this.J6_14.Location = new System.Drawing.Point(21, 330);
            this.J6_14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_14.Name = "J6_14";
            this.J6_14.Size = new System.Drawing.Size(11, 12);
            this.J6_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_14.TabIndex = 189;
            this.J6_14.TabStop = false;
            this.J6_14.Visible = false;
            // 
            // J5_14
            // 
            this.J5_14.BackColor = System.Drawing.Color.Transparent;
            this.J5_14.Location = new System.Drawing.Point(46, 316);
            this.J5_14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_14.Name = "J5_14";
            this.J5_14.Size = new System.Drawing.Size(11, 12);
            this.J5_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_14.TabIndex = 188;
            this.J5_14.TabStop = false;
            this.J5_14.Visible = false;
            // 
            // J4_14
            // 
            this.J4_14.BackColor = System.Drawing.Color.Transparent;
            this.J4_14.Location = new System.Drawing.Point(21, 316);
            this.J4_14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_14.Name = "J4_14";
            this.J4_14.Size = new System.Drawing.Size(11, 12);
            this.J4_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_14.TabIndex = 187;
            this.J4_14.TabStop = false;
            this.J4_14.Visible = false;
            // 
            // J3_14
            // 
            this.J3_14.BackColor = System.Drawing.Color.Transparent;
            this.J3_14.Location = new System.Drawing.Point(46, 302);
            this.J3_14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_14.Name = "J3_14";
            this.J3_14.Size = new System.Drawing.Size(11, 12);
            this.J3_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_14.TabIndex = 186;
            this.J3_14.TabStop = false;
            this.J3_14.Visible = false;
            // 
            // J2_14
            // 
            this.J2_14.BackColor = System.Drawing.Color.Transparent;
            this.J2_14.Location = new System.Drawing.Point(34, 302);
            this.J2_14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_14.Name = "J2_14";
            this.J2_14.Size = new System.Drawing.Size(11, 12);
            this.J2_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_14.TabIndex = 185;
            this.J2_14.TabStop = false;
            this.J2_14.Visible = false;
            // 
            // J1_14
            // 
            this.J1_14.BackColor = System.Drawing.Color.Transparent;
            this.J1_14.Location = new System.Drawing.Point(21, 302);
            this.J1_14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_14.Name = "J1_14";
            this.J1_14.Size = new System.Drawing.Size(11, 12);
            this.J1_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_14.TabIndex = 184;
            this.J1_14.TabStop = false;
            this.J1_14.Visible = false;
            // 
            // J8_13
            // 
            this.J8_13.BackColor = System.Drawing.Color.Transparent;
            this.J8_13.Location = new System.Drawing.Point(46, 375);
            this.J8_13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_13.Name = "J8_13";
            this.J8_13.Size = new System.Drawing.Size(11, 12);
            this.J8_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_13.TabIndex = 183;
            this.J8_13.TabStop = false;
            this.J8_13.Visible = false;
            // 
            // J7_13
            // 
            this.J7_13.BackColor = System.Drawing.Color.Transparent;
            this.J7_13.Location = new System.Drawing.Point(34, 375);
            this.J7_13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_13.Name = "J7_13";
            this.J7_13.Size = new System.Drawing.Size(11, 12);
            this.J7_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_13.TabIndex = 182;
            this.J7_13.TabStop = false;
            this.J7_13.Visible = false;
            // 
            // J6_13
            // 
            this.J6_13.BackColor = System.Drawing.Color.Transparent;
            this.J6_13.Location = new System.Drawing.Point(21, 375);
            this.J6_13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_13.Name = "J6_13";
            this.J6_13.Size = new System.Drawing.Size(11, 12);
            this.J6_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_13.TabIndex = 181;
            this.J6_13.TabStop = false;
            this.J6_13.Visible = false;
            // 
            // J5_13
            // 
            this.J5_13.BackColor = System.Drawing.Color.Transparent;
            this.J5_13.Location = new System.Drawing.Point(46, 361);
            this.J5_13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_13.Name = "J5_13";
            this.J5_13.Size = new System.Drawing.Size(11, 12);
            this.J5_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_13.TabIndex = 180;
            this.J5_13.TabStop = false;
            this.J5_13.Visible = false;
            // 
            // J4_13
            // 
            this.J4_13.BackColor = System.Drawing.Color.Transparent;
            this.J4_13.Location = new System.Drawing.Point(21, 361);
            this.J4_13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_13.Name = "J4_13";
            this.J4_13.Size = new System.Drawing.Size(11, 12);
            this.J4_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_13.TabIndex = 179;
            this.J4_13.TabStop = false;
            this.J4_13.Visible = false;
            // 
            // J3_13
            // 
            this.J3_13.BackColor = System.Drawing.Color.Transparent;
            this.J3_13.Location = new System.Drawing.Point(46, 347);
            this.J3_13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_13.Name = "J3_13";
            this.J3_13.Size = new System.Drawing.Size(11, 12);
            this.J3_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_13.TabIndex = 178;
            this.J3_13.TabStop = false;
            this.J3_13.Visible = false;
            // 
            // J2_13
            // 
            this.J2_13.BackColor = System.Drawing.Color.Transparent;
            this.J2_13.Location = new System.Drawing.Point(34, 347);
            this.J2_13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_13.Name = "J2_13";
            this.J2_13.Size = new System.Drawing.Size(11, 12);
            this.J2_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_13.TabIndex = 177;
            this.J2_13.TabStop = false;
            this.J2_13.Visible = false;
            // 
            // J1_13
            // 
            this.J1_13.BackColor = System.Drawing.Color.Transparent;
            this.J1_13.Location = new System.Drawing.Point(21, 347);
            this.J1_13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_13.Name = "J1_13";
            this.J1_13.Size = new System.Drawing.Size(11, 12);
            this.J1_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_13.TabIndex = 176;
            this.J1_13.TabStop = false;
            this.J1_13.Visible = false;
            // 
            // J8_12
            // 
            this.J8_12.BackColor = System.Drawing.Color.Transparent;
            this.J8_12.Location = new System.Drawing.Point(46, 418);
            this.J8_12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_12.Name = "J8_12";
            this.J8_12.Size = new System.Drawing.Size(11, 12);
            this.J8_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_12.TabIndex = 175;
            this.J8_12.TabStop = false;
            this.J8_12.Visible = false;
            // 
            // J7_12
            // 
            this.J7_12.BackColor = System.Drawing.Color.Transparent;
            this.J7_12.Location = new System.Drawing.Point(34, 418);
            this.J7_12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_12.Name = "J7_12";
            this.J7_12.Size = new System.Drawing.Size(11, 12);
            this.J7_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_12.TabIndex = 174;
            this.J7_12.TabStop = false;
            this.J7_12.Visible = false;
            // 
            // J6_12
            // 
            this.J6_12.BackColor = System.Drawing.Color.Transparent;
            this.J6_12.Location = new System.Drawing.Point(21, 418);
            this.J6_12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_12.Name = "J6_12";
            this.J6_12.Size = new System.Drawing.Size(11, 12);
            this.J6_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_12.TabIndex = 173;
            this.J6_12.TabStop = false;
            this.J6_12.Visible = false;
            // 
            // J5_12
            // 
            this.J5_12.BackColor = System.Drawing.Color.Transparent;
            this.J5_12.Location = new System.Drawing.Point(46, 404);
            this.J5_12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_12.Name = "J5_12";
            this.J5_12.Size = new System.Drawing.Size(11, 12);
            this.J5_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_12.TabIndex = 172;
            this.J5_12.TabStop = false;
            this.J5_12.Visible = false;
            // 
            // J4_12
            // 
            this.J4_12.BackColor = System.Drawing.Color.Transparent;
            this.J4_12.Location = new System.Drawing.Point(21, 404);
            this.J4_12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_12.Name = "J4_12";
            this.J4_12.Size = new System.Drawing.Size(11, 12);
            this.J4_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_12.TabIndex = 171;
            this.J4_12.TabStop = false;
            this.J4_12.Visible = false;
            // 
            // J3_12
            // 
            this.J3_12.BackColor = System.Drawing.Color.Transparent;
            this.J3_12.Location = new System.Drawing.Point(46, 390);
            this.J3_12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_12.Name = "J3_12";
            this.J3_12.Size = new System.Drawing.Size(11, 12);
            this.J3_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_12.TabIndex = 170;
            this.J3_12.TabStop = false;
            this.J3_12.Visible = false;
            // 
            // J2_12
            // 
            this.J2_12.BackColor = System.Drawing.Color.Transparent;
            this.J2_12.Location = new System.Drawing.Point(34, 390);
            this.J2_12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_12.Name = "J2_12";
            this.J2_12.Size = new System.Drawing.Size(11, 12);
            this.J2_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_12.TabIndex = 169;
            this.J2_12.TabStop = false;
            this.J2_12.Visible = false;
            // 
            // J1_12
            // 
            this.J1_12.BackColor = System.Drawing.Color.Transparent;
            this.J1_12.Location = new System.Drawing.Point(21, 390);
            this.J1_12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_12.Name = "J1_12";
            this.J1_12.Size = new System.Drawing.Size(11, 12);
            this.J1_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_12.TabIndex = 168;
            this.J1_12.TabStop = false;
            this.J1_12.Visible = false;
            // 
            // J8_11
            // 
            this.J8_11.BackColor = System.Drawing.Color.Transparent;
            this.J8_11.Location = new System.Drawing.Point(46, 462);
            this.J8_11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_11.Name = "J8_11";
            this.J8_11.Size = new System.Drawing.Size(11, 12);
            this.J8_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_11.TabIndex = 167;
            this.J8_11.TabStop = false;
            this.J8_11.Visible = false;
            // 
            // J7_11
            // 
            this.J7_11.BackColor = System.Drawing.Color.Transparent;
            this.J7_11.Location = new System.Drawing.Point(34, 462);
            this.J7_11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_11.Name = "J7_11";
            this.J7_11.Size = new System.Drawing.Size(11, 12);
            this.J7_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_11.TabIndex = 166;
            this.J7_11.TabStop = false;
            this.J7_11.Visible = false;
            // 
            // J6_11
            // 
            this.J6_11.BackColor = System.Drawing.Color.Transparent;
            this.J6_11.Location = new System.Drawing.Point(21, 462);
            this.J6_11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_11.Name = "J6_11";
            this.J6_11.Size = new System.Drawing.Size(11, 12);
            this.J6_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_11.TabIndex = 165;
            this.J6_11.TabStop = false;
            this.J6_11.Visible = false;
            // 
            // J5_11
            // 
            this.J5_11.BackColor = System.Drawing.Color.Transparent;
            this.J5_11.Location = new System.Drawing.Point(46, 448);
            this.J5_11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_11.Name = "J5_11";
            this.J5_11.Size = new System.Drawing.Size(11, 12);
            this.J5_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_11.TabIndex = 164;
            this.J5_11.TabStop = false;
            this.J5_11.Visible = false;
            // 
            // J4_11
            // 
            this.J4_11.BackColor = System.Drawing.Color.Transparent;
            this.J4_11.Location = new System.Drawing.Point(21, 448);
            this.J4_11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_11.Name = "J4_11";
            this.J4_11.Size = new System.Drawing.Size(11, 12);
            this.J4_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_11.TabIndex = 163;
            this.J4_11.TabStop = false;
            this.J4_11.Visible = false;
            // 
            // J3_11
            // 
            this.J3_11.BackColor = System.Drawing.Color.Transparent;
            this.J3_11.Location = new System.Drawing.Point(46, 434);
            this.J3_11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_11.Name = "J3_11";
            this.J3_11.Size = new System.Drawing.Size(11, 12);
            this.J3_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_11.TabIndex = 162;
            this.J3_11.TabStop = false;
            this.J3_11.Visible = false;
            // 
            // J2_11
            // 
            this.J2_11.BackColor = System.Drawing.Color.Transparent;
            this.J2_11.Location = new System.Drawing.Point(34, 434);
            this.J2_11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_11.Name = "J2_11";
            this.J2_11.Size = new System.Drawing.Size(11, 12);
            this.J2_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_11.TabIndex = 161;
            this.J2_11.TabStop = false;
            this.J2_11.Visible = false;
            // 
            // J1_11
            // 
            this.J1_11.BackColor = System.Drawing.Color.Transparent;
            this.J1_11.Location = new System.Drawing.Point(21, 434);
            this.J1_11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_11.Name = "J1_11";
            this.J1_11.Size = new System.Drawing.Size(11, 12);
            this.J1_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_11.TabIndex = 160;
            this.J1_11.TabStop = false;
            this.J1_11.Visible = false;
            // 
            // J8_10
            // 
            this.J8_10.BackColor = System.Drawing.Color.Transparent;
            this.J8_10.Location = new System.Drawing.Point(63, 532);
            this.J8_10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_10.Name = "J8_10";
            this.J8_10.Size = new System.Drawing.Size(11, 12);
            this.J8_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_10.TabIndex = 159;
            this.J8_10.TabStop = false;
            this.J8_10.Visible = false;
            // 
            // J7_10
            // 
            this.J7_10.BackColor = System.Drawing.Color.Transparent;
            this.J7_10.Location = new System.Drawing.Point(50, 532);
            this.J7_10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_10.Name = "J7_10";
            this.J7_10.Size = new System.Drawing.Size(11, 12);
            this.J7_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_10.TabIndex = 158;
            this.J7_10.TabStop = false;
            this.J7_10.Visible = false;
            // 
            // J6_10
            // 
            this.J6_10.BackColor = System.Drawing.Color.Transparent;
            this.J6_10.Location = new System.Drawing.Point(36, 532);
            this.J6_10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_10.Name = "J6_10";
            this.J6_10.Size = new System.Drawing.Size(11, 12);
            this.J6_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_10.TabIndex = 157;
            this.J6_10.TabStop = false;
            this.J6_10.Visible = false;
            // 
            // J5_10
            // 
            this.J5_10.BackColor = System.Drawing.Color.Transparent;
            this.J5_10.Location = new System.Drawing.Point(22, 532);
            this.J5_10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_10.Name = "J5_10";
            this.J5_10.Size = new System.Drawing.Size(11, 12);
            this.J5_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_10.TabIndex = 156;
            this.J5_10.TabStop = false;
            this.J5_10.Visible = false;
            // 
            // J4_10
            // 
            this.J4_10.BackColor = System.Drawing.Color.Transparent;
            this.J4_10.Location = new System.Drawing.Point(13, 521);
            this.J4_10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_10.Name = "J4_10";
            this.J4_10.Size = new System.Drawing.Size(11, 12);
            this.J4_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_10.TabIndex = 155;
            this.J4_10.TabStop = false;
            this.J4_10.Visible = false;
            // 
            // J3_10
            // 
            this.J3_10.BackColor = System.Drawing.Color.Transparent;
            this.J3_10.Location = new System.Drawing.Point(13, 506);
            this.J3_10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_10.Name = "J3_10";
            this.J3_10.Size = new System.Drawing.Size(11, 12);
            this.J3_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_10.TabIndex = 154;
            this.J3_10.TabStop = false;
            this.J3_10.Visible = false;
            // 
            // J2_10
            // 
            this.J2_10.BackColor = System.Drawing.Color.Transparent;
            this.J2_10.Location = new System.Drawing.Point(13, 492);
            this.J2_10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_10.Name = "J2_10";
            this.J2_10.Size = new System.Drawing.Size(11, 12);
            this.J2_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_10.TabIndex = 153;
            this.J2_10.TabStop = false;
            this.J2_10.Visible = false;
            // 
            // J1_10
            // 
            this.J1_10.BackColor = System.Drawing.Color.Transparent;
            this.J1_10.Location = new System.Drawing.Point(13, 479);
            this.J1_10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_10.Name = "J1_10";
            this.J1_10.Size = new System.Drawing.Size(11, 12);
            this.J1_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_10.TabIndex = 152;
            this.J1_10.TabStop = false;
            this.J1_10.Visible = false;
            // 
            // J8_10P
            // 
            this.J8_10P.BackColor = System.Drawing.Color.Transparent;
            this.J8_10P.Location = new System.Drawing.Point(59, 509);
            this.J8_10P.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_10P.Name = "J8_10P";
            this.J8_10P.Size = new System.Drawing.Size(11, 12);
            this.J8_10P.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_10P.TabIndex = 151;
            this.J8_10P.TabStop = false;
            this.J8_10P.Visible = false;
            // 
            // J7_10P
            // 
            this.J7_10P.BackColor = System.Drawing.Color.Transparent;
            this.J7_10P.Location = new System.Drawing.Point(46, 509);
            this.J7_10P.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_10P.Name = "J7_10P";
            this.J7_10P.Size = new System.Drawing.Size(11, 12);
            this.J7_10P.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_10P.TabIndex = 150;
            this.J7_10P.TabStop = false;
            this.J7_10P.Visible = false;
            // 
            // J6_10P
            // 
            this.J6_10P.BackColor = System.Drawing.Color.Transparent;
            this.J6_10P.Location = new System.Drawing.Point(34, 509);
            this.J6_10P.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_10P.Name = "J6_10P";
            this.J6_10P.Size = new System.Drawing.Size(11, 12);
            this.J6_10P.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_10P.TabIndex = 149;
            this.J6_10P.TabStop = false;
            this.J6_10P.Visible = false;
            // 
            // J5_10P
            // 
            this.J5_10P.BackColor = System.Drawing.Color.Transparent;
            this.J5_10P.Location = new System.Drawing.Point(59, 496);
            this.J5_10P.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_10P.Name = "J5_10P";
            this.J5_10P.Size = new System.Drawing.Size(11, 12);
            this.J5_10P.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_10P.TabIndex = 148;
            this.J5_10P.TabStop = false;
            this.J5_10P.Visible = false;
            // 
            // J4_10P
            // 
            this.J4_10P.BackColor = System.Drawing.Color.Transparent;
            this.J4_10P.Location = new System.Drawing.Point(34, 496);
            this.J4_10P.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_10P.Name = "J4_10P";
            this.J4_10P.Size = new System.Drawing.Size(11, 12);
            this.J4_10P.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_10P.TabIndex = 147;
            this.J4_10P.TabStop = false;
            this.J4_10P.Visible = false;
            // 
            // J3_10P
            // 
            this.J3_10P.BackColor = System.Drawing.Color.Transparent;
            this.J3_10P.Location = new System.Drawing.Point(59, 482);
            this.J3_10P.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_10P.Name = "J3_10P";
            this.J3_10P.Size = new System.Drawing.Size(11, 12);
            this.J3_10P.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_10P.TabIndex = 146;
            this.J3_10P.TabStop = false;
            this.J3_10P.Visible = false;
            // 
            // J2_10P
            // 
            this.J2_10P.BackColor = System.Drawing.Color.Transparent;
            this.J2_10P.Location = new System.Drawing.Point(46, 482);
            this.J2_10P.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_10P.Name = "J2_10P";
            this.J2_10P.Size = new System.Drawing.Size(11, 12);
            this.J2_10P.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_10P.TabIndex = 145;
            this.J2_10P.TabStop = false;
            this.J2_10P.Visible = false;
            // 
            // J1_10P
            // 
            this.J1_10P.BackColor = System.Drawing.Color.Transparent;
            this.J1_10P.Location = new System.Drawing.Point(34, 482);
            this.J1_10P.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_10P.Name = "J1_10P";
            this.J1_10P.Size = new System.Drawing.Size(11, 12);
            this.J1_10P.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_10P.TabIndex = 144;
            this.J1_10P.TabStop = false;
            this.J1_10P.Visible = false;
            // 
            // J8_09
            // 
            this.J8_09.BackColor = System.Drawing.Color.Transparent;
            this.J8_09.Location = new System.Drawing.Point(105, 523);
            this.J8_09.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_09.Name = "J8_09";
            this.J8_09.Size = new System.Drawing.Size(11, 12);
            this.J8_09.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_09.TabIndex = 143;
            this.J8_09.TabStop = false;
            this.J8_09.Visible = false;
            // 
            // J7_09
            // 
            this.J7_09.BackColor = System.Drawing.Color.Transparent;
            this.J7_09.Location = new System.Drawing.Point(92, 523);
            this.J7_09.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_09.Name = "J7_09";
            this.J7_09.Size = new System.Drawing.Size(11, 12);
            this.J7_09.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_09.TabIndex = 142;
            this.J7_09.TabStop = false;
            this.J7_09.Visible = false;
            // 
            // J6_09
            // 
            this.J6_09.BackColor = System.Drawing.Color.Transparent;
            this.J6_09.Location = new System.Drawing.Point(80, 523);
            this.J6_09.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_09.Name = "J6_09";
            this.J6_09.Size = new System.Drawing.Size(11, 12);
            this.J6_09.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_09.TabIndex = 141;
            this.J6_09.TabStop = false;
            this.J6_09.Visible = false;
            // 
            // J5_09
            // 
            this.J5_09.BackColor = System.Drawing.Color.Transparent;
            this.J5_09.Location = new System.Drawing.Point(105, 509);
            this.J5_09.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_09.Name = "J5_09";
            this.J5_09.Size = new System.Drawing.Size(11, 12);
            this.J5_09.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_09.TabIndex = 140;
            this.J5_09.TabStop = false;
            this.J5_09.Visible = false;
            // 
            // J4_09
            // 
            this.J4_09.BackColor = System.Drawing.Color.Transparent;
            this.J4_09.Location = new System.Drawing.Point(80, 509);
            this.J4_09.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_09.Name = "J4_09";
            this.J4_09.Size = new System.Drawing.Size(11, 12);
            this.J4_09.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_09.TabIndex = 139;
            this.J4_09.TabStop = false;
            this.J4_09.Visible = false;
            // 
            // J3_09
            // 
            this.J3_09.BackColor = System.Drawing.Color.Transparent;
            this.J3_09.Location = new System.Drawing.Point(105, 496);
            this.J3_09.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_09.Name = "J3_09";
            this.J3_09.Size = new System.Drawing.Size(11, 12);
            this.J3_09.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_09.TabIndex = 138;
            this.J3_09.TabStop = false;
            this.J3_09.Visible = false;
            // 
            // J2_09
            // 
            this.J2_09.BackColor = System.Drawing.Color.Transparent;
            this.J2_09.Location = new System.Drawing.Point(92, 496);
            this.J2_09.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_09.Name = "J2_09";
            this.J2_09.Size = new System.Drawing.Size(11, 12);
            this.J2_09.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_09.TabIndex = 137;
            this.J2_09.TabStop = false;
            this.J2_09.Visible = false;
            // 
            // J1_09
            // 
            this.J1_09.BackColor = System.Drawing.Color.Transparent;
            this.J1_09.Location = new System.Drawing.Point(80, 496);
            this.J1_09.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_09.Name = "J1_09";
            this.J1_09.Size = new System.Drawing.Size(11, 12);
            this.J1_09.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_09.TabIndex = 136;
            this.J1_09.TabStop = false;
            this.J1_09.Visible = false;
            // 
            // J8_08
            // 
            this.J8_08.BackColor = System.Drawing.Color.Transparent;
            this.J8_08.Location = new System.Drawing.Point(146, 523);
            this.J8_08.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_08.Name = "J8_08";
            this.J8_08.Size = new System.Drawing.Size(11, 12);
            this.J8_08.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_08.TabIndex = 135;
            this.J8_08.TabStop = false;
            this.J8_08.Visible = false;
            // 
            // J7_08
            // 
            this.J7_08.BackColor = System.Drawing.Color.Transparent;
            this.J7_08.Location = new System.Drawing.Point(134, 523);
            this.J7_08.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_08.Name = "J7_08";
            this.J7_08.Size = new System.Drawing.Size(11, 12);
            this.J7_08.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_08.TabIndex = 134;
            this.J7_08.TabStop = false;
            this.J7_08.Visible = false;
            // 
            // J6_08
            // 
            this.J6_08.BackColor = System.Drawing.Color.Transparent;
            this.J6_08.Location = new System.Drawing.Point(121, 523);
            this.J6_08.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_08.Name = "J6_08";
            this.J6_08.Size = new System.Drawing.Size(11, 12);
            this.J6_08.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_08.TabIndex = 133;
            this.J6_08.TabStop = false;
            this.J6_08.Visible = false;
            // 
            // J5_08
            // 
            this.J5_08.BackColor = System.Drawing.Color.Transparent;
            this.J5_08.Location = new System.Drawing.Point(146, 509);
            this.J5_08.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_08.Name = "J5_08";
            this.J5_08.Size = new System.Drawing.Size(11, 12);
            this.J5_08.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_08.TabIndex = 132;
            this.J5_08.TabStop = false;
            this.J5_08.Visible = false;
            // 
            // J4_08
            // 
            this.J4_08.BackColor = System.Drawing.Color.Transparent;
            this.J4_08.Location = new System.Drawing.Point(121, 509);
            this.J4_08.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_08.Name = "J4_08";
            this.J4_08.Size = new System.Drawing.Size(11, 12);
            this.J4_08.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_08.TabIndex = 131;
            this.J4_08.TabStop = false;
            this.J4_08.Visible = false;
            // 
            // J3_08
            // 
            this.J3_08.BackColor = System.Drawing.Color.Transparent;
            this.J3_08.Location = new System.Drawing.Point(146, 496);
            this.J3_08.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_08.Name = "J3_08";
            this.J3_08.Size = new System.Drawing.Size(11, 12);
            this.J3_08.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_08.TabIndex = 130;
            this.J3_08.TabStop = false;
            this.J3_08.Visible = false;
            // 
            // J2_08
            // 
            this.J2_08.BackColor = System.Drawing.Color.Transparent;
            this.J2_08.Location = new System.Drawing.Point(134, 496);
            this.J2_08.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_08.Name = "J2_08";
            this.J2_08.Size = new System.Drawing.Size(11, 12);
            this.J2_08.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_08.TabIndex = 129;
            this.J2_08.TabStop = false;
            this.J2_08.Visible = false;
            // 
            // J1_08
            // 
            this.J1_08.BackColor = System.Drawing.Color.Transparent;
            this.J1_08.Location = new System.Drawing.Point(121, 496);
            this.J1_08.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_08.Name = "J1_08";
            this.J1_08.Size = new System.Drawing.Size(11, 12);
            this.J1_08.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_08.TabIndex = 128;
            this.J1_08.TabStop = false;
            this.J1_08.Visible = false;
            // 
            // J8_07
            // 
            this.J8_07.BackColor = System.Drawing.Color.Transparent;
            this.J8_07.Location = new System.Drawing.Point(186, 523);
            this.J8_07.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_07.Name = "J8_07";
            this.J8_07.Size = new System.Drawing.Size(11, 12);
            this.J8_07.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_07.TabIndex = 127;
            this.J8_07.TabStop = false;
            this.J8_07.Visible = false;
            // 
            // J7_07
            // 
            this.J7_07.BackColor = System.Drawing.Color.Transparent;
            this.J7_07.Location = new System.Drawing.Point(173, 523);
            this.J7_07.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_07.Name = "J7_07";
            this.J7_07.Size = new System.Drawing.Size(11, 12);
            this.J7_07.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_07.TabIndex = 126;
            this.J7_07.TabStop = false;
            this.J7_07.Visible = false;
            // 
            // J6_07
            // 
            this.J6_07.BackColor = System.Drawing.Color.Transparent;
            this.J6_07.Location = new System.Drawing.Point(160, 523);
            this.J6_07.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_07.Name = "J6_07";
            this.J6_07.Size = new System.Drawing.Size(11, 12);
            this.J6_07.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_07.TabIndex = 125;
            this.J6_07.TabStop = false;
            this.J6_07.Visible = false;
            // 
            // J5_07
            // 
            this.J5_07.BackColor = System.Drawing.Color.Transparent;
            this.J5_07.Location = new System.Drawing.Point(186, 509);
            this.J5_07.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_07.Name = "J5_07";
            this.J5_07.Size = new System.Drawing.Size(11, 12);
            this.J5_07.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_07.TabIndex = 124;
            this.J5_07.TabStop = false;
            this.J5_07.Visible = false;
            // 
            // J4_07
            // 
            this.J4_07.BackColor = System.Drawing.Color.Transparent;
            this.J4_07.Location = new System.Drawing.Point(160, 509);
            this.J4_07.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_07.Name = "J4_07";
            this.J4_07.Size = new System.Drawing.Size(11, 12);
            this.J4_07.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_07.TabIndex = 123;
            this.J4_07.TabStop = false;
            this.J4_07.Visible = false;
            // 
            // J3_07
            // 
            this.J3_07.BackColor = System.Drawing.Color.Transparent;
            this.J3_07.Location = new System.Drawing.Point(186, 496);
            this.J3_07.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_07.Name = "J3_07";
            this.J3_07.Size = new System.Drawing.Size(11, 12);
            this.J3_07.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_07.TabIndex = 122;
            this.J3_07.TabStop = false;
            this.J3_07.Visible = false;
            // 
            // J2_07
            // 
            this.J2_07.BackColor = System.Drawing.Color.Transparent;
            this.J2_07.Location = new System.Drawing.Point(173, 496);
            this.J2_07.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_07.Name = "J2_07";
            this.J2_07.Size = new System.Drawing.Size(11, 12);
            this.J2_07.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_07.TabIndex = 121;
            this.J2_07.TabStop = false;
            this.J2_07.Visible = false;
            // 
            // J1_07
            // 
            this.J1_07.BackColor = System.Drawing.Color.Transparent;
            this.J1_07.Location = new System.Drawing.Point(160, 496);
            this.J1_07.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_07.Name = "J1_07";
            this.J1_07.Size = new System.Drawing.Size(11, 12);
            this.J1_07.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_07.TabIndex = 120;
            this.J1_07.TabStop = false;
            this.J1_07.Visible = false;
            // 
            // J8_06
            // 
            this.J8_06.BackColor = System.Drawing.Color.Transparent;
            this.J8_06.Location = new System.Drawing.Point(227, 523);
            this.J8_06.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_06.Name = "J8_06";
            this.J8_06.Size = new System.Drawing.Size(11, 12);
            this.J8_06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_06.TabIndex = 119;
            this.J8_06.TabStop = false;
            this.J8_06.Visible = false;
            // 
            // J7_06
            // 
            this.J7_06.BackColor = System.Drawing.Color.Transparent;
            this.J7_06.Location = new System.Drawing.Point(214, 523);
            this.J7_06.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_06.Name = "J7_06";
            this.J7_06.Size = new System.Drawing.Size(11, 12);
            this.J7_06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_06.TabIndex = 118;
            this.J7_06.TabStop = false;
            this.J7_06.Visible = false;
            // 
            // J6_06
            // 
            this.J6_06.BackColor = System.Drawing.Color.Transparent;
            this.J6_06.Location = new System.Drawing.Point(202, 523);
            this.J6_06.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_06.Name = "J6_06";
            this.J6_06.Size = new System.Drawing.Size(11, 12);
            this.J6_06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_06.TabIndex = 117;
            this.J6_06.TabStop = false;
            this.J6_06.Visible = false;
            // 
            // J5_06
            // 
            this.J5_06.BackColor = System.Drawing.Color.Transparent;
            this.J5_06.Location = new System.Drawing.Point(227, 509);
            this.J5_06.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_06.Name = "J5_06";
            this.J5_06.Size = new System.Drawing.Size(11, 12);
            this.J5_06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_06.TabIndex = 116;
            this.J5_06.TabStop = false;
            this.J5_06.Visible = false;
            // 
            // J4_06
            // 
            this.J4_06.BackColor = System.Drawing.Color.Transparent;
            this.J4_06.Location = new System.Drawing.Point(202, 509);
            this.J4_06.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_06.Name = "J4_06";
            this.J4_06.Size = new System.Drawing.Size(11, 12);
            this.J4_06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_06.TabIndex = 115;
            this.J4_06.TabStop = false;
            this.J4_06.Visible = false;
            // 
            // J3_06
            // 
            this.J3_06.BackColor = System.Drawing.Color.Transparent;
            this.J3_06.Location = new System.Drawing.Point(227, 496);
            this.J3_06.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_06.Name = "J3_06";
            this.J3_06.Size = new System.Drawing.Size(11, 12);
            this.J3_06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_06.TabIndex = 114;
            this.J3_06.TabStop = false;
            this.J3_06.Visible = false;
            // 
            // J2_06
            // 
            this.J2_06.BackColor = System.Drawing.Color.Transparent;
            this.J2_06.Location = new System.Drawing.Point(214, 496);
            this.J2_06.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_06.Name = "J2_06";
            this.J2_06.Size = new System.Drawing.Size(11, 12);
            this.J2_06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_06.TabIndex = 113;
            this.J2_06.TabStop = false;
            this.J2_06.Visible = false;
            // 
            // J1_06
            // 
            this.J1_06.BackColor = System.Drawing.Color.Transparent;
            this.J1_06.Location = new System.Drawing.Point(202, 496);
            this.J1_06.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_06.Name = "J1_06";
            this.J1_06.Size = new System.Drawing.Size(11, 12);
            this.J1_06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_06.TabIndex = 112;
            this.J1_06.TabStop = false;
            this.J1_06.Visible = false;
            // 
            // J8_05
            // 
            this.J8_05.BackColor = System.Drawing.Color.Transparent;
            this.J8_05.Location = new System.Drawing.Point(268, 523);
            this.J8_05.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_05.Name = "J8_05";
            this.J8_05.Size = new System.Drawing.Size(11, 12);
            this.J8_05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_05.TabIndex = 111;
            this.J8_05.TabStop = false;
            this.J8_05.Visible = false;
            // 
            // J7_05
            // 
            this.J7_05.BackColor = System.Drawing.Color.Transparent;
            this.J7_05.Location = new System.Drawing.Point(255, 523);
            this.J7_05.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_05.Name = "J7_05";
            this.J7_05.Size = new System.Drawing.Size(11, 12);
            this.J7_05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_05.TabIndex = 110;
            this.J7_05.TabStop = false;
            this.J7_05.Visible = false;
            // 
            // J6_05
            // 
            this.J6_05.BackColor = System.Drawing.Color.Transparent;
            this.J6_05.Location = new System.Drawing.Point(242, 523);
            this.J6_05.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_05.Name = "J6_05";
            this.J6_05.Size = new System.Drawing.Size(11, 12);
            this.J6_05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_05.TabIndex = 109;
            this.J6_05.TabStop = false;
            this.J6_05.Visible = false;
            // 
            // J5_05
            // 
            this.J5_05.BackColor = System.Drawing.Color.Transparent;
            this.J5_05.Location = new System.Drawing.Point(268, 509);
            this.J5_05.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_05.Name = "J5_05";
            this.J5_05.Size = new System.Drawing.Size(11, 12);
            this.J5_05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_05.TabIndex = 108;
            this.J5_05.TabStop = false;
            this.J5_05.Visible = false;
            // 
            // J4_05
            // 
            this.J4_05.BackColor = System.Drawing.Color.Transparent;
            this.J4_05.Location = new System.Drawing.Point(242, 509);
            this.J4_05.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_05.Name = "J4_05";
            this.J4_05.Size = new System.Drawing.Size(11, 12);
            this.J4_05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_05.TabIndex = 107;
            this.J4_05.TabStop = false;
            this.J4_05.Visible = false;
            // 
            // J3_05
            // 
            this.J3_05.BackColor = System.Drawing.Color.Transparent;
            this.J3_05.Location = new System.Drawing.Point(268, 496);
            this.J3_05.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_05.Name = "J3_05";
            this.J3_05.Size = new System.Drawing.Size(11, 12);
            this.J3_05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_05.TabIndex = 106;
            this.J3_05.TabStop = false;
            this.J3_05.Visible = false;
            // 
            // J2_05
            // 
            this.J2_05.BackColor = System.Drawing.Color.Transparent;
            this.J2_05.Location = new System.Drawing.Point(255, 496);
            this.J2_05.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_05.Name = "J2_05";
            this.J2_05.Size = new System.Drawing.Size(11, 12);
            this.J2_05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_05.TabIndex = 105;
            this.J2_05.TabStop = false;
            this.J2_05.Visible = false;
            // 
            // J1_05
            // 
            this.J1_05.BackColor = System.Drawing.Color.Transparent;
            this.J1_05.Location = new System.Drawing.Point(242, 496);
            this.J1_05.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_05.Name = "J1_05";
            this.J1_05.Size = new System.Drawing.Size(11, 12);
            this.J1_05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_05.TabIndex = 104;
            this.J1_05.TabStop = false;
            this.J1_05.Visible = false;
            // 
            // J8_04
            // 
            this.J8_04.BackColor = System.Drawing.Color.Transparent;
            this.J8_04.Location = new System.Drawing.Point(308, 523);
            this.J8_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_04.Name = "J8_04";
            this.J8_04.Size = new System.Drawing.Size(11, 12);
            this.J8_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_04.TabIndex = 103;
            this.J8_04.TabStop = false;
            this.J8_04.Visible = false;
            // 
            // J7_04
            // 
            this.J7_04.BackColor = System.Drawing.Color.Transparent;
            this.J7_04.Location = new System.Drawing.Point(296, 523);
            this.J7_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_04.Name = "J7_04";
            this.J7_04.Size = new System.Drawing.Size(11, 12);
            this.J7_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_04.TabIndex = 102;
            this.J7_04.TabStop = false;
            this.J7_04.Visible = false;
            // 
            // J6_04
            // 
            this.J6_04.BackColor = System.Drawing.Color.Transparent;
            this.J6_04.Location = new System.Drawing.Point(283, 523);
            this.J6_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_04.Name = "J6_04";
            this.J6_04.Size = new System.Drawing.Size(11, 12);
            this.J6_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_04.TabIndex = 101;
            this.J6_04.TabStop = false;
            this.J6_04.Visible = false;
            // 
            // J5_04
            // 
            this.J5_04.BackColor = System.Drawing.Color.Transparent;
            this.J5_04.Location = new System.Drawing.Point(308, 509);
            this.J5_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_04.Name = "J5_04";
            this.J5_04.Size = new System.Drawing.Size(11, 12);
            this.J5_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_04.TabIndex = 100;
            this.J5_04.TabStop = false;
            this.J5_04.Visible = false;
            // 
            // J4_04
            // 
            this.J4_04.BackColor = System.Drawing.Color.Transparent;
            this.J4_04.Location = new System.Drawing.Point(283, 509);
            this.J4_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_04.Name = "J4_04";
            this.J4_04.Size = new System.Drawing.Size(11, 12);
            this.J4_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_04.TabIndex = 99;
            this.J4_04.TabStop = false;
            this.J4_04.Visible = false;
            // 
            // J3_04
            // 
            this.J3_04.BackColor = System.Drawing.Color.Transparent;
            this.J3_04.Location = new System.Drawing.Point(308, 496);
            this.J3_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_04.Name = "J3_04";
            this.J3_04.Size = new System.Drawing.Size(11, 12);
            this.J3_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_04.TabIndex = 98;
            this.J3_04.TabStop = false;
            this.J3_04.Visible = false;
            // 
            // J2_04
            // 
            this.J2_04.BackColor = System.Drawing.Color.Transparent;
            this.J2_04.Location = new System.Drawing.Point(296, 496);
            this.J2_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_04.Name = "J2_04";
            this.J2_04.Size = new System.Drawing.Size(11, 12);
            this.J2_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_04.TabIndex = 97;
            this.J2_04.TabStop = false;
            this.J2_04.Visible = false;
            // 
            // J1_04
            // 
            this.J1_04.BackColor = System.Drawing.Color.Transparent;
            this.J1_04.Location = new System.Drawing.Point(283, 496);
            this.J1_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_04.Name = "J1_04";
            this.J1_04.Size = new System.Drawing.Size(11, 12);
            this.J1_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_04.TabIndex = 96;
            this.J1_04.TabStop = false;
            this.J1_04.Visible = false;
            // 
            // J8_03
            // 
            this.J8_03.BackColor = System.Drawing.Color.Transparent;
            this.J8_03.Location = new System.Drawing.Point(349, 523);
            this.J8_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_03.Name = "J8_03";
            this.J8_03.Size = new System.Drawing.Size(11, 12);
            this.J8_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_03.TabIndex = 95;
            this.J8_03.TabStop = false;
            this.J8_03.Visible = false;
            // 
            // J7_03
            // 
            this.J7_03.BackColor = System.Drawing.Color.Transparent;
            this.J7_03.Location = new System.Drawing.Point(336, 523);
            this.J7_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_03.Name = "J7_03";
            this.J7_03.Size = new System.Drawing.Size(11, 12);
            this.J7_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_03.TabIndex = 94;
            this.J7_03.TabStop = false;
            this.J7_03.Visible = false;
            // 
            // J6_03
            // 
            this.J6_03.BackColor = System.Drawing.Color.Transparent;
            this.J6_03.Location = new System.Drawing.Point(323, 523);
            this.J6_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_03.Name = "J6_03";
            this.J6_03.Size = new System.Drawing.Size(11, 12);
            this.J6_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_03.TabIndex = 93;
            this.J6_03.TabStop = false;
            this.J6_03.Visible = false;
            // 
            // J5_03
            // 
            this.J5_03.BackColor = System.Drawing.Color.Transparent;
            this.J5_03.Location = new System.Drawing.Point(349, 509);
            this.J5_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_03.Name = "J5_03";
            this.J5_03.Size = new System.Drawing.Size(11, 12);
            this.J5_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_03.TabIndex = 92;
            this.J5_03.TabStop = false;
            this.J5_03.Visible = false;
            // 
            // J4_03
            // 
            this.J4_03.BackColor = System.Drawing.Color.Transparent;
            this.J4_03.Location = new System.Drawing.Point(323, 509);
            this.J4_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_03.Name = "J4_03";
            this.J4_03.Size = new System.Drawing.Size(11, 12);
            this.J4_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_03.TabIndex = 91;
            this.J4_03.TabStop = false;
            this.J4_03.Visible = false;
            // 
            // J3_03
            // 
            this.J3_03.BackColor = System.Drawing.Color.Transparent;
            this.J3_03.Location = new System.Drawing.Point(349, 496);
            this.J3_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_03.Name = "J3_03";
            this.J3_03.Size = new System.Drawing.Size(11, 12);
            this.J3_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_03.TabIndex = 90;
            this.J3_03.TabStop = false;
            this.J3_03.Visible = false;
            // 
            // J2_03
            // 
            this.J2_03.BackColor = System.Drawing.Color.Transparent;
            this.J2_03.Location = new System.Drawing.Point(336, 496);
            this.J2_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_03.Name = "J2_03";
            this.J2_03.Size = new System.Drawing.Size(11, 12);
            this.J2_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_03.TabIndex = 89;
            this.J2_03.TabStop = false;
            this.J2_03.Visible = false;
            // 
            // J1_03
            // 
            this.J1_03.BackColor = System.Drawing.Color.Transparent;
            this.J1_03.Location = new System.Drawing.Point(323, 496);
            this.J1_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_03.Name = "J1_03";
            this.J1_03.Size = new System.Drawing.Size(11, 12);
            this.J1_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_03.TabIndex = 88;
            this.J1_03.TabStop = false;
            this.J1_03.Visible = false;
            // 
            // J8_02
            // 
            this.J8_02.BackColor = System.Drawing.Color.Transparent;
            this.J8_02.Location = new System.Drawing.Point(388, 523);
            this.J8_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_02.Name = "J8_02";
            this.J8_02.Size = new System.Drawing.Size(11, 12);
            this.J8_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_02.TabIndex = 87;
            this.J8_02.TabStop = false;
            this.J8_02.Visible = false;
            // 
            // J7_02
            // 
            this.J7_02.BackColor = System.Drawing.Color.Transparent;
            this.J7_02.Location = new System.Drawing.Point(376, 523);
            this.J7_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_02.Name = "J7_02";
            this.J7_02.Size = new System.Drawing.Size(11, 12);
            this.J7_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_02.TabIndex = 86;
            this.J7_02.TabStop = false;
            this.J7_02.Visible = false;
            // 
            // J6_02
            // 
            this.J6_02.BackColor = System.Drawing.Color.Transparent;
            this.J6_02.Location = new System.Drawing.Point(363, 523);
            this.J6_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_02.Name = "J6_02";
            this.J6_02.Size = new System.Drawing.Size(11, 12);
            this.J6_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_02.TabIndex = 85;
            this.J6_02.TabStop = false;
            this.J6_02.Visible = false;
            // 
            // J5_02
            // 
            this.J5_02.BackColor = System.Drawing.Color.Transparent;
            this.J5_02.Location = new System.Drawing.Point(388, 509);
            this.J5_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_02.Name = "J5_02";
            this.J5_02.Size = new System.Drawing.Size(11, 12);
            this.J5_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_02.TabIndex = 84;
            this.J5_02.TabStop = false;
            this.J5_02.Visible = false;
            // 
            // J4_02
            // 
            this.J4_02.BackColor = System.Drawing.Color.Transparent;
            this.J4_02.Location = new System.Drawing.Point(363, 509);
            this.J4_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_02.Name = "J4_02";
            this.J4_02.Size = new System.Drawing.Size(11, 12);
            this.J4_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_02.TabIndex = 83;
            this.J4_02.TabStop = false;
            this.J4_02.Visible = false;
            // 
            // J3_02
            // 
            this.J3_02.BackColor = System.Drawing.Color.Transparent;
            this.J3_02.Location = new System.Drawing.Point(388, 496);
            this.J3_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_02.Name = "J3_02";
            this.J3_02.Size = new System.Drawing.Size(11, 12);
            this.J3_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_02.TabIndex = 82;
            this.J3_02.TabStop = false;
            this.J3_02.Visible = false;
            // 
            // J2_02
            // 
            this.J2_02.BackColor = System.Drawing.Color.Transparent;
            this.J2_02.Location = new System.Drawing.Point(376, 496);
            this.J2_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_02.Name = "J2_02";
            this.J2_02.Size = new System.Drawing.Size(11, 12);
            this.J2_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_02.TabIndex = 81;
            this.J2_02.TabStop = false;
            this.J2_02.Visible = false;
            // 
            // J1_02
            // 
            this.J1_02.BackColor = System.Drawing.Color.Transparent;
            this.J1_02.Location = new System.Drawing.Point(363, 496);
            this.J1_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_02.Name = "J1_02";
            this.J1_02.Size = new System.Drawing.Size(11, 12);
            this.J1_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_02.TabIndex = 80;
            this.J1_02.TabStop = false;
            this.J1_02.Visible = false;
            // 
            // J8_01
            // 
            this.J8_01.BackColor = System.Drawing.Color.Transparent;
            this.J8_01.Location = new System.Drawing.Point(429, 523);
            this.J8_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_01.Name = "J8_01";
            this.J8_01.Size = new System.Drawing.Size(11, 12);
            this.J8_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_01.TabIndex = 79;
            this.J8_01.TabStop = false;
            this.J8_01.Visible = false;
            // 
            // J7_01
            // 
            this.J7_01.BackColor = System.Drawing.Color.Transparent;
            this.J7_01.Location = new System.Drawing.Point(416, 523);
            this.J7_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_01.Name = "J7_01";
            this.J7_01.Size = new System.Drawing.Size(11, 12);
            this.J7_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_01.TabIndex = 78;
            this.J7_01.TabStop = false;
            this.J7_01.Visible = false;
            // 
            // J6_01
            // 
            this.J6_01.BackColor = System.Drawing.Color.Transparent;
            this.J6_01.Location = new System.Drawing.Point(404, 523);
            this.J6_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_01.Name = "J6_01";
            this.J6_01.Size = new System.Drawing.Size(11, 12);
            this.J6_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_01.TabIndex = 77;
            this.J6_01.TabStop = false;
            this.J6_01.Visible = false;
            // 
            // J5_01
            // 
            this.J5_01.BackColor = System.Drawing.Color.Transparent;
            this.J5_01.Location = new System.Drawing.Point(429, 509);
            this.J5_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_01.Name = "J5_01";
            this.J5_01.Size = new System.Drawing.Size(11, 12);
            this.J5_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_01.TabIndex = 76;
            this.J5_01.TabStop = false;
            this.J5_01.Visible = false;
            // 
            // J4_01
            // 
            this.J4_01.BackColor = System.Drawing.Color.Transparent;
            this.J4_01.Location = new System.Drawing.Point(404, 509);
            this.J4_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_01.Name = "J4_01";
            this.J4_01.Size = new System.Drawing.Size(11, 12);
            this.J4_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_01.TabIndex = 75;
            this.J4_01.TabStop = false;
            this.J4_01.Visible = false;
            // 
            // J3_01
            // 
            this.J3_01.BackColor = System.Drawing.Color.Transparent;
            this.J3_01.Location = new System.Drawing.Point(429, 496);
            this.J3_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_01.Name = "J3_01";
            this.J3_01.Size = new System.Drawing.Size(11, 12);
            this.J3_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_01.TabIndex = 74;
            this.J3_01.TabStop = false;
            this.J3_01.Visible = false;
            // 
            // J2_01
            // 
            this.J2_01.BackColor = System.Drawing.Color.Transparent;
            this.J2_01.Location = new System.Drawing.Point(416, 496);
            this.J2_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_01.Name = "J2_01";
            this.J2_01.Size = new System.Drawing.Size(11, 12);
            this.J2_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_01.TabIndex = 73;
            this.J2_01.TabStop = false;
            this.J2_01.Visible = false;
            // 
            // J1_01
            // 
            this.J1_01.BackColor = System.Drawing.Color.Transparent;
            this.J1_01.Location = new System.Drawing.Point(404, 496);
            this.J1_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_01.Name = "J1_01";
            this.J1_01.Size = new System.Drawing.Size(11, 12);
            this.J1_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_01.TabIndex = 72;
            this.J1_01.TabStop = false;
            this.J1_01.Visible = false;
            // 
            // J8_00
            // 
            this.J8_00.BackColor = System.Drawing.Color.Transparent;
            this.J8_00.Location = new System.Drawing.Point(494, 500);
            this.J8_00.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J8_00.Name = "J8_00";
            this.J8_00.Size = new System.Drawing.Size(11, 12);
            this.J8_00.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J8_00.TabIndex = 71;
            this.J8_00.TabStop = false;
            this.J8_00.Visible = false;
            // 
            // J7_00
            // 
            this.J7_00.BackColor = System.Drawing.Color.Transparent;
            this.J7_00.Location = new System.Drawing.Point(478, 500);
            this.J7_00.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J7_00.Name = "J7_00";
            this.J7_00.Size = new System.Drawing.Size(11, 12);
            this.J7_00.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J7_00.TabIndex = 70;
            this.J7_00.TabStop = false;
            this.J7_00.Visible = false;
            // 
            // J6_00
            // 
            this.J6_00.BackColor = System.Drawing.Color.Transparent;
            this.J6_00.Location = new System.Drawing.Point(463, 500);
            this.J6_00.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J6_00.Name = "J6_00";
            this.J6_00.Size = new System.Drawing.Size(11, 12);
            this.J6_00.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J6_00.TabIndex = 69;
            this.J6_00.TabStop = false;
            this.J6_00.Visible = false;
            // 
            // J5_00
            // 
            this.J5_00.BackColor = System.Drawing.Color.Transparent;
            this.J5_00.Location = new System.Drawing.Point(447, 500);
            this.J5_00.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J5_00.Name = "J5_00";
            this.J5_00.Size = new System.Drawing.Size(11, 12);
            this.J5_00.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J5_00.TabIndex = 68;
            this.J5_00.TabStop = false;
            this.J5_00.Visible = false;
            // 
            // J4_00
            // 
            this.J4_00.BackColor = System.Drawing.Color.Transparent;
            this.J4_00.Location = new System.Drawing.Point(494, 484);
            this.J4_00.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J4_00.Name = "J4_00";
            this.J4_00.Size = new System.Drawing.Size(11, 12);
            this.J4_00.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J4_00.TabIndex = 67;
            this.J4_00.TabStop = false;
            this.J4_00.Visible = false;
            // 
            // J3_00
            // 
            this.J3_00.BackColor = System.Drawing.Color.Transparent;
            this.J3_00.Location = new System.Drawing.Point(478, 484);
            this.J3_00.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J3_00.Name = "J3_00";
            this.J3_00.Size = new System.Drawing.Size(11, 12);
            this.J3_00.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J3_00.TabIndex = 66;
            this.J3_00.TabStop = false;
            this.J3_00.Visible = false;
            // 
            // J2_00
            // 
            this.J2_00.BackColor = System.Drawing.Color.Transparent;
            this.J2_00.Location = new System.Drawing.Point(463, 484);
            this.J2_00.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J2_00.Name = "J2_00";
            this.J2_00.Size = new System.Drawing.Size(11, 12);
            this.J2_00.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J2_00.TabIndex = 65;
            this.J2_00.TabStop = false;
            this.J2_00.Visible = false;
            // 
            // J1_00
            // 
            this.J1_00.BackColor = System.Drawing.SystemColors.Control;
            this.J1_00.Location = new System.Drawing.Point(447, 484);
            this.J1_00.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.J1_00.Name = "J1_00";
            this.J1_00.Size = new System.Drawing.Size(11, 12);
            this.J1_00.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.J1_00.TabIndex = 64;
            this.J1_00.TabStop = false;
            this.J1_00.Visible = false;
            this.J1_00.Click += new System.EventHandler(this.casa1_Click);
            // 
            // prop39
            // 
            this.prop39.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop39.Location = new System.Drawing.Point(503, 436);
            this.prop39.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop39.Name = "prop39";
            this.prop39.Size = new System.Drawing.Size(8, 37);
            this.prop39.TabIndex = 42;
            this.prop39.TabStop = false;
            this.prop39.Visible = false;
            this.prop39.Click += new System.EventHandler(this.prop39_Click);
            // 
            // prop37
            // 
            this.prop37.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop37.Location = new System.Drawing.Point(504, 349);
            this.prop37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop37.Name = "prop37";
            this.prop37.Size = new System.Drawing.Size(8, 37);
            this.prop37.TabIndex = 41;
            this.prop37.TabStop = false;
            this.prop37.Visible = false;
            // 
            // prop35
            // 
            this.prop35.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop35.Location = new System.Drawing.Point(503, 260);
            this.prop35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop35.Name = "prop35";
            this.prop35.Size = new System.Drawing.Size(8, 37);
            this.prop35.TabIndex = 40;
            this.prop35.TabStop = false;
            this.prop35.Visible = false;
            // 
            // prop34
            // 
            this.prop34.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop34.Location = new System.Drawing.Point(504, 216);
            this.prop34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop34.Name = "prop34";
            this.prop34.Size = new System.Drawing.Size(8, 37);
            this.prop34.TabIndex = 39;
            this.prop34.TabStop = false;
            this.prop34.Visible = false;
            // 
            // prop32
            // 
            this.prop32.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop32.Location = new System.Drawing.Point(504, 128);
            this.prop32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop32.Name = "prop32";
            this.prop32.Size = new System.Drawing.Size(8, 37);
            this.prop32.TabIndex = 38;
            this.prop32.TabStop = false;
            this.prop32.Visible = false;
            // 
            // prop31
            // 
            this.prop31.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop31.Location = new System.Drawing.Point(504, 84);
            this.prop31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop31.Name = "prop31";
            this.prop31.Size = new System.Drawing.Size(8, 37);
            this.prop31.TabIndex = 37;
            this.prop31.TabStop = false;
            this.prop31.Visible = false;
            // 
            // prop29
            // 
            this.prop29.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop29.Location = new System.Drawing.Point(406, 10);
            this.prop29.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop29.Name = "prop29";
            this.prop29.Size = new System.Drawing.Size(35, 9);
            this.prop29.TabIndex = 36;
            this.prop29.TabStop = false;
            this.prop29.Visible = false;
            // 
            // prop28
            // 
            this.prop28.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop28.Location = new System.Drawing.Point(366, 10);
            this.prop28.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop28.Name = "prop28";
            this.prop28.Size = new System.Drawing.Size(35, 9);
            this.prop28.TabIndex = 35;
            this.prop28.TabStop = false;
            this.prop28.Visible = false;
            // 
            // prop27
            // 
            this.prop27.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop27.Location = new System.Drawing.Point(325, 10);
            this.prop27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop27.Name = "prop27";
            this.prop27.Size = new System.Drawing.Size(35, 9);
            this.prop27.TabIndex = 34;
            this.prop27.TabStop = false;
            this.prop27.Visible = false;
            // 
            // prop26
            // 
            this.prop26.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop26.Location = new System.Drawing.Point(284, 10);
            this.prop26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop26.Name = "prop26";
            this.prop26.Size = new System.Drawing.Size(35, 9);
            this.prop26.TabIndex = 33;
            this.prop26.TabStop = false;
            this.prop26.Visible = false;
            // 
            // prop25
            // 
            this.prop25.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop25.Location = new System.Drawing.Point(244, 10);
            this.prop25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop25.Name = "prop25";
            this.prop25.Size = new System.Drawing.Size(35, 9);
            this.prop25.TabIndex = 32;
            this.prop25.TabStop = false;
            this.prop25.Visible = false;
            // 
            // prop24
            // 
            this.prop24.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop24.Location = new System.Drawing.Point(202, 10);
            this.prop24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop24.Name = "prop24";
            this.prop24.Size = new System.Drawing.Size(35, 9);
            this.prop24.TabIndex = 31;
            this.prop24.TabStop = false;
            this.prop24.Visible = false;
            // 
            // prop23
            // 
            this.prop23.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop23.Location = new System.Drawing.Point(162, 10);
            this.prop23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop23.Name = "prop23";
            this.prop23.Size = new System.Drawing.Size(35, 9);
            this.prop23.TabIndex = 30;
            this.prop23.TabStop = false;
            this.prop23.Visible = false;
            // 
            // prop21
            // 
            this.prop21.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop21.Location = new System.Drawing.Point(80, 10);
            this.prop21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop21.Name = "prop21";
            this.prop21.Size = new System.Drawing.Size(35, 9);
            this.prop21.TabIndex = 29;
            this.prop21.TabStop = false;
            this.prop21.Visible = false;
            // 
            // prop19
            // 
            this.prop19.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop19.Location = new System.Drawing.Point(9, 84);
            this.prop19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop19.Name = "prop19";
            this.prop19.Size = new System.Drawing.Size(8, 37);
            this.prop19.TabIndex = 28;
            this.prop19.TabStop = false;
            this.prop19.Visible = false;
            // 
            // prop18
            // 
            this.prop18.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop18.Location = new System.Drawing.Point(9, 128);
            this.prop18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop18.Name = "prop18";
            this.prop18.Size = new System.Drawing.Size(8, 37);
            this.prop18.TabIndex = 27;
            this.prop18.TabStop = false;
            this.prop18.Visible = false;
            // 
            // prop16
            // 
            this.prop16.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop16.Location = new System.Drawing.Point(9, 216);
            this.prop16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop16.Name = "prop16";
            this.prop16.Size = new System.Drawing.Size(8, 37);
            this.prop16.TabIndex = 26;
            this.prop16.TabStop = false;
            this.prop16.Visible = false;
            // 
            // prop15
            // 
            this.prop15.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop15.Location = new System.Drawing.Point(9, 260);
            this.prop15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop15.Name = "prop15";
            this.prop15.Size = new System.Drawing.Size(8, 37);
            this.prop15.TabIndex = 25;
            this.prop15.TabStop = false;
            this.prop15.Visible = false;
            // 
            // prop14
            // 
            this.prop14.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop14.Location = new System.Drawing.Point(9, 305);
            this.prop14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop14.Name = "prop14";
            this.prop14.Size = new System.Drawing.Size(8, 37);
            this.prop14.TabIndex = 24;
            this.prop14.TabStop = false;
            this.prop14.Visible = false;
            // 
            // prop13
            // 
            this.prop13.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop13.Location = new System.Drawing.Point(9, 349);
            this.prop13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop13.Name = "prop13";
            this.prop13.Size = new System.Drawing.Size(8, 37);
            this.prop13.TabIndex = 23;
            this.prop13.TabStop = false;
            this.prop13.Visible = false;
            // 
            // prop12
            // 
            this.prop12.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop12.Location = new System.Drawing.Point(9, 392);
            this.prop12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop12.Name = "prop12";
            this.prop12.Size = new System.Drawing.Size(8, 37);
            this.prop12.TabIndex = 22;
            this.prop12.TabStop = false;
            this.prop12.Visible = false;
            // 
            // prop11
            // 
            this.prop11.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop11.Location = new System.Drawing.Point(9, 436);
            this.prop11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop11.Name = "prop11";
            this.prop11.Size = new System.Drawing.Size(8, 37);
            this.prop11.TabIndex = 21;
            this.prop11.TabStop = false;
            this.prop11.Visible = false;
            // 
            // prop9
            // 
            this.prop9.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop9.Location = new System.Drawing.Point(80, 540);
            this.prop9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop9.Name = "prop9";
            this.prop9.Size = new System.Drawing.Size(35, 9);
            this.prop9.TabIndex = 20;
            this.prop9.TabStop = false;
            this.prop9.Visible = false;
            // 
            // prop8
            // 
            this.prop8.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop8.Location = new System.Drawing.Point(122, 540);
            this.prop8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop8.Name = "prop8";
            this.prop8.Size = new System.Drawing.Size(35, 9);
            this.prop8.TabIndex = 19;
            this.prop8.TabStop = false;
            this.prop8.Visible = false;
            // 
            // prop6
            // 
            this.prop6.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop6.Location = new System.Drawing.Point(203, 540);
            this.prop6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop6.Name = "prop6";
            this.prop6.Size = new System.Drawing.Size(35, 9);
            this.prop6.TabIndex = 18;
            this.prop6.TabStop = false;
            this.prop6.Visible = false;
            // 
            // prop5
            // 
            this.prop5.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop5.Location = new System.Drawing.Point(244, 540);
            this.prop5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop5.Name = "prop5";
            this.prop5.Size = new System.Drawing.Size(35, 9);
            this.prop5.TabIndex = 17;
            this.prop5.TabStop = false;
            this.prop5.Visible = false;
            // 
            // prop3
            // 
            this.prop3.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop3.Location = new System.Drawing.Point(325, 540);
            this.prop3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop3.Name = "prop3";
            this.prop3.Size = new System.Drawing.Size(35, 9);
            this.prop3.TabIndex = 16;
            this.prop3.TabStop = false;
            this.prop3.Visible = false;
            // 
            // prop1
            // 
            this.prop1.BackColor = System.Drawing.SystemColors.Highlight;
            this.prop1.Location = new System.Drawing.Point(404, 540);
            this.prop1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prop1.Name = "prop1";
            this.prop1.Size = new System.Drawing.Size(35, 9);
            this.prop1.TabIndex = 15;
            this.prop1.TabStop = false;
            this.prop1.Visible = false;
            this.prop1.Click += new System.EventHandler(this.prop1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = global::Monopoly.Properties.Resources._22790935_1507698452647255_1483476998_o;
            this.pictureBox1.Location = new System.Drawing.Point(9, 7);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(502, 541);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(759, 358);
            this.button4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(240, 34);
            this.button4.TabIndex = 384;
            this.button4.Text = "Declarar Falência";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // C1_04
            // 
            this.C1_04.BackColor = System.Drawing.Color.Transparent;
            this.C1_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C1_04.Location = new System.Drawing.Point(403, 472);
            this.C1_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C1_04.Name = "C1_04";
            this.C1_04.Size = new System.Drawing.Size(11, 12);
            this.C1_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C1_04.TabIndex = 385;
            this.C1_04.TabStop = false;
            this.C1_04.Visible = false;
            // 
            // C1_01
            // 
            this.C1_01.BackColor = System.Drawing.Color.Transparent;
            this.C1_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C1_01.Location = new System.Drawing.Point(411, 479);
            this.C1_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C1_01.Name = "C1_01";
            this.C1_01.Size = new System.Drawing.Size(11, 12);
            this.C1_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C1_01.TabIndex = 386;
            this.C1_01.TabStop = false;
            this.C1_01.Visible = false;
            // 
            // C1_03
            // 
            this.C1_03.BackColor = System.Drawing.Color.Transparent;
            this.C1_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C1_03.Location = new System.Drawing.Point(420, 473);
            this.C1_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C1_03.Name = "C1_03";
            this.C1_03.Size = new System.Drawing.Size(11, 12);
            this.C1_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C1_03.TabIndex = 387;
            this.C1_03.TabStop = false;
            this.C1_03.Visible = false;
            // 
            // C1_02
            // 
            this.C1_02.BackColor = System.Drawing.Color.Transparent;
            this.C1_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C1_02.Location = new System.Drawing.Point(428, 479);
            this.C1_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C1_02.Name = "C1_02";
            this.C1_02.Size = new System.Drawing.Size(11, 12);
            this.C1_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C1_02.TabIndex = 388;
            this.C1_02.TabStop = false;
            this.C1_02.Visible = false;
            // 
            // C3_02
            // 
            this.C3_02.BackColor = System.Drawing.Color.Transparent;
            this.C3_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C3_02.Location = new System.Drawing.Point(350, 480);
            this.C3_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C3_02.Name = "C3_02";
            this.C3_02.Size = new System.Drawing.Size(11, 12);
            this.C3_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C3_02.TabIndex = 392;
            this.C3_02.TabStop = false;
            this.C3_02.Visible = false;
            // 
            // C3_03
            // 
            this.C3_03.BackColor = System.Drawing.Color.Transparent;
            this.C3_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C3_03.Location = new System.Drawing.Point(341, 474);
            this.C3_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C3_03.Name = "C3_03";
            this.C3_03.Size = new System.Drawing.Size(11, 12);
            this.C3_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C3_03.TabIndex = 391;
            this.C3_03.TabStop = false;
            this.C3_03.Visible = false;
            // 
            // C3_01
            // 
            this.C3_01.BackColor = System.Drawing.Color.Transparent;
            this.C3_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C3_01.Location = new System.Drawing.Point(332, 479);
            this.C3_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C3_01.Name = "C3_01";
            this.C3_01.Size = new System.Drawing.Size(11, 12);
            this.C3_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C3_01.TabIndex = 390;
            this.C3_01.TabStop = false;
            this.C3_01.Visible = false;
            // 
            // C3_04
            // 
            this.C3_04.BackColor = System.Drawing.Color.Transparent;
            this.C3_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C3_04.Location = new System.Drawing.Point(324, 473);
            this.C3_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C3_04.Name = "C3_04";
            this.C3_04.Size = new System.Drawing.Size(11, 12);
            this.C3_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C3_04.TabIndex = 389;
            this.C3_04.TabStop = false;
            this.C3_04.Visible = false;
            // 
            // C6_02
            // 
            this.C6_02.BackColor = System.Drawing.Color.Transparent;
            this.C6_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C6_02.Location = new System.Drawing.Point(226, 479);
            this.C6_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C6_02.Name = "C6_02";
            this.C6_02.Size = new System.Drawing.Size(11, 12);
            this.C6_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C6_02.TabIndex = 396;
            this.C6_02.TabStop = false;
            this.C6_02.Visible = false;
            // 
            // C6_03
            // 
            this.C6_03.BackColor = System.Drawing.Color.Transparent;
            this.C6_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C6_03.Location = new System.Drawing.Point(218, 473);
            this.C6_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C6_03.Name = "C6_03";
            this.C6_03.Size = new System.Drawing.Size(11, 12);
            this.C6_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C6_03.TabIndex = 395;
            this.C6_03.TabStop = false;
            this.C6_03.Visible = false;
            // 
            // C6_01
            // 
            this.C6_01.BackColor = System.Drawing.Color.Transparent;
            this.C6_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C6_01.Location = new System.Drawing.Point(209, 479);
            this.C6_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C6_01.Name = "C6_01";
            this.C6_01.Size = new System.Drawing.Size(11, 12);
            this.C6_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C6_01.TabIndex = 394;
            this.C6_01.TabStop = false;
            this.C6_01.Visible = false;
            // 
            // C6_04
            // 
            this.C6_04.BackColor = System.Drawing.Color.Transparent;
            this.C6_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C6_04.Location = new System.Drawing.Point(201, 472);
            this.C6_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C6_04.Name = "C6_04";
            this.C6_04.Size = new System.Drawing.Size(11, 12);
            this.C6_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C6_04.TabIndex = 393;
            this.C6_04.TabStop = false;
            this.C6_04.Visible = false;
            // 
            // C8_02
            // 
            this.C8_02.BackColor = System.Drawing.Color.Transparent;
            this.C8_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C8_02.Location = new System.Drawing.Point(146, 479);
            this.C8_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C8_02.Name = "C8_02";
            this.C8_02.Size = new System.Drawing.Size(11, 12);
            this.C8_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C8_02.TabIndex = 400;
            this.C8_02.TabStop = false;
            this.C8_02.Visible = false;
            // 
            // C8_03
            // 
            this.C8_03.BackColor = System.Drawing.Color.Transparent;
            this.C8_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C8_03.Location = new System.Drawing.Point(137, 472);
            this.C8_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C8_03.Name = "C8_03";
            this.C8_03.Size = new System.Drawing.Size(11, 12);
            this.C8_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C8_03.TabIndex = 399;
            this.C8_03.TabStop = false;
            this.C8_03.Visible = false;
            // 
            // C8_01
            // 
            this.C8_01.BackColor = System.Drawing.Color.Transparent;
            this.C8_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C8_01.Location = new System.Drawing.Point(128, 478);
            this.C8_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C8_01.Name = "C8_01";
            this.C8_01.Size = new System.Drawing.Size(11, 12);
            this.C8_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C8_01.TabIndex = 398;
            this.C8_01.TabStop = false;
            this.C8_01.Visible = false;
            // 
            // C8_04
            // 
            this.C8_04.BackColor = System.Drawing.Color.Transparent;
            this.C8_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C8_04.Location = new System.Drawing.Point(120, 471);
            this.C8_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C8_04.Name = "C8_04";
            this.C8_04.Size = new System.Drawing.Size(11, 12);
            this.C8_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C8_04.TabIndex = 397;
            this.C8_04.TabStop = false;
            this.C8_04.Visible = false;
            // 
            // C9_02
            // 
            this.C9_02.BackColor = System.Drawing.Color.Transparent;
            this.C9_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C9_02.Location = new System.Drawing.Point(104, 478);
            this.C9_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C9_02.Name = "C9_02";
            this.C9_02.Size = new System.Drawing.Size(11, 12);
            this.C9_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C9_02.TabIndex = 404;
            this.C9_02.TabStop = false;
            this.C9_02.Visible = false;
            // 
            // C9_03
            // 
            this.C9_03.BackColor = System.Drawing.Color.Transparent;
            this.C9_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C9_03.Location = new System.Drawing.Point(96, 471);
            this.C9_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C9_03.Name = "C9_03";
            this.C9_03.Size = new System.Drawing.Size(11, 12);
            this.C9_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C9_03.TabIndex = 403;
            this.C9_03.TabStop = false;
            this.C9_03.Visible = false;
            // 
            // C9_01
            // 
            this.C9_01.BackColor = System.Drawing.Color.Transparent;
            this.C9_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C9_01.Location = new System.Drawing.Point(87, 477);
            this.C9_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C9_01.Name = "C9_01";
            this.C9_01.Size = new System.Drawing.Size(11, 12);
            this.C9_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C9_01.TabIndex = 402;
            this.C9_01.TabStop = false;
            this.C9_01.Visible = false;
            // 
            // C9_04
            // 
            this.C9_04.BackColor = System.Drawing.Color.Transparent;
            this.C9_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C9_04.Location = new System.Drawing.Point(79, 470);
            this.C9_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C9_04.Name = "C9_04";
            this.C9_04.Size = new System.Drawing.Size(11, 12);
            this.C9_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C9_04.TabIndex = 401;
            this.C9_04.TabStop = false;
            this.C9_04.Visible = false;
            // 
            // C11_04
            // 
            this.C11_04.BackColor = System.Drawing.Color.Transparent;
            this.C11_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C11_04.Location = new System.Drawing.Point(70, 459);
            this.C11_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C11_04.Name = "C11_04";
            this.C11_04.Size = new System.Drawing.Size(11, 12);
            this.C11_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C11_04.TabIndex = 408;
            this.C11_04.TabStop = false;
            this.C11_04.Visible = false;
            // 
            // C11_02
            // 
            this.C11_02.BackColor = System.Drawing.Color.Transparent;
            this.C11_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C11_02.Location = new System.Drawing.Point(62, 449);
            this.C11_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C11_02.Name = "C11_02";
            this.C11_02.Size = new System.Drawing.Size(11, 12);
            this.C11_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C11_02.TabIndex = 407;
            this.C11_02.TabStop = false;
            this.C11_02.Visible = false;
            // 
            // C11_03
            // 
            this.C11_03.BackColor = System.Drawing.Color.Transparent;
            this.C11_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C11_03.Location = new System.Drawing.Point(70, 440);
            this.C11_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C11_03.Name = "C11_03";
            this.C11_03.Size = new System.Drawing.Size(11, 12);
            this.C11_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C11_03.TabIndex = 406;
            this.C11_03.TabStop = false;
            this.C11_03.Visible = false;
            // 
            // C11_01
            // 
            this.C11_01.BackColor = System.Drawing.Color.Transparent;
            this.C11_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C11_01.Location = new System.Drawing.Point(62, 433);
            this.C11_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C11_01.Name = "C11_01";
            this.C11_01.Size = new System.Drawing.Size(11, 12);
            this.C11_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C11_01.TabIndex = 405;
            this.C11_01.TabStop = false;
            this.C11_01.Visible = false;
            // 
            // C13_04
            // 
            this.C13_04.BackColor = System.Drawing.Color.Transparent;
            this.C13_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C13_04.Location = new System.Drawing.Point(70, 375);
            this.C13_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C13_04.Name = "C13_04";
            this.C13_04.Size = new System.Drawing.Size(11, 12);
            this.C13_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C13_04.TabIndex = 412;
            this.C13_04.TabStop = false;
            this.C13_04.Visible = false;
            // 
            // C13_02
            // 
            this.C13_02.BackColor = System.Drawing.Color.Transparent;
            this.C13_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C13_02.Location = new System.Drawing.Point(62, 365);
            this.C13_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C13_02.Name = "C13_02";
            this.C13_02.Size = new System.Drawing.Size(11, 12);
            this.C13_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C13_02.TabIndex = 411;
            this.C13_02.TabStop = false;
            this.C13_02.Visible = false;
            // 
            // C13_03
            // 
            this.C13_03.BackColor = System.Drawing.Color.Transparent;
            this.C13_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C13_03.Location = new System.Drawing.Point(70, 356);
            this.C13_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C13_03.Name = "C13_03";
            this.C13_03.Size = new System.Drawing.Size(11, 12);
            this.C13_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C13_03.TabIndex = 410;
            this.C13_03.TabStop = false;
            this.C13_03.Visible = false;
            // 
            // C13_01
            // 
            this.C13_01.BackColor = System.Drawing.Color.Transparent;
            this.C13_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C13_01.Location = new System.Drawing.Point(62, 349);
            this.C13_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C13_01.Name = "C13_01";
            this.C13_01.Size = new System.Drawing.Size(11, 12);
            this.C13_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C13_01.TabIndex = 409;
            this.C13_01.TabStop = false;
            this.C13_01.Visible = false;
            // 
            // C14_04
            // 
            this.C14_04.BackColor = System.Drawing.Color.Transparent;
            this.C14_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C14_04.Location = new System.Drawing.Point(70, 330);
            this.C14_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C14_04.Name = "C14_04";
            this.C14_04.Size = new System.Drawing.Size(11, 12);
            this.C14_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C14_04.TabIndex = 416;
            this.C14_04.TabStop = false;
            this.C14_04.Visible = false;
            // 
            // C14_02
            // 
            this.C14_02.BackColor = System.Drawing.Color.Transparent;
            this.C14_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C14_02.Location = new System.Drawing.Point(62, 320);
            this.C14_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C14_02.Name = "C14_02";
            this.C14_02.Size = new System.Drawing.Size(11, 12);
            this.C14_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C14_02.TabIndex = 415;
            this.C14_02.TabStop = false;
            this.C14_02.Visible = false;
            // 
            // C14_03
            // 
            this.C14_03.BackColor = System.Drawing.Color.Transparent;
            this.C14_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C14_03.Location = new System.Drawing.Point(70, 311);
            this.C14_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C14_03.Name = "C14_03";
            this.C14_03.Size = new System.Drawing.Size(11, 12);
            this.C14_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C14_03.TabIndex = 414;
            this.C14_03.TabStop = false;
            this.C14_03.Visible = false;
            // 
            // C14_01
            // 
            this.C14_01.BackColor = System.Drawing.Color.Transparent;
            this.C14_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C14_01.Location = new System.Drawing.Point(62, 304);
            this.C14_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C14_01.Name = "C14_01";
            this.C14_01.Size = new System.Drawing.Size(11, 12);
            this.C14_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C14_01.TabIndex = 413;
            this.C14_01.TabStop = false;
            this.C14_01.Visible = false;
            // 
            // C16_04
            // 
            this.C16_04.BackColor = System.Drawing.Color.Transparent;
            this.C16_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C16_04.Location = new System.Drawing.Point(70, 241);
            this.C16_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C16_04.Name = "C16_04";
            this.C16_04.Size = new System.Drawing.Size(11, 12);
            this.C16_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C16_04.TabIndex = 420;
            this.C16_04.TabStop = false;
            this.C16_04.Visible = false;
            // 
            // C16_02
            // 
            this.C16_02.BackColor = System.Drawing.Color.Transparent;
            this.C16_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C16_02.Location = new System.Drawing.Point(62, 232);
            this.C16_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C16_02.Name = "C16_02";
            this.C16_02.Size = new System.Drawing.Size(11, 12);
            this.C16_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C16_02.TabIndex = 419;
            this.C16_02.TabStop = false;
            this.C16_02.Visible = false;
            // 
            // C16_03
            // 
            this.C16_03.BackColor = System.Drawing.Color.Transparent;
            this.C16_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C16_03.Location = new System.Drawing.Point(70, 223);
            this.C16_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C16_03.Name = "C16_03";
            this.C16_03.Size = new System.Drawing.Size(11, 12);
            this.C16_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C16_03.TabIndex = 418;
            this.C16_03.TabStop = false;
            this.C16_03.Visible = false;
            // 
            // C16_01
            // 
            this.C16_01.BackColor = System.Drawing.Color.Transparent;
            this.C16_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C16_01.Location = new System.Drawing.Point(62, 215);
            this.C16_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C16_01.Name = "C16_01";
            this.C16_01.Size = new System.Drawing.Size(11, 12);
            this.C16_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C16_01.TabIndex = 417;
            this.C16_01.TabStop = false;
            this.C16_01.Visible = false;
            // 
            // C18_04
            // 
            this.C18_04.BackColor = System.Drawing.Color.Transparent;
            this.C18_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C18_04.Location = new System.Drawing.Point(70, 154);
            this.C18_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C18_04.Name = "C18_04";
            this.C18_04.Size = new System.Drawing.Size(11, 12);
            this.C18_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C18_04.TabIndex = 424;
            this.C18_04.TabStop = false;
            this.C18_04.Visible = false;
            // 
            // C18_02
            // 
            this.C18_02.BackColor = System.Drawing.Color.Transparent;
            this.C18_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C18_02.Location = new System.Drawing.Point(62, 145);
            this.C18_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C18_02.Name = "C18_02";
            this.C18_02.Size = new System.Drawing.Size(11, 12);
            this.C18_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C18_02.TabIndex = 423;
            this.C18_02.TabStop = false;
            this.C18_02.Visible = false;
            // 
            // C18_03
            // 
            this.C18_03.BackColor = System.Drawing.Color.Transparent;
            this.C18_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C18_03.Location = new System.Drawing.Point(70, 136);
            this.C18_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C18_03.Name = "C18_03";
            this.C18_03.Size = new System.Drawing.Size(11, 12);
            this.C18_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C18_03.TabIndex = 422;
            this.C18_03.TabStop = false;
            this.C18_03.Visible = false;
            // 
            // C18_01
            // 
            this.C18_01.BackColor = System.Drawing.Color.Transparent;
            this.C18_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C18_01.Location = new System.Drawing.Point(62, 128);
            this.C18_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C18_01.Name = "C18_01";
            this.C18_01.Size = new System.Drawing.Size(11, 12);
            this.C18_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C18_01.TabIndex = 421;
            this.C18_01.TabStop = false;
            this.C18_01.Visible = false;
            // 
            // C19_04
            // 
            this.C19_04.BackColor = System.Drawing.Color.Transparent;
            this.C19_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C19_04.Location = new System.Drawing.Point(70, 109);
            this.C19_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C19_04.Name = "C19_04";
            this.C19_04.Size = new System.Drawing.Size(11, 12);
            this.C19_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C19_04.TabIndex = 428;
            this.C19_04.TabStop = false;
            this.C19_04.Visible = false;
            // 
            // C19_02
            // 
            this.C19_02.BackColor = System.Drawing.Color.Transparent;
            this.C19_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C19_02.Location = new System.Drawing.Point(62, 99);
            this.C19_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C19_02.Name = "C19_02";
            this.C19_02.Size = new System.Drawing.Size(11, 12);
            this.C19_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C19_02.TabIndex = 427;
            this.C19_02.TabStop = false;
            this.C19_02.Visible = false;
            // 
            // C19_03
            // 
            this.C19_03.BackColor = System.Drawing.Color.Transparent;
            this.C19_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C19_03.Location = new System.Drawing.Point(70, 90);
            this.C19_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C19_03.Name = "C19_03";
            this.C19_03.Size = new System.Drawing.Size(11, 12);
            this.C19_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C19_03.TabIndex = 426;
            this.C19_03.TabStop = false;
            this.C19_03.Visible = false;
            // 
            // C19_01
            // 
            this.C19_01.BackColor = System.Drawing.Color.Transparent;
            this.C19_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C19_01.Location = new System.Drawing.Point(62, 83);
            this.C19_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C19_01.Name = "C19_01";
            this.C19_01.Size = new System.Drawing.Size(11, 12);
            this.C19_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C19_01.TabIndex = 425;
            this.C19_01.TabStop = false;
            this.C19_01.Visible = false;
            // 
            // C21_04
            // 
            this.C21_04.BackColor = System.Drawing.Color.Transparent;
            this.C21_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C21_04.Location = new System.Drawing.Point(105, 72);
            this.C21_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C21_04.Name = "C21_04";
            this.C21_04.Size = new System.Drawing.Size(11, 12);
            this.C21_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C21_04.TabIndex = 432;
            this.C21_04.TabStop = false;
            this.C21_04.Visible = false;
            // 
            // C21_02
            // 
            this.C21_02.BackColor = System.Drawing.Color.Transparent;
            this.C21_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C21_02.Location = new System.Drawing.Point(97, 66);
            this.C21_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C21_02.Name = "C21_02";
            this.C21_02.Size = new System.Drawing.Size(11, 12);
            this.C21_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C21_02.TabIndex = 431;
            this.C21_02.TabStop = false;
            this.C21_02.Visible = false;
            // 
            // C21_03
            // 
            this.C21_03.BackColor = System.Drawing.Color.Transparent;
            this.C21_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C21_03.Location = new System.Drawing.Point(88, 72);
            this.C21_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C21_03.Name = "C21_03";
            this.C21_03.Size = new System.Drawing.Size(11, 12);
            this.C21_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C21_03.TabIndex = 430;
            this.C21_03.TabStop = false;
            this.C21_03.Visible = false;
            // 
            // C21_01
            // 
            this.C21_01.BackColor = System.Drawing.Color.Transparent;
            this.C21_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C21_01.Location = new System.Drawing.Point(80, 65);
            this.C21_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C21_01.Name = "C21_01";
            this.C21_01.Size = new System.Drawing.Size(11, 12);
            this.C21_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C21_01.TabIndex = 429;
            this.C21_01.TabStop = false;
            this.C21_01.Visible = false;
            // 
            // C23_04
            // 
            this.C23_04.BackColor = System.Drawing.Color.Transparent;
            this.C23_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C23_04.Location = new System.Drawing.Point(186, 72);
            this.C23_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C23_04.Name = "C23_04";
            this.C23_04.Size = new System.Drawing.Size(11, 12);
            this.C23_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C23_04.TabIndex = 436;
            this.C23_04.TabStop = false;
            this.C23_04.Visible = false;
            // 
            // C23_02
            // 
            this.C23_02.BackColor = System.Drawing.Color.Transparent;
            this.C23_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C23_02.Location = new System.Drawing.Point(178, 66);
            this.C23_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C23_02.Name = "C23_02";
            this.C23_02.Size = new System.Drawing.Size(11, 12);
            this.C23_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C23_02.TabIndex = 435;
            this.C23_02.TabStop = false;
            this.C23_02.Visible = false;
            // 
            // C23_03
            // 
            this.C23_03.BackColor = System.Drawing.Color.Transparent;
            this.C23_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C23_03.Location = new System.Drawing.Point(169, 72);
            this.C23_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C23_03.Name = "C23_03";
            this.C23_03.Size = new System.Drawing.Size(11, 12);
            this.C23_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C23_03.TabIndex = 434;
            this.C23_03.TabStop = false;
            this.C23_03.Visible = false;
            // 
            // C23_01
            // 
            this.C23_01.BackColor = System.Drawing.Color.Transparent;
            this.C23_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C23_01.Location = new System.Drawing.Point(160, 65);
            this.C23_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C23_01.Name = "C23_01";
            this.C23_01.Size = new System.Drawing.Size(11, 12);
            this.C23_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C23_01.TabIndex = 433;
            this.C23_01.TabStop = false;
            this.C23_01.Visible = false;
            // 
            // C24_04
            // 
            this.C24_04.BackColor = System.Drawing.Color.Transparent;
            this.C24_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C24_04.Location = new System.Drawing.Point(226, 72);
            this.C24_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C24_04.Name = "C24_04";
            this.C24_04.Size = new System.Drawing.Size(11, 12);
            this.C24_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C24_04.TabIndex = 440;
            this.C24_04.TabStop = false;
            this.C24_04.Visible = false;
            // 
            // C24_02
            // 
            this.C24_02.BackColor = System.Drawing.Color.Transparent;
            this.C24_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C24_02.Location = new System.Drawing.Point(218, 66);
            this.C24_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C24_02.Name = "C24_02";
            this.C24_02.Size = new System.Drawing.Size(11, 12);
            this.C24_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C24_02.TabIndex = 439;
            this.C24_02.TabStop = false;
            this.C24_02.Visible = false;
            // 
            // C24_03
            // 
            this.C24_03.BackColor = System.Drawing.Color.Transparent;
            this.C24_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C24_03.Location = new System.Drawing.Point(209, 72);
            this.C24_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C24_03.Name = "C24_03";
            this.C24_03.Size = new System.Drawing.Size(11, 12);
            this.C24_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C24_03.TabIndex = 438;
            this.C24_03.TabStop = false;
            this.C24_03.Visible = false;
            // 
            // C24_01
            // 
            this.C24_01.BackColor = System.Drawing.Color.Transparent;
            this.C24_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C24_01.Location = new System.Drawing.Point(201, 65);
            this.C24_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C24_01.Name = "C24_01";
            this.C24_01.Size = new System.Drawing.Size(11, 12);
            this.C24_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C24_01.TabIndex = 437;
            this.C24_01.TabStop = false;
            this.C24_01.Visible = false;
            // 
            // C26_04
            // 
            this.C26_04.BackColor = System.Drawing.Color.Transparent;
            this.C26_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C26_04.Location = new System.Drawing.Point(308, 72);
            this.C26_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C26_04.Name = "C26_04";
            this.C26_04.Size = new System.Drawing.Size(11, 12);
            this.C26_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C26_04.TabIndex = 444;
            this.C26_04.TabStop = false;
            this.C26_04.Visible = false;
            // 
            // C26_02
            // 
            this.C26_02.BackColor = System.Drawing.Color.Transparent;
            this.C26_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C26_02.Location = new System.Drawing.Point(300, 66);
            this.C26_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C26_02.Name = "C26_02";
            this.C26_02.Size = new System.Drawing.Size(11, 12);
            this.C26_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C26_02.TabIndex = 443;
            this.C26_02.TabStop = false;
            this.C26_02.Visible = false;
            // 
            // C26_03
            // 
            this.C26_03.BackColor = System.Drawing.Color.Transparent;
            this.C26_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C26_03.Location = new System.Drawing.Point(291, 72);
            this.C26_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C26_03.Name = "C26_03";
            this.C26_03.Size = new System.Drawing.Size(11, 12);
            this.C26_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C26_03.TabIndex = 442;
            this.C26_03.TabStop = false;
            this.C26_03.Visible = false;
            // 
            // C26_01
            // 
            this.C26_01.BackColor = System.Drawing.Color.Transparent;
            this.C26_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C26_01.Location = new System.Drawing.Point(283, 65);
            this.C26_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C26_01.Name = "C26_01";
            this.C26_01.Size = new System.Drawing.Size(11, 12);
            this.C26_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C26_01.TabIndex = 441;
            this.C26_01.TabStop = false;
            this.C26_01.Visible = false;
            // 
            // C27_04
            // 
            this.C27_04.BackColor = System.Drawing.Color.Transparent;
            this.C27_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C27_04.Location = new System.Drawing.Point(350, 72);
            this.C27_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C27_04.Name = "C27_04";
            this.C27_04.Size = new System.Drawing.Size(11, 12);
            this.C27_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C27_04.TabIndex = 448;
            this.C27_04.TabStop = false;
            this.C27_04.Visible = false;
            // 
            // C27_02
            // 
            this.C27_02.BackColor = System.Drawing.Color.Transparent;
            this.C27_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C27_02.Location = new System.Drawing.Point(341, 65);
            this.C27_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C27_02.Name = "C27_02";
            this.C27_02.Size = new System.Drawing.Size(11, 12);
            this.C27_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C27_02.TabIndex = 447;
            this.C27_02.TabStop = false;
            this.C27_02.Visible = false;
            // 
            // C27_03
            // 
            this.C27_03.BackColor = System.Drawing.Color.Transparent;
            this.C27_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C27_03.Location = new System.Drawing.Point(332, 71);
            this.C27_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C27_03.Name = "C27_03";
            this.C27_03.Size = new System.Drawing.Size(11, 12);
            this.C27_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C27_03.TabIndex = 446;
            this.C27_03.TabStop = false;
            this.C27_03.Visible = false;
            // 
            // C27_01
            // 
            this.C27_01.BackColor = System.Drawing.Color.Transparent;
            this.C27_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C27_01.Location = new System.Drawing.Point(324, 64);
            this.C27_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C27_01.Name = "C27_01";
            this.C27_01.Size = new System.Drawing.Size(11, 12);
            this.C27_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C27_01.TabIndex = 445;
            this.C27_01.TabStop = false;
            this.C27_01.Visible = false;
            // 
            // C29_04
            // 
            this.C29_04.BackColor = System.Drawing.Color.Transparent;
            this.C29_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C29_04.Location = new System.Drawing.Point(430, 72);
            this.C29_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C29_04.Name = "C29_04";
            this.C29_04.Size = new System.Drawing.Size(11, 12);
            this.C29_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C29_04.TabIndex = 452;
            this.C29_04.TabStop = false;
            this.C29_04.Visible = false;
            // 
            // C29_02
            // 
            this.C29_02.BackColor = System.Drawing.Color.Transparent;
            this.C29_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C29_02.Location = new System.Drawing.Point(422, 66);
            this.C29_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C29_02.Name = "C29_02";
            this.C29_02.Size = new System.Drawing.Size(11, 12);
            this.C29_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C29_02.TabIndex = 451;
            this.C29_02.TabStop = false;
            this.C29_02.Visible = false;
            // 
            // C29_03
            // 
            this.C29_03.BackColor = System.Drawing.Color.Transparent;
            this.C29_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C29_03.Location = new System.Drawing.Point(413, 72);
            this.C29_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C29_03.Name = "C29_03";
            this.C29_03.Size = new System.Drawing.Size(11, 12);
            this.C29_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C29_03.TabIndex = 450;
            this.C29_03.TabStop = false;
            this.C29_03.Visible = false;
            // 
            // C29_01
            // 
            this.C29_01.BackColor = System.Drawing.Color.Transparent;
            this.C29_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C29_01.Location = new System.Drawing.Point(405, 65);
            this.C29_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C29_01.Name = "C29_01";
            this.C29_01.Size = new System.Drawing.Size(11, 12);
            this.C29_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C29_01.TabIndex = 449;
            this.C29_01.TabStop = false;
            this.C29_01.Visible = false;
            // 
            // C31_02
            // 
            this.C31_02.BackColor = System.Drawing.Color.Transparent;
            this.C31_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C31_02.Location = new System.Drawing.Point(446, 101);
            this.C31_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C31_02.Name = "C31_02";
            this.C31_02.Size = new System.Drawing.Size(11, 12);
            this.C31_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C31_02.TabIndex = 456;
            this.C31_02.TabStop = false;
            this.C31_02.Visible = false;
            // 
            // C31_04
            // 
            this.C31_04.BackColor = System.Drawing.Color.Transparent;
            this.C31_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C31_04.Location = new System.Drawing.Point(439, 109);
            this.C31_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C31_04.Name = "C31_04";
            this.C31_04.Size = new System.Drawing.Size(11, 12);
            this.C31_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C31_04.TabIndex = 455;
            this.C31_04.TabStop = false;
            this.C31_04.Visible = false;
            // 
            // C31_01
            // 
            this.C31_01.BackColor = System.Drawing.Color.Transparent;
            this.C31_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C31_01.Location = new System.Drawing.Point(447, 84);
            this.C31_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C31_01.Name = "C31_01";
            this.C31_01.Size = new System.Drawing.Size(11, 12);
            this.C31_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C31_01.TabIndex = 454;
            this.C31_01.TabStop = false;
            this.C31_01.Visible = false;
            // 
            // C31_03
            // 
            this.C31_03.BackColor = System.Drawing.Color.Transparent;
            this.C31_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C31_03.Location = new System.Drawing.Point(439, 91);
            this.C31_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C31_03.Name = "C31_03";
            this.C31_03.Size = new System.Drawing.Size(11, 12);
            this.C31_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C31_03.TabIndex = 453;
            this.C31_03.TabStop = false;
            this.C31_03.Visible = false;
            // 
            // C32_02
            // 
            this.C32_02.BackColor = System.Drawing.Color.Transparent;
            this.C32_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C32_02.Location = new System.Drawing.Point(446, 145);
            this.C32_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C32_02.Name = "C32_02";
            this.C32_02.Size = new System.Drawing.Size(11, 12);
            this.C32_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C32_02.TabIndex = 460;
            this.C32_02.TabStop = false;
            this.C32_02.Visible = false;
            // 
            // C32_04
            // 
            this.C32_04.BackColor = System.Drawing.Color.Transparent;
            this.C32_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C32_04.Location = new System.Drawing.Point(439, 153);
            this.C32_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C32_04.Name = "C32_04";
            this.C32_04.Size = new System.Drawing.Size(11, 12);
            this.C32_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C32_04.TabIndex = 459;
            this.C32_04.TabStop = false;
            this.C32_04.Visible = false;
            // 
            // C32_01
            // 
            this.C32_01.BackColor = System.Drawing.Color.Transparent;
            this.C32_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C32_01.Location = new System.Drawing.Point(447, 128);
            this.C32_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C32_01.Name = "C32_01";
            this.C32_01.Size = new System.Drawing.Size(11, 12);
            this.C32_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C32_01.TabIndex = 458;
            this.C32_01.TabStop = false;
            this.C32_01.Visible = false;
            // 
            // C32_03
            // 
            this.C32_03.BackColor = System.Drawing.Color.Transparent;
            this.C32_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C32_03.Location = new System.Drawing.Point(439, 135);
            this.C32_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C32_03.Name = "C32_03";
            this.C32_03.Size = new System.Drawing.Size(11, 12);
            this.C32_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C32_03.TabIndex = 457;
            this.C32_03.TabStop = false;
            this.C32_03.Visible = false;
            // 
            // C34_02
            // 
            this.C34_02.BackColor = System.Drawing.Color.Transparent;
            this.C34_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C34_02.Location = new System.Drawing.Point(446, 234);
            this.C34_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C34_02.Name = "C34_02";
            this.C34_02.Size = new System.Drawing.Size(11, 12);
            this.C34_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C34_02.TabIndex = 464;
            this.C34_02.TabStop = false;
            this.C34_02.Visible = false;
            // 
            // C34_04
            // 
            this.C34_04.BackColor = System.Drawing.Color.Transparent;
            this.C34_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C34_04.Location = new System.Drawing.Point(439, 242);
            this.C34_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C34_04.Name = "C34_04";
            this.C34_04.Size = new System.Drawing.Size(11, 12);
            this.C34_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C34_04.TabIndex = 463;
            this.C34_04.TabStop = false;
            this.C34_04.Visible = false;
            // 
            // C34_01
            // 
            this.C34_01.BackColor = System.Drawing.Color.Transparent;
            this.C34_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C34_01.Location = new System.Drawing.Point(447, 217);
            this.C34_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C34_01.Name = "C34_01";
            this.C34_01.Size = new System.Drawing.Size(11, 12);
            this.C34_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C34_01.TabIndex = 462;
            this.C34_01.TabStop = false;
            this.C34_01.Visible = false;
            // 
            // C34_03
            // 
            this.C34_03.BackColor = System.Drawing.Color.Transparent;
            this.C34_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C34_03.Location = new System.Drawing.Point(439, 224);
            this.C34_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C34_03.Name = "C34_03";
            this.C34_03.Size = new System.Drawing.Size(11, 12);
            this.C34_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C34_03.TabIndex = 461;
            this.C34_03.TabStop = false;
            this.C34_03.Visible = false;
            // 
            // C37_02
            // 
            this.C37_02.BackColor = System.Drawing.Color.Transparent;
            this.C37_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C37_02.Location = new System.Drawing.Point(446, 365);
            this.C37_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C37_02.Name = "C37_02";
            this.C37_02.Size = new System.Drawing.Size(11, 12);
            this.C37_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C37_02.TabIndex = 468;
            this.C37_02.TabStop = false;
            this.C37_02.Visible = false;
            // 
            // C37_04
            // 
            this.C37_04.BackColor = System.Drawing.Color.Transparent;
            this.C37_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C37_04.Location = new System.Drawing.Point(439, 373);
            this.C37_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C37_04.Name = "C37_04";
            this.C37_04.Size = new System.Drawing.Size(11, 12);
            this.C37_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C37_04.TabIndex = 467;
            this.C37_04.TabStop = false;
            this.C37_04.Visible = false;
            // 
            // C37_01
            // 
            this.C37_01.BackColor = System.Drawing.Color.Transparent;
            this.C37_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C37_01.Location = new System.Drawing.Point(447, 348);
            this.C37_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C37_01.Name = "C37_01";
            this.C37_01.Size = new System.Drawing.Size(11, 12);
            this.C37_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C37_01.TabIndex = 466;
            this.C37_01.TabStop = false;
            this.C37_01.Visible = false;
            // 
            // C37_03
            // 
            this.C37_03.BackColor = System.Drawing.Color.Transparent;
            this.C37_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C37_03.Location = new System.Drawing.Point(439, 355);
            this.C37_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C37_03.Name = "C37_03";
            this.C37_03.Size = new System.Drawing.Size(11, 12);
            this.C37_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C37_03.TabIndex = 465;
            this.C37_03.TabStop = false;
            this.C37_03.Visible = false;
            // 
            // C39_02
            // 
            this.C39_02.BackColor = System.Drawing.Color.Transparent;
            this.C39_02.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C39_02.Location = new System.Drawing.Point(446, 453);
            this.C39_02.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C39_02.Name = "C39_02";
            this.C39_02.Size = new System.Drawing.Size(11, 12);
            this.C39_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C39_02.TabIndex = 472;
            this.C39_02.TabStop = false;
            this.C39_02.Visible = false;
            // 
            // C39_04
            // 
            this.C39_04.BackColor = System.Drawing.Color.Transparent;
            this.C39_04.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C39_04.Location = new System.Drawing.Point(438, 461);
            this.C39_04.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C39_04.Name = "C39_04";
            this.C39_04.Size = new System.Drawing.Size(11, 12);
            this.C39_04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C39_04.TabIndex = 471;
            this.C39_04.TabStop = false;
            this.C39_04.Visible = false;
            // 
            // C39_01
            // 
            this.C39_01.BackColor = System.Drawing.Color.Transparent;
            this.C39_01.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C39_01.Location = new System.Drawing.Point(446, 436);
            this.C39_01.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C39_01.Name = "C39_01";
            this.C39_01.Size = new System.Drawing.Size(11, 12);
            this.C39_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C39_01.TabIndex = 470;
            this.C39_01.TabStop = false;
            this.C39_01.Visible = false;
            // 
            // C39_03
            // 
            this.C39_03.BackColor = System.Drawing.Color.Transparent;
            this.C39_03.Image = global::Monopoly.Properties.Resources.green_house_icon;
            this.C39_03.Location = new System.Drawing.Point(438, 443);
            this.C39_03.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.C39_03.Name = "C39_03";
            this.C39_03.Size = new System.Drawing.Size(11, 12);
            this.C39_03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C39_03.TabIndex = 469;
            this.C39_03.TabStop = false;
            this.C39_03.Visible = false;
            // 
            // H1
            // 
            this.H1.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H1.Location = new System.Drawing.Point(411, 470);
            this.H1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H1.Name = "H1";
            this.H1.Size = new System.Drawing.Size(22, 20);
            this.H1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H1.TabIndex = 63;
            this.H1.TabStop = false;
            this.H1.Visible = false;
            // 
            // H3
            // 
            this.H3.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H3.Location = new System.Drawing.Point(331, 472);
            this.H3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H3.Name = "H3";
            this.H3.Size = new System.Drawing.Size(22, 20);
            this.H3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H3.TabIndex = 473;
            this.H3.TabStop = false;
            this.H3.Visible = false;
            // 
            // H6
            // 
            this.H6.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H6.Location = new System.Drawing.Point(209, 471);
            this.H6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H6.Name = "H6";
            this.H6.Size = new System.Drawing.Size(22, 20);
            this.H6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H6.TabIndex = 474;
            this.H6.TabStop = false;
            this.H6.Visible = false;
            // 
            // H8
            // 
            this.H8.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H8.Location = new System.Drawing.Point(127, 472);
            this.H8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H8.Name = "H8";
            this.H8.Size = new System.Drawing.Size(22, 20);
            this.H8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H8.TabIndex = 475;
            this.H8.TabStop = false;
            this.H8.Visible = false;
            // 
            // H9
            // 
            this.H9.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H9.Location = new System.Drawing.Point(86, 471);
            this.H9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H9.Name = "H9";
            this.H9.Size = new System.Drawing.Size(22, 20);
            this.H9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H9.TabIndex = 476;
            this.H9.TabStop = false;
            this.H9.Visible = false;
            // 
            // H11
            // 
            this.H11.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H11.Location = new System.Drawing.Point(63, 443);
            this.H11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H11.Name = "H11";
            this.H11.Size = new System.Drawing.Size(22, 20);
            this.H11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H11.TabIndex = 477;
            this.H11.TabStop = false;
            this.H11.Visible = false;
            // 
            // H13
            // 
            this.H13.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H13.Location = new System.Drawing.Point(62, 358);
            this.H13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H13.Name = "H13";
            this.H13.Size = new System.Drawing.Size(22, 20);
            this.H13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H13.TabIndex = 478;
            this.H13.TabStop = false;
            this.H13.Visible = false;
            // 
            // H14
            // 
            this.H14.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H14.Location = new System.Drawing.Point(62, 312);
            this.H14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H14.Name = "H14";
            this.H14.Size = new System.Drawing.Size(22, 20);
            this.H14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H14.TabIndex = 479;
            this.H14.TabStop = false;
            this.H14.Visible = false;
            // 
            // H16
            // 
            this.H16.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H16.Location = new System.Drawing.Point(63, 224);
            this.H16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H16.Name = "H16";
            this.H16.Size = new System.Drawing.Size(22, 20);
            this.H16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H16.TabIndex = 480;
            this.H16.TabStop = false;
            this.H16.Visible = false;
            // 
            // H18
            // 
            this.H18.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H18.Location = new System.Drawing.Point(63, 136);
            this.H18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H18.Name = "H18";
            this.H18.Size = new System.Drawing.Size(22, 20);
            this.H18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H18.TabIndex = 481;
            this.H18.TabStop = false;
            this.H18.Visible = false;
            // 
            // H19
            // 
            this.H19.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H19.Location = new System.Drawing.Point(63, 93);
            this.H19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H19.Name = "H19";
            this.H19.Size = new System.Drawing.Size(22, 20);
            this.H19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H19.TabIndex = 482;
            this.H19.TabStop = false;
            this.H19.Visible = false;
            // 
            // H21
            // 
            this.H21.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H21.Location = new System.Drawing.Point(88, 64);
            this.H21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H21.Name = "H21";
            this.H21.Size = new System.Drawing.Size(22, 20);
            this.H21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H21.TabIndex = 483;
            this.H21.TabStop = false;
            this.H21.Visible = false;
            // 
            // H23
            // 
            this.H23.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H23.Location = new System.Drawing.Point(169, 64);
            this.H23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H23.Name = "H23";
            this.H23.Size = new System.Drawing.Size(22, 20);
            this.H23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H23.TabIndex = 484;
            this.H23.TabStop = false;
            this.H23.Visible = false;
            // 
            // H24
            // 
            this.H24.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H24.Location = new System.Drawing.Point(209, 64);
            this.H24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H24.Name = "H24";
            this.H24.Size = new System.Drawing.Size(22, 20);
            this.H24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H24.TabIndex = 485;
            this.H24.TabStop = false;
            this.H24.Visible = false;
            // 
            // H26
            // 
            this.H26.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H26.Location = new System.Drawing.Point(291, 64);
            this.H26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H26.Name = "H26";
            this.H26.Size = new System.Drawing.Size(22, 20);
            this.H26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H26.TabIndex = 486;
            this.H26.TabStop = false;
            this.H26.Visible = false;
            // 
            // H27
            // 
            this.H27.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H27.Location = new System.Drawing.Point(331, 64);
            this.H27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H27.Name = "H27";
            this.H27.Size = new System.Drawing.Size(22, 20);
            this.H27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H27.TabIndex = 487;
            this.H27.TabStop = false;
            this.H27.Visible = false;
            // 
            // H29
            // 
            this.H29.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H29.Location = new System.Drawing.Point(412, 64);
            this.H29.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H29.Name = "H29";
            this.H29.Size = new System.Drawing.Size(22, 20);
            this.H29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H29.TabIndex = 488;
            this.H29.TabStop = false;
            this.H29.Visible = false;
            // 
            // H31
            // 
            this.H31.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H31.Location = new System.Drawing.Point(436, 93);
            this.H31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H31.Name = "H31";
            this.H31.Size = new System.Drawing.Size(22, 20);
            this.H31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H31.TabIndex = 489;
            this.H31.TabStop = false;
            this.H31.Visible = false;
            // 
            // H32
            // 
            this.H32.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H32.Location = new System.Drawing.Point(436, 136);
            this.H32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H32.Name = "H32";
            this.H32.Size = new System.Drawing.Size(22, 20);
            this.H32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H32.TabIndex = 490;
            this.H32.TabStop = false;
            this.H32.Visible = false;
            // 
            // H34
            // 
            this.H34.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H34.Location = new System.Drawing.Point(436, 225);
            this.H34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H34.Name = "H34";
            this.H34.Size = new System.Drawing.Size(22, 20);
            this.H34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H34.TabIndex = 491;
            this.H34.TabStop = false;
            this.H34.Visible = false;
            // 
            // H37
            // 
            this.H37.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H37.Location = new System.Drawing.Point(436, 358);
            this.H37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H37.Name = "H37";
            this.H37.Size = new System.Drawing.Size(22, 20);
            this.H37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H37.TabIndex = 492;
            this.H37.TabStop = false;
            this.H37.Visible = false;
            // 
            // H39
            // 
            this.H39.Image = global::Monopoly.Properties.Resources.red_house_icon;
            this.H39.Location = new System.Drawing.Point(436, 444);
            this.H39.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.H39.Name = "H39";
            this.H39.Size = new System.Drawing.Size(22, 20);
            this.H39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.H39.TabIndex = 493;
            this.H39.TabStop = false;
            this.H39.Visible = false;
            // 
            // Jogo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1015, 558);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.H39);
            this.Controls.Add(this.H37);
            this.Controls.Add(this.H34);
            this.Controls.Add(this.H32);
            this.Controls.Add(this.H31);
            this.Controls.Add(this.H29);
            this.Controls.Add(this.H27);
            this.Controls.Add(this.H26);
            this.Controls.Add(this.H24);
            this.Controls.Add(this.H23);
            this.Controls.Add(this.H21);
            this.Controls.Add(this.H19);
            this.Controls.Add(this.H18);
            this.Controls.Add(this.H16);
            this.Controls.Add(this.H14);
            this.Controls.Add(this.H13);
            this.Controls.Add(this.H11);
            this.Controls.Add(this.H9);
            this.Controls.Add(this.H8);
            this.Controls.Add(this.H6);
            this.Controls.Add(this.H3);
            this.Controls.Add(this.H1);
            this.Controls.Add(this.C39_02);
            this.Controls.Add(this.C39_04);
            this.Controls.Add(this.C39_01);
            this.Controls.Add(this.C39_03);
            this.Controls.Add(this.C37_02);
            this.Controls.Add(this.C37_04);
            this.Controls.Add(this.C37_01);
            this.Controls.Add(this.C37_03);
            this.Controls.Add(this.C34_02);
            this.Controls.Add(this.C34_04);
            this.Controls.Add(this.C34_01);
            this.Controls.Add(this.C34_03);
            this.Controls.Add(this.C32_02);
            this.Controls.Add(this.C32_04);
            this.Controls.Add(this.C32_01);
            this.Controls.Add(this.C32_03);
            this.Controls.Add(this.C31_02);
            this.Controls.Add(this.C31_04);
            this.Controls.Add(this.C31_01);
            this.Controls.Add(this.C31_03);
            this.Controls.Add(this.C29_04);
            this.Controls.Add(this.C29_02);
            this.Controls.Add(this.C29_03);
            this.Controls.Add(this.C29_01);
            this.Controls.Add(this.C27_04);
            this.Controls.Add(this.C27_02);
            this.Controls.Add(this.C27_03);
            this.Controls.Add(this.C27_01);
            this.Controls.Add(this.C26_04);
            this.Controls.Add(this.C26_02);
            this.Controls.Add(this.C26_03);
            this.Controls.Add(this.C26_01);
            this.Controls.Add(this.C24_04);
            this.Controls.Add(this.C24_02);
            this.Controls.Add(this.C24_03);
            this.Controls.Add(this.C24_01);
            this.Controls.Add(this.C23_04);
            this.Controls.Add(this.C23_02);
            this.Controls.Add(this.C23_03);
            this.Controls.Add(this.C23_01);
            this.Controls.Add(this.C21_04);
            this.Controls.Add(this.C21_02);
            this.Controls.Add(this.C21_03);
            this.Controls.Add(this.C21_01);
            this.Controls.Add(this.C19_04);
            this.Controls.Add(this.C19_02);
            this.Controls.Add(this.C19_03);
            this.Controls.Add(this.C19_01);
            this.Controls.Add(this.C18_04);
            this.Controls.Add(this.C18_02);
            this.Controls.Add(this.C18_03);
            this.Controls.Add(this.C18_01);
            this.Controls.Add(this.C16_04);
            this.Controls.Add(this.C16_02);
            this.Controls.Add(this.C16_03);
            this.Controls.Add(this.C16_01);
            this.Controls.Add(this.C14_04);
            this.Controls.Add(this.C14_02);
            this.Controls.Add(this.C14_03);
            this.Controls.Add(this.C14_01);
            this.Controls.Add(this.C13_04);
            this.Controls.Add(this.C13_02);
            this.Controls.Add(this.C13_03);
            this.Controls.Add(this.C13_01);
            this.Controls.Add(this.C11_04);
            this.Controls.Add(this.C11_02);
            this.Controls.Add(this.C11_03);
            this.Controls.Add(this.C11_01);
            this.Controls.Add(this.C9_02);
            this.Controls.Add(this.C9_03);
            this.Controls.Add(this.C9_01);
            this.Controls.Add(this.C9_04);
            this.Controls.Add(this.C8_02);
            this.Controls.Add(this.C8_03);
            this.Controls.Add(this.C8_01);
            this.Controls.Add(this.C8_04);
            this.Controls.Add(this.C6_02);
            this.Controls.Add(this.C6_03);
            this.Controls.Add(this.C6_01);
            this.Controls.Add(this.C6_04);
            this.Controls.Add(this.C3_02);
            this.Controls.Add(this.C3_03);
            this.Controls.Add(this.C3_01);
            this.Controls.Add(this.C3_04);
            this.Controls.Add(this.C1_02);
            this.Controls.Add(this.C1_03);
            this.Controls.Add(this.C1_01);
            this.Controls.Add(this.C1_04);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.J8_39);
            this.Controls.Add(this.J7_39);
            this.Controls.Add(this.J6_39);
            this.Controls.Add(this.J5_39);
            this.Controls.Add(this.J4_39);
            this.Controls.Add(this.J3_39);
            this.Controls.Add(this.J2_39);
            this.Controls.Add(this.J1_39);
            this.Controls.Add(this.J8_38);
            this.Controls.Add(this.J7_38);
            this.Controls.Add(this.J6_38);
            this.Controls.Add(this.J5_38);
            this.Controls.Add(this.J4_38);
            this.Controls.Add(this.J3_38);
            this.Controls.Add(this.J2_38);
            this.Controls.Add(this.J1_38);
            this.Controls.Add(this.J8_37);
            this.Controls.Add(this.J7_37);
            this.Controls.Add(this.J6_37);
            this.Controls.Add(this.J5_37);
            this.Controls.Add(this.J4_37);
            this.Controls.Add(this.J3_37);
            this.Controls.Add(this.J2_37);
            this.Controls.Add(this.J1_37);
            this.Controls.Add(this.J8_36);
            this.Controls.Add(this.J7_36);
            this.Controls.Add(this.J6_36);
            this.Controls.Add(this.J5_36);
            this.Controls.Add(this.J4_36);
            this.Controls.Add(this.J3_36);
            this.Controls.Add(this.J2_36);
            this.Controls.Add(this.J1_36);
            this.Controls.Add(this.J8_35);
            this.Controls.Add(this.J7_35);
            this.Controls.Add(this.J6_35);
            this.Controls.Add(this.J5_35);
            this.Controls.Add(this.J4_35);
            this.Controls.Add(this.J3_35);
            this.Controls.Add(this.J2_35);
            this.Controls.Add(this.J1_35);
            this.Controls.Add(this.J8_34);
            this.Controls.Add(this.J7_34);
            this.Controls.Add(this.J6_34);
            this.Controls.Add(this.J5_34);
            this.Controls.Add(this.J4_34);
            this.Controls.Add(this.J3_34);
            this.Controls.Add(this.J2_34);
            this.Controls.Add(this.J1_34);
            this.Controls.Add(this.J8_33);
            this.Controls.Add(this.J7_33);
            this.Controls.Add(this.J6_33);
            this.Controls.Add(this.J5_33);
            this.Controls.Add(this.J4_33);
            this.Controls.Add(this.J3_33);
            this.Controls.Add(this.J2_33);
            this.Controls.Add(this.J1_33);
            this.Controls.Add(this.J8_32);
            this.Controls.Add(this.J7_32);
            this.Controls.Add(this.J6_32);
            this.Controls.Add(this.J5_32);
            this.Controls.Add(this.J4_32);
            this.Controls.Add(this.J3_32);
            this.Controls.Add(this.J2_32);
            this.Controls.Add(this.J1_32);
            this.Controls.Add(this.J8_31);
            this.Controls.Add(this.J7_31);
            this.Controls.Add(this.J6_31);
            this.Controls.Add(this.J5_31);
            this.Controls.Add(this.J4_31);
            this.Controls.Add(this.J3_31);
            this.Controls.Add(this.J2_31);
            this.Controls.Add(this.J1_31);
            this.Controls.Add(this.J8_29);
            this.Controls.Add(this.J7_29);
            this.Controls.Add(this.J6_29);
            this.Controls.Add(this.J5_29);
            this.Controls.Add(this.J4_29);
            this.Controls.Add(this.J3_29);
            this.Controls.Add(this.J2_29);
            this.Controls.Add(this.J1_29);
            this.Controls.Add(this.J8_28);
            this.Controls.Add(this.J7_28);
            this.Controls.Add(this.J6_28);
            this.Controls.Add(this.J5_28);
            this.Controls.Add(this.J4_28);
            this.Controls.Add(this.J3_28);
            this.Controls.Add(this.J2_28);
            this.Controls.Add(this.J1_28);
            this.Controls.Add(this.J8_27);
            this.Controls.Add(this.J7_27);
            this.Controls.Add(this.J6_27);
            this.Controls.Add(this.J5_27);
            this.Controls.Add(this.J4_27);
            this.Controls.Add(this.J3_27);
            this.Controls.Add(this.J2_27);
            this.Controls.Add(this.J1_27);
            this.Controls.Add(this.J8_26);
            this.Controls.Add(this.J7_26);
            this.Controls.Add(this.J6_26);
            this.Controls.Add(this.J5_26);
            this.Controls.Add(this.J4_26);
            this.Controls.Add(this.J3_26);
            this.Controls.Add(this.J2_26);
            this.Controls.Add(this.J1_26);
            this.Controls.Add(this.J8_25);
            this.Controls.Add(this.J7_25);
            this.Controls.Add(this.J6_25);
            this.Controls.Add(this.J5_25);
            this.Controls.Add(this.J4_25);
            this.Controls.Add(this.J3_25);
            this.Controls.Add(this.J2_25);
            this.Controls.Add(this.J1_25);
            this.Controls.Add(this.J8_24);
            this.Controls.Add(this.J7_24);
            this.Controls.Add(this.J6_24);
            this.Controls.Add(this.J5_24);
            this.Controls.Add(this.J4_24);
            this.Controls.Add(this.J3_24);
            this.Controls.Add(this.J2_24);
            this.Controls.Add(this.J1_24);
            this.Controls.Add(this.J8_23);
            this.Controls.Add(this.J7_23);
            this.Controls.Add(this.J6_23);
            this.Controls.Add(this.J5_23);
            this.Controls.Add(this.J4_23);
            this.Controls.Add(this.J3_23);
            this.Controls.Add(this.J2_23);
            this.Controls.Add(this.J1_23);
            this.Controls.Add(this.J8_22);
            this.Controls.Add(this.J7_22);
            this.Controls.Add(this.J6_22);
            this.Controls.Add(this.J5_22);
            this.Controls.Add(this.J4_22);
            this.Controls.Add(this.J3_22);
            this.Controls.Add(this.J2_22);
            this.Controls.Add(this.J1_22);
            this.Controls.Add(this.J8_20);
            this.Controls.Add(this.J7_20);
            this.Controls.Add(this.J6_20);
            this.Controls.Add(this.J5_20);
            this.Controls.Add(this.J4_20);
            this.Controls.Add(this.J3_20);
            this.Controls.Add(this.J2_20);
            this.Controls.Add(this.J1_20);
            this.Controls.Add(this.J8_21);
            this.Controls.Add(this.J7_21);
            this.Controls.Add(this.J6_21);
            this.Controls.Add(this.J5_21);
            this.Controls.Add(this.J4_21);
            this.Controls.Add(this.J3_21);
            this.Controls.Add(this.J2_21);
            this.Controls.Add(this.J1_21);
            this.Controls.Add(this.J8_19);
            this.Controls.Add(this.J7_19);
            this.Controls.Add(this.J6_19);
            this.Controls.Add(this.J5_19);
            this.Controls.Add(this.J4_19);
            this.Controls.Add(this.J3_19);
            this.Controls.Add(this.J2_19);
            this.Controls.Add(this.J1_19);
            this.Controls.Add(this.J8_18);
            this.Controls.Add(this.J7_18);
            this.Controls.Add(this.J6_18);
            this.Controls.Add(this.J5_18);
            this.Controls.Add(this.J4_18);
            this.Controls.Add(this.J3_18);
            this.Controls.Add(this.J2_18);
            this.Controls.Add(this.J1_18);
            this.Controls.Add(this.J8_17);
            this.Controls.Add(this.J7_17);
            this.Controls.Add(this.J6_17);
            this.Controls.Add(this.J5_17);
            this.Controls.Add(this.J4_17);
            this.Controls.Add(this.J3_17);
            this.Controls.Add(this.J2_17);
            this.Controls.Add(this.J1_17);
            this.Controls.Add(this.J8_16);
            this.Controls.Add(this.J7_16);
            this.Controls.Add(this.J6_16);
            this.Controls.Add(this.J5_16);
            this.Controls.Add(this.J4_16);
            this.Controls.Add(this.J3_16);
            this.Controls.Add(this.J2_16);
            this.Controls.Add(this.J1_16);
            this.Controls.Add(this.J8_15);
            this.Controls.Add(this.J7_15);
            this.Controls.Add(this.J6_15);
            this.Controls.Add(this.J5_15);
            this.Controls.Add(this.J4_15);
            this.Controls.Add(this.J3_15);
            this.Controls.Add(this.J2_15);
            this.Controls.Add(this.J1_15);
            this.Controls.Add(this.J8_14);
            this.Controls.Add(this.J7_14);
            this.Controls.Add(this.J6_14);
            this.Controls.Add(this.J5_14);
            this.Controls.Add(this.J4_14);
            this.Controls.Add(this.J3_14);
            this.Controls.Add(this.J2_14);
            this.Controls.Add(this.J1_14);
            this.Controls.Add(this.J8_13);
            this.Controls.Add(this.J7_13);
            this.Controls.Add(this.J6_13);
            this.Controls.Add(this.J5_13);
            this.Controls.Add(this.J4_13);
            this.Controls.Add(this.J3_13);
            this.Controls.Add(this.J2_13);
            this.Controls.Add(this.J1_13);
            this.Controls.Add(this.J8_12);
            this.Controls.Add(this.J7_12);
            this.Controls.Add(this.J6_12);
            this.Controls.Add(this.J5_12);
            this.Controls.Add(this.J4_12);
            this.Controls.Add(this.J3_12);
            this.Controls.Add(this.J2_12);
            this.Controls.Add(this.J1_12);
            this.Controls.Add(this.J8_11);
            this.Controls.Add(this.J7_11);
            this.Controls.Add(this.J6_11);
            this.Controls.Add(this.J5_11);
            this.Controls.Add(this.J4_11);
            this.Controls.Add(this.J3_11);
            this.Controls.Add(this.J2_11);
            this.Controls.Add(this.J1_11);
            this.Controls.Add(this.J8_10);
            this.Controls.Add(this.J7_10);
            this.Controls.Add(this.J6_10);
            this.Controls.Add(this.J5_10);
            this.Controls.Add(this.J4_10);
            this.Controls.Add(this.J3_10);
            this.Controls.Add(this.J2_10);
            this.Controls.Add(this.J1_10);
            this.Controls.Add(this.J8_10P);
            this.Controls.Add(this.J7_10P);
            this.Controls.Add(this.J6_10P);
            this.Controls.Add(this.J5_10P);
            this.Controls.Add(this.J4_10P);
            this.Controls.Add(this.J3_10P);
            this.Controls.Add(this.J2_10P);
            this.Controls.Add(this.J1_10P);
            this.Controls.Add(this.J8_09);
            this.Controls.Add(this.J7_09);
            this.Controls.Add(this.J6_09);
            this.Controls.Add(this.J5_09);
            this.Controls.Add(this.J4_09);
            this.Controls.Add(this.J3_09);
            this.Controls.Add(this.J2_09);
            this.Controls.Add(this.J1_09);
            this.Controls.Add(this.J8_08);
            this.Controls.Add(this.J7_08);
            this.Controls.Add(this.J6_08);
            this.Controls.Add(this.J5_08);
            this.Controls.Add(this.J4_08);
            this.Controls.Add(this.J3_08);
            this.Controls.Add(this.J2_08);
            this.Controls.Add(this.J1_08);
            this.Controls.Add(this.J8_07);
            this.Controls.Add(this.J7_07);
            this.Controls.Add(this.J6_07);
            this.Controls.Add(this.J5_07);
            this.Controls.Add(this.J4_07);
            this.Controls.Add(this.J3_07);
            this.Controls.Add(this.J2_07);
            this.Controls.Add(this.J1_07);
            this.Controls.Add(this.J8_06);
            this.Controls.Add(this.J7_06);
            this.Controls.Add(this.J6_06);
            this.Controls.Add(this.J5_06);
            this.Controls.Add(this.J4_06);
            this.Controls.Add(this.J3_06);
            this.Controls.Add(this.J2_06);
            this.Controls.Add(this.J1_06);
            this.Controls.Add(this.J8_05);
            this.Controls.Add(this.J7_05);
            this.Controls.Add(this.J6_05);
            this.Controls.Add(this.J5_05);
            this.Controls.Add(this.J4_05);
            this.Controls.Add(this.J3_05);
            this.Controls.Add(this.J2_05);
            this.Controls.Add(this.J1_05);
            this.Controls.Add(this.J8_04);
            this.Controls.Add(this.J7_04);
            this.Controls.Add(this.J6_04);
            this.Controls.Add(this.J5_04);
            this.Controls.Add(this.J4_04);
            this.Controls.Add(this.J3_04);
            this.Controls.Add(this.J2_04);
            this.Controls.Add(this.J1_04);
            this.Controls.Add(this.J8_03);
            this.Controls.Add(this.J7_03);
            this.Controls.Add(this.J6_03);
            this.Controls.Add(this.J5_03);
            this.Controls.Add(this.J4_03);
            this.Controls.Add(this.J3_03);
            this.Controls.Add(this.J2_03);
            this.Controls.Add(this.J1_03);
            this.Controls.Add(this.J8_02);
            this.Controls.Add(this.J7_02);
            this.Controls.Add(this.J6_02);
            this.Controls.Add(this.J5_02);
            this.Controls.Add(this.J4_02);
            this.Controls.Add(this.J3_02);
            this.Controls.Add(this.J2_02);
            this.Controls.Add(this.J1_02);
            this.Controls.Add(this.J8_01);
            this.Controls.Add(this.J7_01);
            this.Controls.Add(this.J6_01);
            this.Controls.Add(this.J5_01);
            this.Controls.Add(this.J4_01);
            this.Controls.Add(this.J3_01);
            this.Controls.Add(this.J2_01);
            this.Controls.Add(this.J1_01);
            this.Controls.Add(this.J8_00);
            this.Controls.Add(this.J7_00);
            this.Controls.Add(this.J6_00);
            this.Controls.Add(this.J5_00);
            this.Controls.Add(this.J4_00);
            this.Controls.Add(this.J3_00);
            this.Controls.Add(this.J2_00);
            this.Controls.Add(this.J1_00);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.prop39);
            this.Controls.Add(this.prop37);
            this.Controls.Add(this.prop35);
            this.Controls.Add(this.prop34);
            this.Controls.Add(this.prop32);
            this.Controls.Add(this.prop31);
            this.Controls.Add(this.prop29);
            this.Controls.Add(this.prop28);
            this.Controls.Add(this.prop27);
            this.Controls.Add(this.prop26);
            this.Controls.Add(this.prop25);
            this.Controls.Add(this.prop24);
            this.Controls.Add(this.prop23);
            this.Controls.Add(this.prop21);
            this.Controls.Add(this.prop19);
            this.Controls.Add(this.prop18);
            this.Controls.Add(this.prop16);
            this.Controls.Add(this.prop15);
            this.Controls.Add(this.prop14);
            this.Controls.Add(this.prop13);
            this.Controls.Add(this.prop12);
            this.Controls.Add(this.prop11);
            this.Controls.Add(this.prop9);
            this.Controls.Add(this.prop8);
            this.Controls.Add(this.prop6);
            this.Controls.Add(this.prop5);
            this.Controls.Add(this.prop3);
            this.Controls.Add(this.prop1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.TerminarTurnoButton);
            this.Controls.Add(this.groupBox1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Jogo";
            this.Text = "Monopoly";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Jogo_FormClosing);
            this.Load += new System.EventHandler(this.Jogo_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_Color)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_10P)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_10P)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_10P)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_10P)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_10P)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_10P)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_10P)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_10P)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J8_00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J7_00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J6_00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J5_00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J4_00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J3_00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J2_00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J1_00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C1_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C1_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C1_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C1_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C8_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C8_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C8_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C8_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C9_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C9_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C9_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C9_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C11_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C11_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C11_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C11_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C13_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C13_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C13_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C13_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C14_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C14_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C14_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C14_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C16_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C16_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C16_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C16_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C18_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C18_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C18_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C18_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C19_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C19_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C19_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C19_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C21_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C21_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C21_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C21_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C23_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C23_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C23_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C23_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C24_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C24_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C24_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C24_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C26_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C26_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C26_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C26_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C27_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C27_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C27_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C27_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C29_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C29_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C29_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C29_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C31_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C31_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C31_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C31_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C32_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C32_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C32_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C32_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C34_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C34_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C34_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C34_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C37_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C37_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C37_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C37_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C39_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C39_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C39_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C39_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H39)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button dadosButton;
        private System.Windows.Forms.Label dado1label;
        private System.Windows.Forms.Label dado2label;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label dinheiroJogLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox prop1;
        private System.Windows.Forms.PictureBox prop3;
        private System.Windows.Forms.PictureBox prop5;
        private System.Windows.Forms.PictureBox prop6;
        private System.Windows.Forms.PictureBox prop8;
        private System.Windows.Forms.PictureBox prop9;
        private System.Windows.Forms.PictureBox prop11;
        private System.Windows.Forms.PictureBox prop12;
        private System.Windows.Forms.PictureBox prop13;
        private System.Windows.Forms.PictureBox prop14;
        private System.Windows.Forms.PictureBox prop15;
        private System.Windows.Forms.PictureBox prop16;
        private System.Windows.Forms.PictureBox prop18;
        private System.Windows.Forms.PictureBox prop19;
        private System.Windows.Forms.PictureBox prop21;
        private System.Windows.Forms.PictureBox prop23;
        private System.Windows.Forms.PictureBox prop24;
        private System.Windows.Forms.PictureBox prop25;
        private System.Windows.Forms.PictureBox prop26;
        private System.Windows.Forms.PictureBox prop27;
        private System.Windows.Forms.PictureBox prop28;
        private System.Windows.Forms.PictureBox prop29;
        private System.Windows.Forms.PictureBox prop31;
        private System.Windows.Forms.PictureBox prop32;
        private System.Windows.Forms.PictureBox prop34;
        private System.Windows.Forms.PictureBox prop35;
        private System.Windows.Forms.PictureBox prop37;
        private System.Windows.Forms.PictureBox prop39;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label NomeProp;
        private System.Windows.Forms.PictureBox PB_Color;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label NrHotel;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label NrCasas;
        private System.Windows.Forms.Label PreçoCasa;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label ValorHipot;
        private System.Windows.Forms.Button HipotecaButton;
        private System.Windows.Forms.Button BuildButton;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.PictureBox J1_00;
        private System.Windows.Forms.PictureBox J2_00;
        private System.Windows.Forms.PictureBox J3_00;
        private System.Windows.Forms.PictureBox J4_00;
        private System.Windows.Forms.PictureBox J5_00;
        private System.Windows.Forms.PictureBox J6_00;
        private System.Windows.Forms.PictureBox J7_00;
        private System.Windows.Forms.PictureBox J8_00;
        private System.Windows.Forms.PictureBox J1_01;
        private System.Windows.Forms.PictureBox J2_01;
        private System.Windows.Forms.PictureBox J3_01;
        private System.Windows.Forms.PictureBox J4_01;
        private System.Windows.Forms.PictureBox J5_01;
        private System.Windows.Forms.PictureBox J6_01;
        private System.Windows.Forms.PictureBox J7_01;
        private System.Windows.Forms.PictureBox J8_01;
        private System.Windows.Forms.PictureBox J8_02;
        private System.Windows.Forms.PictureBox J7_02;
        private System.Windows.Forms.PictureBox J6_02;
        private System.Windows.Forms.PictureBox J5_02;
        private System.Windows.Forms.PictureBox J4_02;
        private System.Windows.Forms.PictureBox J3_02;
        private System.Windows.Forms.PictureBox J2_02;
        private System.Windows.Forms.PictureBox J1_02;
        private System.Windows.Forms.PictureBox J8_03;
        private System.Windows.Forms.PictureBox J7_03;
        private System.Windows.Forms.PictureBox J6_03;
        private System.Windows.Forms.PictureBox J5_03;
        private System.Windows.Forms.PictureBox J4_03;
        private System.Windows.Forms.PictureBox J3_03;
        private System.Windows.Forms.PictureBox J2_03;
        private System.Windows.Forms.PictureBox J1_03;
        private System.Windows.Forms.PictureBox J8_04;
        private System.Windows.Forms.PictureBox J7_04;
        private System.Windows.Forms.PictureBox J6_04;
        private System.Windows.Forms.PictureBox J5_04;
        private System.Windows.Forms.PictureBox J4_04;
        private System.Windows.Forms.PictureBox J3_04;
        private System.Windows.Forms.PictureBox J2_04;
        private System.Windows.Forms.PictureBox J1_04;
        private System.Windows.Forms.PictureBox J8_05;
        private System.Windows.Forms.PictureBox J7_05;
        private System.Windows.Forms.PictureBox J6_05;
        private System.Windows.Forms.PictureBox J5_05;
        private System.Windows.Forms.PictureBox J4_05;
        private System.Windows.Forms.PictureBox J3_05;
        private System.Windows.Forms.PictureBox J2_05;
        private System.Windows.Forms.PictureBox J1_05;
        private System.Windows.Forms.PictureBox J8_06;
        private System.Windows.Forms.PictureBox J7_06;
        private System.Windows.Forms.PictureBox J6_06;
        private System.Windows.Forms.PictureBox J5_06;
        private System.Windows.Forms.PictureBox J4_06;
        private System.Windows.Forms.PictureBox J3_06;
        private System.Windows.Forms.PictureBox J2_06;
        private System.Windows.Forms.PictureBox J1_06;
        private System.Windows.Forms.PictureBox J8_07;
        private System.Windows.Forms.PictureBox J7_07;
        private System.Windows.Forms.PictureBox J6_07;
        private System.Windows.Forms.PictureBox J5_07;
        private System.Windows.Forms.PictureBox J4_07;
        private System.Windows.Forms.PictureBox J3_07;
        private System.Windows.Forms.PictureBox J2_07;
        private System.Windows.Forms.PictureBox J1_07;
        private System.Windows.Forms.PictureBox J8_08;
        private System.Windows.Forms.PictureBox J7_08;
        private System.Windows.Forms.PictureBox J6_08;
        private System.Windows.Forms.PictureBox J5_08;
        private System.Windows.Forms.PictureBox J4_08;
        private System.Windows.Forms.PictureBox J3_08;
        private System.Windows.Forms.PictureBox J2_08;
        private System.Windows.Forms.PictureBox J1_08;
        private System.Windows.Forms.PictureBox J8_09;
        private System.Windows.Forms.PictureBox J7_09;
        private System.Windows.Forms.PictureBox J6_09;
        private System.Windows.Forms.PictureBox J5_09;
        private System.Windows.Forms.PictureBox J4_09;
        private System.Windows.Forms.PictureBox J3_09;
        private System.Windows.Forms.PictureBox J2_09;
        private System.Windows.Forms.PictureBox J1_09;
        private System.Windows.Forms.PictureBox J8_10P;
        private System.Windows.Forms.PictureBox J7_10P;
        private System.Windows.Forms.PictureBox J6_10P;
        private System.Windows.Forms.PictureBox J5_10P;
        private System.Windows.Forms.PictureBox J4_10P;
        private System.Windows.Forms.PictureBox J3_10P;
        private System.Windows.Forms.PictureBox J2_10P;
        private System.Windows.Forms.PictureBox J1_10P;
        private System.Windows.Forms.PictureBox J8_10;
        private System.Windows.Forms.PictureBox J7_10;
        private System.Windows.Forms.PictureBox J6_10;
        private System.Windows.Forms.PictureBox J5_10;
        private System.Windows.Forms.PictureBox J4_10;
        private System.Windows.Forms.PictureBox J3_10;
        private System.Windows.Forms.PictureBox J2_10;
        private System.Windows.Forms.PictureBox J1_10;
        private System.Windows.Forms.PictureBox J8_11;
        private System.Windows.Forms.PictureBox J7_11;
        private System.Windows.Forms.PictureBox J6_11;
        private System.Windows.Forms.PictureBox J5_11;
        private System.Windows.Forms.PictureBox J4_11;
        private System.Windows.Forms.PictureBox J3_11;
        private System.Windows.Forms.PictureBox J2_11;
        private System.Windows.Forms.PictureBox J1_11;
        private System.Windows.Forms.PictureBox J8_12;
        private System.Windows.Forms.PictureBox J7_12;
        private System.Windows.Forms.PictureBox J6_12;
        private System.Windows.Forms.PictureBox J5_12;
        private System.Windows.Forms.PictureBox J4_12;
        private System.Windows.Forms.PictureBox J3_12;
        private System.Windows.Forms.PictureBox J2_12;
        private System.Windows.Forms.PictureBox J1_12;
        private System.Windows.Forms.PictureBox J8_13;
        private System.Windows.Forms.PictureBox J7_13;
        private System.Windows.Forms.PictureBox J6_13;
        private System.Windows.Forms.PictureBox J5_13;
        private System.Windows.Forms.PictureBox J4_13;
        private System.Windows.Forms.PictureBox J3_13;
        private System.Windows.Forms.PictureBox J2_13;
        private System.Windows.Forms.PictureBox J1_13;
        private System.Windows.Forms.PictureBox J8_14;
        private System.Windows.Forms.PictureBox J7_14;
        private System.Windows.Forms.PictureBox J6_14;
        private System.Windows.Forms.PictureBox J5_14;
        private System.Windows.Forms.PictureBox J4_14;
        private System.Windows.Forms.PictureBox J3_14;
        private System.Windows.Forms.PictureBox J2_14;
        private System.Windows.Forms.PictureBox J1_14;
        private System.Windows.Forms.PictureBox J8_15;
        private System.Windows.Forms.PictureBox J7_15;
        private System.Windows.Forms.PictureBox J6_15;
        private System.Windows.Forms.PictureBox J5_15;
        private System.Windows.Forms.PictureBox J4_15;
        private System.Windows.Forms.PictureBox J3_15;
        private System.Windows.Forms.PictureBox J2_15;
        private System.Windows.Forms.PictureBox J1_15;
        private System.Windows.Forms.PictureBox J8_16;
        private System.Windows.Forms.PictureBox J7_16;
        private System.Windows.Forms.PictureBox J6_16;
        private System.Windows.Forms.PictureBox J5_16;
        private System.Windows.Forms.PictureBox J4_16;
        private System.Windows.Forms.PictureBox J3_16;
        private System.Windows.Forms.PictureBox J2_16;
        private System.Windows.Forms.PictureBox J1_16;
        private System.Windows.Forms.PictureBox J8_17;
        private System.Windows.Forms.PictureBox J7_17;
        private System.Windows.Forms.PictureBox J6_17;
        private System.Windows.Forms.PictureBox J5_17;
        private System.Windows.Forms.PictureBox J4_17;
        private System.Windows.Forms.PictureBox J3_17;
        private System.Windows.Forms.PictureBox J2_17;
        private System.Windows.Forms.PictureBox J1_17;
        private System.Windows.Forms.PictureBox J8_18;
        private System.Windows.Forms.PictureBox J7_18;
        private System.Windows.Forms.PictureBox J6_18;
        private System.Windows.Forms.PictureBox J5_18;
        private System.Windows.Forms.PictureBox J4_18;
        private System.Windows.Forms.PictureBox J3_18;
        private System.Windows.Forms.PictureBox J2_18;
        private System.Windows.Forms.PictureBox J1_18;
        private System.Windows.Forms.PictureBox J8_19;
        private System.Windows.Forms.PictureBox J7_19;
        private System.Windows.Forms.PictureBox J6_19;
        private System.Windows.Forms.PictureBox J5_19;
        private System.Windows.Forms.PictureBox J4_19;
        private System.Windows.Forms.PictureBox J3_19;
        private System.Windows.Forms.PictureBox J2_19;
        private System.Windows.Forms.PictureBox J1_19;
        private System.Windows.Forms.PictureBox J8_21;
        private System.Windows.Forms.PictureBox J7_21;
        private System.Windows.Forms.PictureBox J6_21;
        private System.Windows.Forms.PictureBox J5_21;
        private System.Windows.Forms.PictureBox J4_21;
        private System.Windows.Forms.PictureBox J3_21;
        private System.Windows.Forms.PictureBox J2_21;
        private System.Windows.Forms.PictureBox J1_21;
        private System.Windows.Forms.PictureBox J8_20;
        private System.Windows.Forms.PictureBox J7_20;
        private System.Windows.Forms.PictureBox J6_20;
        private System.Windows.Forms.PictureBox J5_20;
        private System.Windows.Forms.PictureBox J4_20;
        private System.Windows.Forms.PictureBox J3_20;
        private System.Windows.Forms.PictureBox J2_20;
        private System.Windows.Forms.PictureBox J1_20;
        private System.Windows.Forms.PictureBox J8_22;
        private System.Windows.Forms.PictureBox J7_22;
        private System.Windows.Forms.PictureBox J6_22;
        private System.Windows.Forms.PictureBox J5_22;
        private System.Windows.Forms.PictureBox J4_22;
        private System.Windows.Forms.PictureBox J3_22;
        private System.Windows.Forms.PictureBox J2_22;
        private System.Windows.Forms.PictureBox J1_22;
        private System.Windows.Forms.PictureBox J8_23;
        private System.Windows.Forms.PictureBox J7_23;
        private System.Windows.Forms.PictureBox J6_23;
        private System.Windows.Forms.PictureBox J5_23;
        private System.Windows.Forms.PictureBox J4_23;
        private System.Windows.Forms.PictureBox J3_23;
        private System.Windows.Forms.PictureBox J2_23;
        private System.Windows.Forms.PictureBox J1_23;
        private System.Windows.Forms.PictureBox J8_24;
        private System.Windows.Forms.PictureBox J7_24;
        private System.Windows.Forms.PictureBox J6_24;
        private System.Windows.Forms.PictureBox J5_24;
        private System.Windows.Forms.PictureBox J4_24;
        private System.Windows.Forms.PictureBox J3_24;
        private System.Windows.Forms.PictureBox J2_24;
        private System.Windows.Forms.PictureBox J1_24;
        private System.Windows.Forms.PictureBox J8_25;
        private System.Windows.Forms.PictureBox J7_25;
        private System.Windows.Forms.PictureBox J6_25;
        private System.Windows.Forms.PictureBox J5_25;
        private System.Windows.Forms.PictureBox J4_25;
        private System.Windows.Forms.PictureBox J3_25;
        private System.Windows.Forms.PictureBox J2_25;
        private System.Windows.Forms.PictureBox J1_25;
        private System.Windows.Forms.PictureBox J8_26;
        private System.Windows.Forms.PictureBox J7_26;
        private System.Windows.Forms.PictureBox J6_26;
        private System.Windows.Forms.PictureBox J5_26;
        private System.Windows.Forms.PictureBox J4_26;
        private System.Windows.Forms.PictureBox J3_26;
        private System.Windows.Forms.PictureBox J2_26;
        private System.Windows.Forms.PictureBox J1_26;
        private System.Windows.Forms.PictureBox J8_27;
        private System.Windows.Forms.PictureBox J7_27;
        private System.Windows.Forms.PictureBox J6_27;
        private System.Windows.Forms.PictureBox J5_27;
        private System.Windows.Forms.PictureBox J4_27;
        private System.Windows.Forms.PictureBox J3_27;
        private System.Windows.Forms.PictureBox J2_27;
        private System.Windows.Forms.PictureBox J1_27;
        private System.Windows.Forms.PictureBox J8_28;
        private System.Windows.Forms.PictureBox J7_28;
        private System.Windows.Forms.PictureBox J6_28;
        private System.Windows.Forms.PictureBox J5_28;
        private System.Windows.Forms.PictureBox J4_28;
        private System.Windows.Forms.PictureBox J3_28;
        private System.Windows.Forms.PictureBox J2_28;
        private System.Windows.Forms.PictureBox J1_28;
        private System.Windows.Forms.PictureBox J8_29;
        private System.Windows.Forms.PictureBox J7_29;
        private System.Windows.Forms.PictureBox J6_29;
        private System.Windows.Forms.PictureBox J5_29;
        private System.Windows.Forms.PictureBox J4_29;
        private System.Windows.Forms.PictureBox J3_29;
        private System.Windows.Forms.PictureBox J2_29;
        private System.Windows.Forms.PictureBox J1_29;
        private System.Windows.Forms.PictureBox J8_31;
        private System.Windows.Forms.PictureBox J7_31;
        private System.Windows.Forms.PictureBox J6_31;
        private System.Windows.Forms.PictureBox J5_31;
        private System.Windows.Forms.PictureBox J4_31;
        private System.Windows.Forms.PictureBox J3_31;
        private System.Windows.Forms.PictureBox J2_31;
        private System.Windows.Forms.PictureBox J1_31;
        private System.Windows.Forms.PictureBox J8_32;
        private System.Windows.Forms.PictureBox J7_32;
        private System.Windows.Forms.PictureBox J6_32;
        private System.Windows.Forms.PictureBox J5_32;
        private System.Windows.Forms.PictureBox J4_32;
        private System.Windows.Forms.PictureBox J3_32;
        private System.Windows.Forms.PictureBox J2_32;
        private System.Windows.Forms.PictureBox J1_32;
        private System.Windows.Forms.PictureBox J8_33;
        private System.Windows.Forms.PictureBox J7_33;
        private System.Windows.Forms.PictureBox J6_33;
        private System.Windows.Forms.PictureBox J5_33;
        private System.Windows.Forms.PictureBox J4_33;
        private System.Windows.Forms.PictureBox J3_33;
        private System.Windows.Forms.PictureBox J2_33;
        private System.Windows.Forms.PictureBox J1_33;
        private System.Windows.Forms.PictureBox J8_34;
        private System.Windows.Forms.PictureBox J7_34;
        private System.Windows.Forms.PictureBox J6_34;
        private System.Windows.Forms.PictureBox J5_34;
        private System.Windows.Forms.PictureBox J4_34;
        private System.Windows.Forms.PictureBox J3_34;
        private System.Windows.Forms.PictureBox J2_34;
        private System.Windows.Forms.PictureBox J1_34;
        private System.Windows.Forms.PictureBox J8_35;
        private System.Windows.Forms.PictureBox J7_35;
        private System.Windows.Forms.PictureBox J6_35;
        private System.Windows.Forms.PictureBox J5_35;
        private System.Windows.Forms.PictureBox J4_35;
        private System.Windows.Forms.PictureBox J3_35;
        private System.Windows.Forms.PictureBox J2_35;
        private System.Windows.Forms.PictureBox J1_35;
        private System.Windows.Forms.PictureBox J8_36;
        private System.Windows.Forms.PictureBox J7_36;
        private System.Windows.Forms.PictureBox J6_36;
        private System.Windows.Forms.PictureBox J5_36;
        private System.Windows.Forms.PictureBox J4_36;
        private System.Windows.Forms.PictureBox J3_36;
        private System.Windows.Forms.PictureBox J2_36;
        private System.Windows.Forms.PictureBox J1_36;
        private System.Windows.Forms.PictureBox J8_37;
        private System.Windows.Forms.PictureBox J7_37;
        private System.Windows.Forms.PictureBox J6_37;
        private System.Windows.Forms.PictureBox J5_37;
        private System.Windows.Forms.PictureBox J4_37;
        private System.Windows.Forms.PictureBox J3_37;
        private System.Windows.Forms.PictureBox J2_37;
        private System.Windows.Forms.PictureBox J1_37;
        private System.Windows.Forms.PictureBox J8_38;
        private System.Windows.Forms.PictureBox J7_38;
        private System.Windows.Forms.PictureBox J6_38;
        private System.Windows.Forms.PictureBox J5_38;
        private System.Windows.Forms.PictureBox J4_38;
        private System.Windows.Forms.PictureBox J3_38;
        private System.Windows.Forms.PictureBox J2_38;
        private System.Windows.Forms.PictureBox J1_38;
        private System.Windows.Forms.PictureBox J8_39;
        private System.Windows.Forms.PictureBox J7_39;
        private System.Windows.Forms.PictureBox J6_39;
        private System.Windows.Forms.PictureBox J5_39;
        private System.Windows.Forms.PictureBox J4_39;
        private System.Windows.Forms.PictureBox J3_39;
        private System.Windows.Forms.PictureBox J2_39;
        private System.Windows.Forms.PictureBox J1_39;
        public System.Windows.Forms.Button TerminarTurnoButton;
        public System.Windows.Forms.Button button4;
        private System.Windows.Forms.PictureBox C1_04;
        private System.Windows.Forms.PictureBox C1_01;
        private System.Windows.Forms.PictureBox C1_03;
        private System.Windows.Forms.PictureBox C1_02;
        private System.Windows.Forms.PictureBox C3_02;
        private System.Windows.Forms.PictureBox C3_03;
        private System.Windows.Forms.PictureBox C3_01;
        private System.Windows.Forms.PictureBox C3_04;
        private System.Windows.Forms.PictureBox C6_02;
        private System.Windows.Forms.PictureBox C6_03;
        private System.Windows.Forms.PictureBox C6_01;
        private System.Windows.Forms.PictureBox C6_04;
        private System.Windows.Forms.PictureBox C8_02;
        private System.Windows.Forms.PictureBox C8_03;
        private System.Windows.Forms.PictureBox C8_01;
        private System.Windows.Forms.PictureBox C8_04;
        private System.Windows.Forms.PictureBox C9_02;
        private System.Windows.Forms.PictureBox C9_03;
        private System.Windows.Forms.PictureBox C9_01;
        private System.Windows.Forms.PictureBox C9_04;
        private System.Windows.Forms.PictureBox C11_04;
        private System.Windows.Forms.PictureBox C11_02;
        private System.Windows.Forms.PictureBox C11_03;
        private System.Windows.Forms.PictureBox C11_01;
        private System.Windows.Forms.PictureBox C13_04;
        private System.Windows.Forms.PictureBox C13_02;
        private System.Windows.Forms.PictureBox C13_03;
        private System.Windows.Forms.PictureBox C13_01;
        private System.Windows.Forms.PictureBox C14_04;
        private System.Windows.Forms.PictureBox C14_02;
        private System.Windows.Forms.PictureBox C14_03;
        private System.Windows.Forms.PictureBox C14_01;
        private System.Windows.Forms.PictureBox C16_04;
        private System.Windows.Forms.PictureBox C16_02;
        private System.Windows.Forms.PictureBox C16_03;
        private System.Windows.Forms.PictureBox C16_01;
        private System.Windows.Forms.PictureBox C18_04;
        private System.Windows.Forms.PictureBox C18_02;
        private System.Windows.Forms.PictureBox C18_03;
        private System.Windows.Forms.PictureBox C18_01;
        private System.Windows.Forms.PictureBox C19_04;
        private System.Windows.Forms.PictureBox C19_02;
        private System.Windows.Forms.PictureBox C19_03;
        private System.Windows.Forms.PictureBox C19_01;
        private System.Windows.Forms.PictureBox C21_04;
        private System.Windows.Forms.PictureBox C21_02;
        private System.Windows.Forms.PictureBox C21_03;
        private System.Windows.Forms.PictureBox C21_01;
        private System.Windows.Forms.PictureBox C23_04;
        private System.Windows.Forms.PictureBox C23_02;
        private System.Windows.Forms.PictureBox C23_03;
        private System.Windows.Forms.PictureBox C23_01;
        private System.Windows.Forms.PictureBox C24_04;
        private System.Windows.Forms.PictureBox C24_02;
        private System.Windows.Forms.PictureBox C24_03;
        private System.Windows.Forms.PictureBox C24_01;
        private System.Windows.Forms.PictureBox C26_04;
        private System.Windows.Forms.PictureBox C26_02;
        private System.Windows.Forms.PictureBox C26_03;
        private System.Windows.Forms.PictureBox C26_01;
        private System.Windows.Forms.PictureBox C27_04;
        private System.Windows.Forms.PictureBox C27_02;
        private System.Windows.Forms.PictureBox C27_03;
        private System.Windows.Forms.PictureBox C27_01;
        private System.Windows.Forms.PictureBox C29_04;
        private System.Windows.Forms.PictureBox C29_02;
        private System.Windows.Forms.PictureBox C29_03;
        private System.Windows.Forms.PictureBox C29_01;
        private System.Windows.Forms.PictureBox C31_02;
        private System.Windows.Forms.PictureBox C31_04;
        private System.Windows.Forms.PictureBox C31_01;
        private System.Windows.Forms.PictureBox C31_03;
        private System.Windows.Forms.PictureBox C32_02;
        private System.Windows.Forms.PictureBox C32_04;
        private System.Windows.Forms.PictureBox C32_01;
        private System.Windows.Forms.PictureBox C32_03;
        private System.Windows.Forms.PictureBox C34_02;
        private System.Windows.Forms.PictureBox C34_04;
        private System.Windows.Forms.PictureBox C34_01;
        private System.Windows.Forms.PictureBox C34_03;
        private System.Windows.Forms.PictureBox C37_02;
        private System.Windows.Forms.PictureBox C37_04;
        private System.Windows.Forms.PictureBox C37_01;
        private System.Windows.Forms.PictureBox C37_03;
        private System.Windows.Forms.PictureBox C39_02;
        private System.Windows.Forms.PictureBox C39_04;
        private System.Windows.Forms.PictureBox C39_01;
        private System.Windows.Forms.PictureBox C39_03;
        private System.Windows.Forms.PictureBox H1;
        private System.Windows.Forms.PictureBox H3;
        private System.Windows.Forms.PictureBox H6;
        private System.Windows.Forms.PictureBox H8;
        private System.Windows.Forms.PictureBox H9;
        private System.Windows.Forms.PictureBox H11;
        private System.Windows.Forms.PictureBox H13;
        private System.Windows.Forms.PictureBox H14;
        private System.Windows.Forms.PictureBox H16;
        private System.Windows.Forms.PictureBox H18;
        private System.Windows.Forms.PictureBox H19;
        private System.Windows.Forms.PictureBox H21;
        private System.Windows.Forms.PictureBox H23;
        private System.Windows.Forms.PictureBox H24;
        private System.Windows.Forms.PictureBox H26;
        private System.Windows.Forms.PictureBox H27;
        private System.Windows.Forms.PictureBox H29;
        private System.Windows.Forms.PictureBox H31;
        private System.Windows.Forms.PictureBox H32;
        private System.Windows.Forms.PictureBox H34;
        private System.Windows.Forms.PictureBox H37;
        private System.Windows.Forms.PictureBox H39;
    }
}