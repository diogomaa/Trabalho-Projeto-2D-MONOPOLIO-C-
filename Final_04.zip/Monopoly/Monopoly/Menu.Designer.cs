﻿namespace Monopoly
{
    partial class Menu
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.playbutton = new System.Windows.Forms.Button();
            this.opçoesButton = new System.Windows.Forms.Button();
            this.sairbutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.voltarButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // playbutton
            // 
            this.playbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.playbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.playbutton.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.playbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.playbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playbutton.ForeColor = System.Drawing.Color.White;
            this.playbutton.Location = new System.Drawing.Point(369, 182);
            this.playbutton.Margin = new System.Windows.Forms.Padding(2);
            this.playbutton.Name = "playbutton";
            this.playbutton.Size = new System.Drawing.Size(225, 57);
            this.playbutton.TabIndex = 1;
            this.playbutton.Text = "JOGAR !";
            this.playbutton.UseVisualStyleBackColor = false;
            this.playbutton.Click += new System.EventHandler(this.playbutton_Click);
            // 
            // opçoesButton
            // 
            this.opçoesButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.opçoesButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.opçoesButton.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.opçoesButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.opçoesButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.opçoesButton.ForeColor = System.Drawing.Color.White;
            this.opçoesButton.Location = new System.Drawing.Point(369, 269);
            this.opçoesButton.Margin = new System.Windows.Forms.Padding(2);
            this.opçoesButton.Name = "opçoesButton";
            this.opçoesButton.Size = new System.Drawing.Size(225, 57);
            this.opçoesButton.TabIndex = 2;
            this.opçoesButton.Text = "Sobre";
            this.opçoesButton.UseVisualStyleBackColor = false;
            this.opçoesButton.Click += new System.EventHandler(this.Button_Click);
            // 
            // sairbutton
            // 
            this.sairbutton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.sairbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.sairbutton.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.sairbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.sairbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sairbutton.ForeColor = System.Drawing.Color.White;
            this.sairbutton.Location = new System.Drawing.Point(369, 357);
            this.sairbutton.Margin = new System.Windows.Forms.Padding(2);
            this.sairbutton.Name = "sairbutton";
            this.sairbutton.Size = new System.Drawing.Size(225, 57);
            this.sairbutton.TabIndex = 3;
            this.sairbutton.Text = "Sair";
            this.sairbutton.UseVisualStyleBackColor = false;
            this.sairbutton.Click += new System.EventHandler(this.sairbutton_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(619, 530);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(317, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Projeto 2D Trabalho Realizado Por: Tiago Castro e Diogo Amorim.\r\n";
            // 
            // voltarButton
            // 
            this.voltarButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.voltarButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.voltarButton.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.voltarButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.voltarButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.voltarButton.ForeColor = System.Drawing.Color.White;
            this.voltarButton.Location = new System.Drawing.Point(502, 163);
            this.voltarButton.Margin = new System.Windows.Forms.Padding(2);
            this.voltarButton.Name = "voltarButton";
            this.voltarButton.Size = new System.Drawing.Size(141, 57);
            this.voltarButton.TabIndex = 5;
            this.voltarButton.Text = "<-- Voltar";
            this.voltarButton.UseVisualStyleBackColor = false;
            this.voltarButton.Visible = false;
            this.voltarButton.Click += new System.EventHandler(this.voltarButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(11, 159);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(520, 340);
            this.label2.TabIndex = 6;
            this.label2.Text = resources.GetString("label2.Text");
            this.label2.Visible = false;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(947, 552);
            this.Controls.Add(this.voltarButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.sairbutton);
            this.Controls.Add(this.opçoesButton);
            this.Controls.Add(this.playbutton);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximumSize = new System.Drawing.Size(963, 591);
            this.MinimumSize = new System.Drawing.Size(963, 591);
            this.Name = "Menu";
            this.Text = "Monopoly";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Menu_FormClosing);
            this.Load += new System.EventHandler(this.Menu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button playbutton;
        private System.Windows.Forms.Button opçoesButton;
        private System.Windows.Forms.Button sairbutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button voltarButton;
        private System.Windows.Forms.Label label2;
    }
}

