﻿namespace Monopoly
{
    partial class Setup
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Setup));
            this.label_NrJogadores = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Player1Image = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Player1Nome = new System.Windows.Forms.TextBox();
            this.Player2Nome = new System.Windows.Forms.TextBox();
            this.Player3Nome = new System.Windows.Forms.TextBox();
            this.Player4Nome = new System.Windows.Forms.TextBox();
            this.Player5Nome = new System.Windows.Forms.TextBox();
            this.Player6Nome = new System.Windows.Forms.TextBox();
            this.Player7Nome = new System.Windows.Forms.TextBox();
            this.Player8Nome = new System.Windows.Forms.TextBox();
            this.Startbutton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.pictureBox64 = new System.Windows.Forms.PictureBox();
            this.pictureBox72 = new System.Windows.Forms.PictureBox();
            this.pictureBox73 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player1Image)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).BeginInit();
            this.SuspendLayout();
            // 
            // label_NrJogadores
            // 
            this.label_NrJogadores.AutoSize = true;
            this.label_NrJogadores.BackColor = System.Drawing.Color.Transparent;
            this.label_NrJogadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NrJogadores.Location = new System.Drawing.Point(15, 176);
            this.label_NrJogadores.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_NrJogadores.Name = "label_NrJogadores";
            this.label_NrJogadores.Size = new System.Drawing.Size(233, 26);
            this.label_NrJogadores.TabIndex = 1;
            this.label_NrJogadores.Text = "Número de Jogadores:";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.BackColor = System.Drawing.Color.White;
            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown1.Location = new System.Drawing.Point(243, 180);
            this.numericUpDown1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.ReadOnly = true;
            this.numericUpDown1.Size = new System.Drawing.Size(68, 23);
            this.numericUpDown1.TabIndex = 2;
            this.numericUpDown1.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(334, 21);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(8, 535);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // Player1Image
            // 
            this.Player1Image.BackColor = System.Drawing.Color.Transparent;
            this.Player1Image.Image = ((System.Drawing.Image)(resources.GetObject("Player1Image.Image")));
            this.Player1Image.Location = new System.Drawing.Point(466, 21);
            this.Player1Image.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Player1Image.Name = "Player1Image";
            this.Player1Image.Size = new System.Drawing.Size(91, 101);
            this.Player1Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Player1Image.TabIndex = 5;
            this.Player1Image.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(354, 57);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 26);
            this.label1.TabIndex = 13;
            this.label1.Text = "Jogador 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(353, 197);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 26);
            this.label2.TabIndex = 14;
            this.label2.Text = "Jogador 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(353, 337);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 26);
            this.label3.TabIndex = 15;
            this.label3.Text = "Jogador 3";
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(353, 467);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 26);
            this.label4.TabIndex = 16;
            this.label4.Text = "Jogador 4";
            this.label4.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(686, 57);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 26);
            this.label5.TabIndex = 17;
            this.label5.Text = "Jogador 5";
            this.label5.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(686, 337);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 26);
            this.label7.TabIndex = 19;
            this.label7.Text = "Jogador 7";
            this.label7.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(686, 467);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 26);
            this.label8.TabIndex = 20;
            this.label8.Text = "Jogador 8";
            this.label8.Visible = false;
            // 
            // Player1Nome
            // 
            this.Player1Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player1Nome.Location = new System.Drawing.Point(465, 130);
            this.Player1Nome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Player1Nome.Name = "Player1Nome";
            this.Player1Nome.Size = new System.Drawing.Size(152, 23);
            this.Player1Nome.TabIndex = 21;
            this.Player1Nome.Text = "Nome1";
            // 
            // Player2Nome
            // 
            this.Player2Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player2Nome.Location = new System.Drawing.Point(465, 263);
            this.Player2Nome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Player2Nome.Name = "Player2Nome";
            this.Player2Nome.Size = new System.Drawing.Size(152, 23);
            this.Player2Nome.TabIndex = 22;
            this.Player2Nome.Text = "Nome2";
            // 
            // Player3Nome
            // 
            this.Player3Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player3Nome.Location = new System.Drawing.Point(465, 400);
            this.Player3Nome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Player3Nome.Name = "Player3Nome";
            this.Player3Nome.Size = new System.Drawing.Size(152, 23);
            this.Player3Nome.TabIndex = 23;
            this.Player3Nome.Text = "Nome3";
            this.Player3Nome.Visible = false;
            // 
            // Player4Nome
            // 
            this.Player4Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player4Nome.Location = new System.Drawing.Point(465, 535);
            this.Player4Nome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Player4Nome.Name = "Player4Nome";
            this.Player4Nome.Size = new System.Drawing.Size(152, 23);
            this.Player4Nome.TabIndex = 24;
            this.Player4Nome.Text = "Nome4";
            this.Player4Nome.Visible = false;
            // 
            // Player5Nome
            // 
            this.Player5Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player5Nome.Location = new System.Drawing.Point(798, 126);
            this.Player5Nome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Player5Nome.Name = "Player5Nome";
            this.Player5Nome.Size = new System.Drawing.Size(152, 23);
            this.Player5Nome.TabIndex = 25;
            this.Player5Nome.Text = "Nome5";
            this.Player5Nome.Visible = false;
            // 
            // Player6Nome
            // 
            this.Player6Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player6Nome.Location = new System.Drawing.Point(798, 263);
            this.Player6Nome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Player6Nome.Name = "Player6Nome";
            this.Player6Nome.Size = new System.Drawing.Size(152, 23);
            this.Player6Nome.TabIndex = 26;
            this.Player6Nome.Text = "Nome6";
            this.Player6Nome.Visible = false;
            // 
            // Player7Nome
            // 
            this.Player7Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player7Nome.Location = new System.Drawing.Point(798, 400);
            this.Player7Nome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Player7Nome.Name = "Player7Nome";
            this.Player7Nome.Size = new System.Drawing.Size(152, 23);
            this.Player7Nome.TabIndex = 27;
            this.Player7Nome.Text = "Nome7";
            this.Player7Nome.Visible = false;
            // 
            // Player8Nome
            // 
            this.Player8Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player8Nome.Location = new System.Drawing.Point(798, 535);
            this.Player8Nome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Player8Nome.Name = "Player8Nome";
            this.Player8Nome.Size = new System.Drawing.Size(152, 23);
            this.Player8Nome.TabIndex = 28;
            this.Player8Nome.Text = "Nome8";
            this.Player8Nome.Visible = false;
            // 
            // Startbutton
            // 
            this.Startbutton.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.Startbutton.AutoSize = true;
            this.Startbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Startbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Startbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Startbutton.ForeColor = System.Drawing.Color.White;
            this.Startbutton.Location = new System.Drawing.Point(20, 491);
            this.Startbutton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Startbutton.Name = "Startbutton";
            this.Startbutton.Size = new System.Drawing.Size(291, 66);
            this.Startbutton.TabIndex = 37;
            this.Startbutton.Text = "COMEÇAR";
            this.Startbutton.UseVisualStyleBackColor = false;
            this.Startbutton.Click += new System.EventHandler(this.Startbutton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.AccessibleDescription = "";
            this.pictureBox1.BackColor = System.Drawing.Color.Blue;
            this.pictureBox1.Location = new System.Drawing.Point(560, 21);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(91, 101);
            this.pictureBox1.TabIndex = 38;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Red;
            this.pictureBox3.Location = new System.Drawing.Point(560, 158);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(91, 101);
            this.pictureBox3.TabIndex = 39;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.LimeGreen;
            this.pictureBox4.Location = new System.Drawing.Point(560, 295);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(91, 101);
            this.pictureBox4.TabIndex = 40;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Yellow;
            this.pictureBox5.Location = new System.Drawing.Point(560, 430);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(91, 101);
            this.pictureBox5.TabIndex = 41;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Visible = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Pink;
            this.pictureBox6.Location = new System.Drawing.Point(893, 21);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(91, 101);
            this.pictureBox6.TabIndex = 42;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Visible = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Orange;
            this.pictureBox7.Location = new System.Drawing.Point(893, 160);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(91, 101);
            this.pictureBox7.TabIndex = 43;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Visible = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Purple;
            this.pictureBox8.Location = new System.Drawing.Point(893, 295);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(91, 101);
            this.pictureBox8.TabIndex = 44;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Visible = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Chocolate;
            this.pictureBox9.Location = new System.Drawing.Point(893, 430);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(91, 101);
            this.pictureBox9.TabIndex = 45;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Visible = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Carro",
            "Cão",
            "Carrinho Mão",
            "Chapéu",
            "Barco",
            "Ferro",
            "Bota",
            "Dedal"});
            this.comboBox1.Location = new System.Drawing.Point(358, 86);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(103, 21);
            this.comboBox1.TabIndex = 50;
            this.comboBox1.Text = "ESCOLHA PEÇA";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // pictureBox24
            // 
            this.pictureBox24.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox24.Location = new System.Drawing.Point(467, 157);
            this.pictureBox24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(91, 101);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox24.TabIndex = 56;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.Click += new System.EventHandler(this.pictureBox24_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Carro",
            "Cão",
            "Carrinho Mão",
            "Chapéu",
            "Barco",
            "Ferro",
            "Bota",
            "Dedal"});
            this.comboBox2.Location = new System.Drawing.Point(359, 226);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(103, 21);
            this.comboBox2.TabIndex = 64;
            this.comboBox2.Text = "ESCOLHA PEÇA";
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Carro",
            "Cão",
            "Carrinho Mão",
            "Chapéu",
            "Barco",
            "Ferro",
            "Bota",
            "Dedal"});
            this.comboBox3.Location = new System.Drawing.Point(359, 366);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(103, 21);
            this.comboBox3.TabIndex = 65;
            this.comboBox3.Text = "ESCOLHA PEÇA";
            this.comboBox3.Visible = false;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Carro",
            "Cão",
            "Carrinho Mão",
            "Chapéu",
            "Barco",
            "Ferro",
            "Bota",
            "Dedal"});
            this.comboBox4.Location = new System.Drawing.Point(359, 496);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(103, 21);
            this.comboBox4.TabIndex = 66;
            this.comboBox4.Text = "ESCOLHA PEÇA";
            this.comboBox4.Visible = false;
            this.comboBox4.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "Carro",
            "Cão",
            "Carrinho Mão",
            "Chapéu",
            "Barco",
            "Ferro",
            "Bota",
            "Dedal"});
            this.comboBox5.Location = new System.Drawing.Point(691, 86);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(103, 21);
            this.comboBox5.TabIndex = 67;
            this.comboBox5.Text = "ESCOLHA PEÇA";
            this.comboBox5.Visible = false;
            this.comboBox5.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "Carro",
            "Cão",
            "Carrinho Mão",
            "Chapéu",
            "Barco",
            "Ferro",
            "Bota",
            "Dedal"});
            this.comboBox6.Location = new System.Drawing.Point(691, 226);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(103, 21);
            this.comboBox6.TabIndex = 68;
            this.comboBox6.Text = "ESCOLHA PEÇA";
            this.comboBox6.Visible = false;
            this.comboBox6.SelectedIndexChanged += new System.EventHandler(this.comboBox6_SelectedIndexChanged);
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "Carro",
            "Cão",
            "Carrinho Mão",
            "Chapéu",
            "Barco",
            "Ferro",
            "Bota",
            "Dedal"});
            this.comboBox7.Location = new System.Drawing.Point(691, 366);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(103, 21);
            this.comboBox7.TabIndex = 69;
            this.comboBox7.Text = "ESCOLHA PEÇA";
            this.comboBox7.Visible = false;
            this.comboBox7.SelectedIndexChanged += new System.EventHandler(this.comboBox7_SelectedIndexChanged);
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "Carro",
            "Cão",
            "Carrinho Mão",
            "Chapéu",
            "Barco",
            "Ferro",
            "Bota",
            "Dedal"});
            this.comboBox8.Location = new System.Drawing.Point(691, 496);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(103, 21);
            this.comboBox8.TabIndex = 70;
            this.comboBox8.Text = "ESCOLHA PEÇA";
            this.comboBox8.Visible = false;
            this.comboBox8.SelectedIndexChanged += new System.EventHandler(this.comboBox8_SelectedIndexChanged);
            // 
            // pictureBox32
            // 
            this.pictureBox32.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox32.Location = new System.Drawing.Point(467, 294);
            this.pictureBox32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(91, 101);
            this.pictureBox32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox32.TabIndex = 71;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.Visible = false;
            // 
            // pictureBox40
            // 
            this.pictureBox40.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox40.Location = new System.Drawing.Point(465, 429);
            this.pictureBox40.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(91, 101);
            this.pictureBox40.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox40.TabIndex = 79;
            this.pictureBox40.TabStop = false;
            this.pictureBox40.Visible = false;
            // 
            // pictureBox48
            // 
            this.pictureBox48.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox48.Location = new System.Drawing.Point(799, 21);
            this.pictureBox48.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(91, 101);
            this.pictureBox48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox48.TabIndex = 87;
            this.pictureBox48.TabStop = false;
            this.pictureBox48.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(686, 197);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 26);
            this.label6.TabIndex = 18;
            this.label6.Text = "Jogador 6";
            this.label6.Visible = false;
            // 
            // pictureBox56
            // 
            this.pictureBox56.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox56.Location = new System.Drawing.Point(798, 159);
            this.pictureBox56.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(91, 101);
            this.pictureBox56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox56.TabIndex = 95;
            this.pictureBox56.TabStop = false;
            this.pictureBox56.Visible = false;
            // 
            // pictureBox64
            // 
            this.pictureBox64.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox64.Location = new System.Drawing.Point(798, 295);
            this.pictureBox64.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox64.Name = "pictureBox64";
            this.pictureBox64.Size = new System.Drawing.Size(91, 101);
            this.pictureBox64.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox64.TabIndex = 103;
            this.pictureBox64.TabStop = false;
            this.pictureBox64.Visible = false;
            // 
            // pictureBox72
            // 
            this.pictureBox72.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox72.Location = new System.Drawing.Point(799, 429);
            this.pictureBox72.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox72.Name = "pictureBox72";
            this.pictureBox72.Size = new System.Drawing.Size(91, 101);
            this.pictureBox72.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox72.TabIndex = 111;
            this.pictureBox72.TabStop = false;
            this.pictureBox72.Visible = false;
            // 
            // pictureBox73
            // 
            this.pictureBox73.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox73.Image = global::Monopoly.Properties.Resources.MonopolyLogo;
            this.pictureBox73.Location = new System.Drawing.Point(20, 21);
            this.pictureBox73.Name = "pictureBox73";
            this.pictureBox73.Size = new System.Drawing.Size(309, 128);
            this.pictureBox73.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox73.TabIndex = 119;
            this.pictureBox73.TabStop = false;
            // 
            // Setup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1011, 586);
            this.Controls.Add(this.pictureBox73);
            this.Controls.Add(this.pictureBox72);
            this.Controls.Add(this.pictureBox64);
            this.Controls.Add(this.pictureBox56);
            this.Controls.Add(this.pictureBox48);
            this.Controls.Add(this.pictureBox40);
            this.Controls.Add(this.pictureBox32);
            this.Controls.Add(this.comboBox8);
            this.Controls.Add(this.comboBox7);
            this.Controls.Add(this.comboBox6);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.pictureBox24);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Startbutton);
            this.Controls.Add(this.Player8Nome);
            this.Controls.Add(this.Player7Nome);
            this.Controls.Add(this.Player6Nome);
            this.Controls.Add(this.Player5Nome);
            this.Controls.Add(this.Player4Nome);
            this.Controls.Add(this.Player3Nome);
            this.Controls.Add(this.Player2Nome);
            this.Controls.Add(this.Player1Nome);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Player1Image);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.label_NrJogadores);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MinimumSize = new System.Drawing.Size(602, 492);
            this.Name = "Setup";
            this.ShowIcon = false;
            this.Text = "Monopoly";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Setup_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player1Image)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_NrJogadores;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox Player1Image;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Player1Nome;
        private System.Windows.Forms.TextBox Player2Nome;
        private System.Windows.Forms.TextBox Player3Nome;
        private System.Windows.Forms.TextBox Player4Nome;
        private System.Windows.Forms.TextBox Player5Nome;
        private System.Windows.Forms.TextBox Player6Nome;
        private System.Windows.Forms.TextBox Player7Nome;
        private System.Windows.Forms.TextBox Player8Nome;
        public System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button Startbutton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.PictureBox pictureBox64;
        private System.Windows.Forms.PictureBox pictureBox72;
        private System.Windows.Forms.PictureBox pictureBox73;
    }
}

