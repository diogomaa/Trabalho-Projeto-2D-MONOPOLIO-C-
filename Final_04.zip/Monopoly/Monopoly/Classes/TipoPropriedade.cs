﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monopoly.Classes
{
    public enum TipoPropriedade
    {

        Brown, Blue, Pink, Orange, Red, Yellow, Green, Purple, Estação, Companhia
        
    }
}
